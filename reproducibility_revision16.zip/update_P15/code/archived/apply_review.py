"""Apply explicit review readings and sourced geography into a separate release."""
import calendar
import copy
import csv
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
OUT=Path(__file__).resolve().parents[1];ROOT=OUT.parents[1];OLD=OUT.with_name('quality_audit_20261024_01')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def jl(p): return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def writejl(name,rows): (OUT/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
def csvout(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

review_path=next((OUT/'inputs').glob('60*.json'));review=read(review_path)
reviews={r['sample_id']:r for r in review['records']}
samples={r['sample_id']:r for r in read(OLD/'inputs/review60_evidence.json')}
baseline=jl(OUT/'inputs/baseline_specimen_information_records.jsonl')
records={r['sample_id']:copy.deepcopy(r) for r in baseline}
baseline_geo=jl(OUT/'inputs/baseline_spatial_records_human_corrected.jsonl')
spatial={r['sample_id']:copy.deepcopy(r) for r in baseline_geo}
changes=[]

def change(sid,field,value,reason,scope='record'):
    obj=records[sid] if scope=='record' else spatial[sid]
    before=copy.deepcopy(obj.get(field))
    if before!=value:
        obj[field]=copy.deepcopy(value)
        changes.append({'sample_id':sid,'scope':scope,'field':field,'before':before,'after':copy.deepcopy(value),'reason':reason,'evidence':'user_review:'+sid})

def replace_locality(sid,replacements):
    text=records[sid]['human_corrected_locality']
    for before,after in replacements:
        assert before in text,(sid,before)
        text=text.replace(before,after)
    change(sid,'human_corrected_locality',text,'采用人工已确认的文字；其余原文保留')

# Author-confirmed readings. Ellipses and abbreviated genera remain literal.
name_readings={
 'TASH074270':('Dracocephalum nuratavicum Adylov','corrected_label_reading'),
 'TASH116605':('Lepyrodiclis holosteoides','core_reading_author_unresolved'),
 'TASH072681':('Kudrjaschevia jacubii (Lipsky) Poj…','partial_author_reading'),
 'TASH072195':('N. podostachys','full_sheet_abbreviated_genus'),
 'TASH072215':('N. podostachys','full_sheet_abbreviated_genus'),
 'TASH087131':('Calligonum Caput-Medusae Schrenk.','full_sheet_identification_label'),
 'TASH104742':('Rheum Maximowiczi','full_sheet_core_reading_author_unresolved'),
 'TASH051980':('Rumex crispus L.','full_sheet_identification_label'),
 'TASH118058':('Spergularia microspermoides Vved.','corrected_label_reading'),
 'TASH074662':('Dracocephalum spinulosum M.Pop.','corrected_label_reading'),
}
for sid,(value,kind) in name_readings.items():
    change(sid,'scientific_name',value,'人工核查提供的可读名称；不另作现代接受名替换')
    change(sid,'name_reading_scope',kind,'标明主签、整张标本补读及尚未恢复的部分')
change('TASH118240','name_unresolved_fragment',records['TASH118240']['scientific_name'],'印章遮挡；仅保留原残片供追溯')
change('TASH118240','scientific_name','','人工未能确认属名；不把残片当作可靠学名')
for sid,name in [('TASH105672','Atraphaxis frutescens (L.)…'),('TASH104219','Polygonum argyrocoleum Steud.'),('TASH088398','Rumex Paulsenianus Rech.f.')]:
    change(sid,'identification_history',[{'name':records[sid]['scientific_name'],'role':'original_label_name'},{'name':name,'role':'additional_identification_label','source':'user_review_full_sheet','identification_date':None}],'并存原签与另一鉴定签；不以未定年附签覆盖原名')

change('TASH074270','collector','Йиғ. – Бешко Н.','按原标签保留采集前缀与已确认姓名')
change('TASH066908','collector','Протопопов Г.Ф.','依据本轮人工对误读姓氏的修正')
change('TASH072681','collector','Бешко Н.Ю.','按人工确认姓名修正；括线不并入姓氏')
change('TASH065952','collector','Р. Аболинъ','原签印刷姓氏末字为ъ')
change('TASH069165','collector_unresolved_fragment','Ел. М…вич','人工仅确认不完整字形，原候选姓氏不成立')
change('TASH069165','collector','','撤下已确认不符的Мерцбахеръ全名，保留不完整读文另列')

replace_locality('TASH074270',[('хал[т]ений','Хаятсай')])
replace_locality('TASH068624',[('ка[к] нов','на ЮВ')])
replace_locality('TASH072195',[('Субсцы тибсман степь на вне. 2700 м. н.у.м.','Субальпийская степь на выс. 2700 м н.у.м.')])
replace_locality('TASH072215',[('лугкой','легкой'),('экспозич.','экспозиц.')])
replace_locality('TASH071382',[('Ущелье речеее.','Ущелье. Редкое.')])
replace_locality('TASH114292',[('Чаркаевского','Чаткальского'),('303','ЗСЗ')])
replace_locality('TASH065960',[('Карадарьин','Каравшин')])
replace_locality('TASH115103',[('Асты-Джунгарское','Алтын-Эмелевское'),('Асты-Джунг','Алтын-Эмель')])
replace_locality('TASH118737',[('Ташкентское','Пскентское'),('Ташкент','Пскент')])
replace_locality('TASH065920',[('Кочевовка','Кочевка')])
replace_locality('TASH118058',[('сыраз','сырая')])
replace_locality('TASH092113',[('понижениц','понижения')])
replace_locality('TASH104219',[('шпте','ниже')])
replace_locality('TASH069165',[('ущ. по р. станицы','окр. почт. станции')])
change('TASH074662','human_corrected_locality','Чаткальского горно-лесного заповедника. МАЙДАНТАЛЬСКИЙ УЧАСТОК. '+records['TASH074662']['human_corrected_locality'],'补入有效抬头及分区；已划去Bashkizilsay不采用，小地名拼写仍待核')
change('TASH104881','collection_number','6062020317','人工确认№6062020317为采集编号，另存字段')
change('TASH051980','verified_additional_locality_fragments',['Аллювиаль-ные','старого русла реки Зеравшан'],'保存人工可读片段；未虚补整句连接部分')

# Preserve catalogue dates, add a separate event-date interpretation with original precision.
for sid,rr in reviews.items():
    r=records[sid];a=rr['answers'];kind=a['date']
    change(sid,'event_date',{'start':r['catalogue_date_start'],'end':r['catalogue_date_end'],'source':'catalogue_interval_checked_against_label' if kind=='consistent' else 'catalogue_unverified','image_support':kind=='consistent','precision':'day' if r['catalogue_date_start']==r['catalogue_date_end'] else 'interval'},'将编目原值与本轮图像支持分开记录')

def event_date(sid,start,end,precision,verbatim,reason):
    change(sid,'event_date',{'start':start,'end':end,'source':'label_human_review','image_support':True,'precision':precision,'verbatim':verbatim},reason)
for sid,date in [('TASH074270','2019-06-16'),('TASH072681','2012-06-27'),('TASH118737','1962-06-08'),('TASH118058','1958-04-20')]:
    event_date(sid,date,date,'day',date,'采用人工确认的标签日期；旧编目日期原样留存')
event_date('TASH070541','1976-06-01','1976-06-30','month','июнь 1976','标签支持6月而非编目7月；以月区间记录，不指定某日')
event_date('TASH105737','1918-01-01','1918-12-31','year','1918; 16 (3) [month/calendar unresolved]','先恢复明确年份；月份、双日期历法另列待核')
event_date('TASH115626','1930-05-01','1930-05-31','month','1930; V','标签支持年/月；编目16日未获图像核实')
for sid in ['TASH065960','TASH069165','TASH088398']:
    change(sid,'event_date',{'start':None,'end':None,'source':'unresolved_label_date','image_support':False,'catalogue_candidate_start':records[sid]['catalogue_date_start'],'catalogue_candidate_end':records[sid]['catalogue_date_end'],'note':reviews[sid]['answers']['correction_note']},'尚不能确定的日期保留为编目候选，不作为已图像确认日期使用')

ROLE_ZH={'collection_anchor':'采集相关地物参考位置','regional_context':'区域背景参考位置','nearby_reference':'附近参照物位置','route_endpoint':'路线端点位置'}
def change_roles(sid,roles,reason):
    points=copy.deepcopy(spatial[sid]['reference_points'])
    for p in points:
        if p['entity_id'] in roles:
            p['role']=roles[p['entity_id']];p['role_zh']=ROLE_ZH[p['role']];p['role_evidence']=reviews[sid]['answers']['correction_note']
    change(sid,'reference_points',points,reason,'spatial')
change_roles('TASH066908',{'geonames:1217473':'route_endpoint'},'Derbent是路线路端，保留到达方向，不当成采集点')
change_roles('TASH068624',{'geonames:1514688':'regional_context','geonames:1524774':'regional_context'},'两河界定河间区域，调整为背景边界参照')
change_roles('TASH116954',{'geonames:1513083':'regional_context'},'Nuratau仅为周边背景；Pistalitov仍为采集相关山地')
for sid,relation in [('TASH085912','越过Kurday山口后28公里；路线未重建，参考点不是采集点'),('TASH118240','Chochay与Terek支流之间；Kenkol/Talas为水系参照'),('TASH075599','390公里是自塔什干出发的路线里程；采集在Pistali附近，不是距山口390公里'),('TASH103673','Kerki与Surkhi之间、阿姆河右岸、铁路附近；端点不等于采集点')]:
    change(sid,'reviewed_spatial_relation',relation,'保存人工核准的空间关系','spatial')

def new_point(sid,entity,name,span,kind,role,lat,lon,source,extra=None):
    p={'sample_id':sid,'case_id':sid+'__quality_audit02','input_version':'quality_audit02','entity_id':entity,'place_name':name,'label_span':span,'feature_kind':kind,'role':role,'role_zh':ROLE_ZH[role],'latitude':lat,'longitude':lon,'status':'supported','coordinate_is_from_specimen_label':False,'sample_point_measurement_accuracy_m':None,'feature_extent_known':False,'country_label_conflict':False,'source':source,'source_text':records[sid]['human_corrected_locality'],'support_basis':'human_confirmed_reading_plus_retrieved_source'}
    if extra:p.update(extra)
    return p

# Replace the wrong city binding only after the review confirmed Pskent.
c=read(OLD/'results/candidate_TASH118737.json')['candidates'][0]
sid='TASH118737';oldpoint=spatial[sid]['reference_points']
change(sid,'withdrawn_reference_points',[{**p,'status':'withdrawn','reason':'Пскент was misread as Ташкент'} for p in oldpoint],'留存已撤回的错误塔什干绑定','spatial')
change(sid,'reference_points',[new_point(sid,c['entity_id'],c['name'],'г. Пскент','settlement','nearby_reference',c['reference_point']['latitude'],c['reference_point']['longitude'],'https://www.geonames.org/1512986/',{'reference_point_admin':c['reference_point_admin'],'relative_constraint':'0.5 km south of Pskent; origin within town unspecified'})],'已确认Pskent读字与现有GeoNames/GNS记录相符，替换参照','spatial')
admin=copy.deepcopy(spatial[sid]['administration'])
for unit in admin['supported_units']:unit['evidence']='已确认Пскент/Piskent及其邻近采集描述；保留Uzbekistan国别，参考点的县不直接转为采集县。'
change(sid,'administration',admin,'同步修正国别依据中的旧城市名','spatial')

# A pass is a nearby reference for the experimental field, not its collection coordinate.
c=next(c for c in read(OLD/'results/candidate_TASH115103.json')['candidates'] if c['entity_id']=='geonames:1517328')
sid='TASH115103'
p=new_point(sid,c['entity_id'],c['name'],'перевала Алтын-Эмель','pass','nearby_reference',c['reference_point']['latitude'],c['reference_point']['longitude'],'https://www.geonames.org/1517328/',{'relative_constraint':'experimental field near the pass; exact field location not established'})
change(sid,'reference_points',spatial[sid]['reference_points']+[p],'依据人工纠正的山口名称补入更细邻近参照','spatial')

sid='TASH114292';chatkal=spatial['TASH076012']['reference_points'][0]
p=new_point(sid,chatkal['entity_id'],chatkal['place_name'],'Чаткальского хребта','mountain','regional_context',chatkal['latitude'],chatkal['longitude'],chatkal['source'])
change(sid,'reference_points',spatial[sid]['reference_points']+[p],'人工核准Chatkal山脉，补入既有库中对应背景','spatial')

# Withdraw a relationship that the review found unsupported.
sid='TASH115626'
change(sid,'candidate_reference_points',spatial[sid]['candidate_reference_points']+[{**p,'status':'insufficient_relationship_evidence','review_note':reviews[sid]['answers']['correction_note']} for p in spatial[sid]['reference_points']],'Panj实体本身存在，但与花园采集的关系未确认','spatial')
change(sid,'reference_points',[],'从已支持结果撤下Panj采集参照，保存为待核候选','spatial')

# The review recovered an actual label coordinate; project it using archived boundaries.
sid='TASH076012';projection=read(OUT/'results/TASH076012_projection.json');units=[]
for u in projection['intersecting_units']:
    if u['covers_whole_geometry']:
        units.append({'id':'gb:UZ:'+u['level']+':'+u['shape_id'],'name':u['name'],'country':'UZ','level':int(u['level'][3:]),'year':u['boundary_year'],'source':u['source'],'basis':'label_coordinate','evidence':'人工确认标签坐标41.179260,70.081114，与存档GeoBoundaries边界叠加'})
coord={'geometry_role':'label_coordinate','latitude':41.179260,'longitude':70.081114,'original_span':'N 41.179260° E 70.081114°','coordinate_uncertainty_m':None,'original_datum':None,'overlay_crs':'EPSG:4326','units':units,'source':'label_human_review','image_source':samples[sid]['context']['image'],'issue':None}
change(sid,'label_coordinate',coord,'补入人工从原图确认的坐标','spatial')
admin=copy.deepcopy(spatial[sid]['administration']);admin['supported_units']=units;admin['finest_level']=2;admin['country_codes']=['UZ']
change(sid,'administration',admin,'标签坐标投影至Akhangaran—Tashkent Region—Uzbekistan（存档边界年份保留）','spatial')
change(sid,'altitude_m',1644,'人工确认标签海拔1644米')

# Both previously unresolved specimens now have named, sourced background references.
external=read(OUT/'inputs/supplemental_spatial_evidence.json')
for sid,ev,span in [('TASH069165',external[0],'Копетъ-дагъ'),('TASH074662',external[1],'МАЙДАНТАЛЬСКИЙ УЧАСТОК')]:
    p=new_point(sid,ev['entity_id'],ev['name'],span,ev['feature_kind'],'regional_context',ev['latitude'],ev['longitude'],ev['source'],{'coordinate_role':ev['coordinate_role'],'source_year':ev.get('source_year'),'country_scope':ev['country_scope'],'supporting_source':ev['supporting_source'],'evidence_application':ev['application']})
    change(sid,'reference_points',[p],'将人工确认的名称与公开权威来源连接为背景参照','spatial')
uz=copy.deepcopy(next(u for u in spatial['TASH074270']['administration']['supported_units'] if u['level']==0))
for k in ['human_confirmed','human_review_case']:uz.pop(k,None)
uz.update({'basis':'named_protected_area_country','evidence':'人工确认Chatkal保护区Maidantal分区；UNESCO分区表列Uzbekistan','source':'https://whc.unesco.org/document/141700'})
admin=copy.deepcopy(spatial['TASH074662']['administration']);admin['supported_units']=[uz];admin['finest_level']=0;admin['country_codes']=['UZ']
change('TASH074662','administration',admin,'保护区分区身份支持国别；不从其中心点推定采集县','spatial')

# Keep ambiguous user readings as candidates and combine follow-up items per specimen.
pending={
 'TASH065900':('field','采集人姓氏与首字母仍不清；月份已保留，无需再确认日。'),
 'TASH105737':('field','采集人姓氏；1918年双日期16(3)的月份与历法。'),
 'TASH116605':('field','Lepyrodiclis holosteoides的作者缩写、采集人，以及更细峡谷名。'),
 'TASH072681':('field','学名作者Poj…的完整读文；ур.后小地名的漏字。姓名、年月日和已有山脉位置已落实。'),
 'TASH092079':('field','采集人和-сай-细地名；Tентек上游背景已保留。'),
 'TASH118240':('field','印章覆盖属名，目前仅sp.可确认；需更清晰影像或另一鉴定签。'),
 'TASH104742':('field','Rheum Maximowiczi的作者及产地细节；山脉文字已移出学名。'),
 'TASH065960':('field','日期1939-06-14或1939-07-04的字形；河名Каравшин已按核查落实。'),
 'TASH115103':('field','采集栏的完整身份读文；Алтын-Эмель山口新参照已落实。'),
 'TASH071916':('field','河名疑Тюп、采集人疑Е. Короткова，均保留候选而未强改为确定读文。'),
 'TASH065920':('field','采集人姓氏和第二条河名（候选Данчи）；国别、日期与营地编号已保留。'),
 'TASH069165':('field','采集人部分字形Ел. М…вич、年份及邮驿站名称；山系背景已补回，无需重核Kopet Dag身份。'),
 'TASH065952':('field','淡色种加词候选spicata；现有可靠属名和作者缩写保留。'),
 'TASH088398':('field','编目1916年未能从图上核实；历史费尔干纳州的范围尚待地图。两张鉴定签已并存。'),
 'TASH115626':('spatial_correctness','手写Stalinabad花园采集与印刷Panj区域标题的关系；Panj采集参照已撤下，等待确认实际地点。'),
 'TASH068624':('precision','Парку-Сай聚落身份及部分地形词；两河已改作河间区域背景。'),
 'TASH072195':('precision','山口Шуваем的读字与位置；额外铅笔学名及2700米生境已补录。'),
 'TASH071382':('precision','урочище后的细地名；Шах-Дара河谷参照不受影响。'),
 'TASH051980':('precision','原签淡色续行的完整读文；已保存可读冲积物/旧河道片段及额外学名。'),
 'TASH075128':('precision','末行小地名候选Майли сай；现有国家范围成立。'),
 'TASH104219':('spatial_correctness','Азим.-Курган及上级地点链；维持未定位，避免只按近形名称赋点。'),
 'TASH119822':('spatial_correctness','两河原始拼写与Pishpek历史县地图的相互印证；保留历史名称，尚未赋现代位置。'),
 'TASH074662':('precision','手写小地名Ак-Тахтай候选与分区内坡面；Maidantal背景及UZ国别已补回。'),
}
categories={'label_coordinate':'已有可用标签坐标','collection_reference':'已有采集相关地物坐标或范围','context_reference':'已有区域背景或附近参照坐标','administrative_range':'目前只有行政范围','unresolved':'尚无可展示的已支持空间位置'}
review_sha=hashlib.sha256(review_path.read_bytes()).hexdigest()
for sid,rr in reviews.items():
    r=records[sid];s=spatial[sid];a=rr['answers']
    # Record quality describes the reviewed old version. Applying fixes does not create a second independent score.
    r['quality_audit']={'audit_id':OUT.name,'reviewer':review['reviewer'],'source_review_sha256':review_sha,'reviewed_input_sha256':rr['source_text_sha256'],'before_revision_judgments':a,'evidence_opened':rr.get('evidence_opened',[]),'updated_at':rr.get('updated_at'),'after_revision_independently_rescored':False}
    r['field_quality_before_revision']={k:a[k] for k in ['scientific_name','locality','collector','date']}
    r['original_model_fields']={k:sample['record'][k] for k in ['scientific_name','locality','collector'] for sample in [samples[sid]]}
    r['curated_field_notes']=a['correction_note']
    r['unresolved_review_items']=[pending[sid][1]] if sid in pending else []
    s['quality_audit']=copy.deepcopy(r['quality_audit'])
    s['source_text']=r['human_corrected_locality'];s['source_sha256']=hashlib.sha256(s['source_text'].encode('utf-8')).hexdigest()
    s['input_version']='quality_audit02';s['case_id']=sid+'__quality_audit02'
    if r['event_date']['image_support']:
        s['date']=r['event_date']['start']
        s['date_precision']=r['event_date']['precision']
    else:s['date']=None;s['date_precision']='unconfirmed'
    s['date_source']='reviewed_event_date'
    s['catalogue_date_original']={'start':r['catalogue_date_start'],'end':r['catalogue_date_end']}
    s['source_text_before_current_review']=samples[sid]['spatial']['source_text']
    for p in s['reference_points']:
        p['source_text']=s['source_text'];p['input_version']='quality_audit02';p['case_id']=s['case_id']
    usable=bool(s.get('label_coordinate') and not s['label_coordinate'].get('issue'))
    direct=any(p['role']=='collection_anchor' for p in s['reference_points'])
    category='label_coordinate' if usable else 'collection_reference' if direct or s['ranges'] else 'context_reference' if s['reference_points'] else 'administrative_range' if s['administration'].get('supported_units') else 'unresolved'
    change(sid,'category',category,'按与旧版相同的五类规则重算，保留角色区分','spatial')
    s['category_zh']=categories[category];s['geospatial_reference_available']=bool(usable or s['reference_points'] or s['ranges'])
    s['collection_linked_spatial_reference']=bool(usable or direct or s['ranges']);s['label_coordinate_usable']=usable
    r.update({'spatial_category':category,'spatial_category_zh':categories[category],'has_spatial_or_admin':category!='unresolved','has_point_or_range_reference':s['geospatial_reference_available'],'has_collection_linked_reference':s['collection_linked_spatial_reference'],'label_coordinate_usable':usable,'label_coordinate':copy.deepcopy(s['label_coordinate']),'reference_points':copy.deepcopy(s['reference_points']),'ranges':copy.deepcopy(s['ranges']),'administration':copy.deepcopy(s['administration'])})
    # Old character/field adjudication belongs to the old model text, not the curated new text.
    r['original_adjudicated_grades']={f:r.get(f+'_adjudicated_grade') for f in ['scientific_name','locality','collector']}
    for f in ['scientific_name','locality','collector']:r[f+'_adjudicated_grade']=None
    r['all_three_fields_nonempty']=all(bool(r[f]) for f in ['scientific_name','human_corrected_locality','collector'])
    r['name_with_spatial_or_admin']=bool(r['scientific_name']) and r['has_spatial_or_admin']
    eventok=bool(r['event_date']['start']) and 1800<=int(r['event_date']['start'][:4])<=2026
    r['name_collector_date_with_spatial_or_admin']=bool(r['name_with_spatial_or_admin'] and r['collector'] and eventok)
    # The prior three-field flag is not recomputed as a new post-correction human score.
    r['all_three_fields_image_supported_before_current_revision']=r.get('all_three_fields_image_supported')
    r['all_three_fields_image_supported']=None

new_records=[records[r['sample_id']] for r in baseline]
new_spatial=[spatial[r['sample_id']] for r in baseline_geo]
writejl('derived/specimen_information_records_reviewed319.jsonl',new_records)
writejl('derived/spatial_records_reviewed319.jsonl',new_spatial)
save('results/corrections_before_after.json',changes)
csvout('results/corrections_before_after.csv',[{**x,'before':json.dumps(x['before'],ensure_ascii=False),'after':json.dumps(x['after'],ensure_ascii=False)} for x in changes])
save('results/review_dispositions60.json',[{'sample_id':r['sample_id'],'judgments_before':r['answers'],'changes':[c for c in changes if c['sample_id']==r['sample_id']],'remaining':pending.get(r['sample_id']),'new_spatial_category':spatial[r['sample_id']]['category']} for r in review['records']])
save('results/remaining_items.json',[{'sample_id':sid,'category':v[0],'question':v[1],'original_human_note':reviews[sid]['answers']['correction_note'],'image':samples[sid]['context']['image'],'full_sheet_path':samples[sid]['full_sheet_path'],'new_spatial_category':spatial[sid]['category']} for sid,v in pending.items()])
summary={'n':319,'reviewed_n':60,'unreviewed_n':259,'records_with_explicit_value_or_structure_changes':len({x['sample_id'] for x in changes}),'change_entries':len(changes),'before_categories':dict(Counter(r['spatial_category'] for r in baseline)),'after_categories':dict(Counter(r['spatial_category'] for r in new_records)),'before_spatial_coverage':sum(r['has_spatial_or_admin'] for r in baseline),'after_spatial_coverage':sum(r['has_spatial_or_admin'] for r in new_records),'label_coordinates_before':13,'label_coordinates_after':sum(r['label_coordinate_usable'] for r in new_records),'confirmed_wrong_location_replaced':['TASH118737'],'unsupported_location_withdrawn':['TASH115626'],'unresolved_with_new_background':['TASH069165','TASH074662'],'new_label_coordinate':['TASH076012'],'historical_and_additional_identifications_preserved':['TASH105672','TASH104219','TASH088398'],'full_sheet_name_recoveries':['TASH072195','TASH072215','TASH087131','TASH051980'],'pending_groups':len(pending),'pending_types':dict(Counter(v[0] for v in pending.values())),'after_quality_inference':'Do not apply old audit scores or corrected-sample success as new accuracy. New319 is a curated release; original audit metrics remain in weighted_quality_before_corrections.json.'}
content_ids={x['sample_id'] for x in changes if x['field']!='event_date' or x['before'] is not None}
summary['records_with_content_changes']=len(content_ids)
summary['content_changed_sample_ids']=sorted(content_ids)
summary['review_metadata_only_n']=60-len(content_ids)
save('results/curation_summary.json',summary)
flat=[]
for r in new_records:
    e=r.get('event_date') or {'start':r.get('catalogue_date_start'),'end':r.get('catalogue_date_end'),'source':'catalogue_only_not_reviewed','image_support':False}
    flat.append({'sample_id':r['sample_id'],'reviewed_this_round':r['sample_id'] in reviews,'scientific_name':r['scientific_name'],'locality':r['human_corrected_locality'],'collector':r['collector'],'event_date_start':e['start'],'event_date_end':e['end'],'event_date_source':e['source'],'event_date_image_supported':e['image_support'],'original_catalogue_start':r['catalogue_date_start'],'original_catalogue_end':r['catalogue_date_end'],'spatial_category':r['spatial_category'],'label_latitude':(r.get('label_coordinate') or {}).get('latitude'),'label_longitude':(r.get('label_coordinate') or {}).get('longitude'),'geographic_references':json.dumps(r['reference_points'],ensure_ascii=False),'administration':json.dumps(r['administration']['supported_units'],ensure_ascii=False),'remaining_review':'; '.join(r.get('unresolved_review_items',[]))})
csvout('derived/specimen_information_records_reviewed319.csv',flat)
print(json.dumps(summary,ensure_ascii=False))
