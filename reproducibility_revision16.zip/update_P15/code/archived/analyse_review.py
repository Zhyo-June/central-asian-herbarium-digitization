"""Score the frozen sample before applying any correction; audit historical use."""
import csv
import hashlib
import json
import math
import re
import shutil
import statistics
import sys
from collections import Counter
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')
OUT=Path(__file__).resolve().parents[1]
ROOT=OUT.parents[1]
OLD=OUT.with_name('quality_audit_20261024_01')
DS=Path(r'external_dataset/DataSet260817_delivery_20261008_01/dataset_v001')
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def jl(p): return [json.loads(s) for s in p.read_text(encoding='utf-8-sig').splitlines() if s.strip()]
def save(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def csvout(name,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

review_path=next((OUT/'inputs').glob('60*.json'))
history_path=next((OUT/'inputs').glob('49*.json'))
review=read(review_path);history=read(history_path);rows=review['records']
plan=read(OLD/'results/sampling_plan.json')
sample={x['sample_id']:x for x in read(OLD/'inputs/frozen_sample60.json')}
required=['scientific_name','locality','collector','date','spatial']
assert review['frozen_sample_sha256']==sha(OLD/'inputs/frozen_sample60.json')
assert len(rows)==len({r['sample_id'] for r in rows})==60 and set(sample)=={r['sample_id'] for r in rows}
assert all(all(r['answers'].get(f) for f in required) for r in rows)
assert all(r['source_text_sha256']==sample[r['sample_id']]['context']['corrected_sha256'] for r in rows)
N={s['category']:s['N'] for s in plan['strata']}
assert all(abs(r['design_weight']-sample[r['sample_id']]['design_weight'])<1e-10 for r in rows)
save('results/review_import.json',{'records':60,'unique_ids':60,'complete_primary_decisions':300,'source_hashes_match':True,'frozen_sample_matches':True,'reviewer':review['reviewer'],'review_sha256':sha(review_path),'history_confirmation_sha256':sha(history_path),'audit_scope':'User-confirmed review of final records; not a new blinded or two-reviewer study. Prior involvement is recorded as unknown.'})

def estimate(key,title,predicate,denominator_predicate=lambda r:True,known_denominator=319):
    numerator=sum(r['design_weight']*int(predicate(r)) for r in rows)
    denominator=known_denominator if known_denominator is not None else sum(r['design_weight']*int(denominator_predicate(r)) for r in rows)
    value=numerator/denominator
    variance=0
    for h,nh in N.items():
        rr=[r for r in rows if r['stratum']==h]
        yy=[int(predicate(r))-(value*int(denominator_predicate(r)) if known_denominator is None else 0) for r in rr]
        variance+=nh**2*(1-len(rr)/nh)*statistics.variance(yy)/len(rr)
    se=math.sqrt(variance)/denominator
    return {'key':key,'label':title,'sample_numerator':sum(predicate(r) for r in rows),'sample_denominator':sum(denominator_predicate(r) for r in rows),'weighted_numerator':numerator,'weighted_denominator':denominator,'percentage':100*value,'standard_error_percentage_points':100*se,'approx_95ci_percent':[100*max(0,value-1.96*se),100*min(1,value+1.96*se)],'estimator':'Stratified expansion (N_h/n_h), finite-population correction; normal approximation interval. Ratio linearization when denominator is estimated.'}

usable=lambda r,f:r['answers'][f] in ['correct','partial']
covered=lambda r:r['stratum']!='unresolved'
supported=lambda r:r['answers']['spatial']=='supported'
metrics=[
    estimate('spatial_precision','原有268份空间/行政结论中，声明角色与范围成立',supported,covered,268),
    estimate('spatial_supported_coverage','全319份具有审计支持的空间/行政信息',supported),
    estimate('spatial_coarsen','全319份需调整空间角色或放宽范围',lambda r:r['answers']['spatial']=='coarsen'),
    estimate('spatial_wrong','全319份地点身份/行政归属错误',lambda r:r['answers']['spatial']=='wrong'),
    estimate('spatial_insufficient','全319份现有空间结论证据不足',lambda r:r['answers']['spatial']=='insufficient'),
    estimate('locality_complete','产地完整正确',lambda r:r['answers']['locality']=='correct'),
    estimate('locality_usable','产地完整或部分可用',lambda r:usable(r,'locality')),
    estimate('name_complete','学名完整正确',lambda r:r['answers']['scientific_name']=='correct'),
    estimate('name_usable','全319份保留可靠学名信息（完整或部分）',lambda r:usable(r,'scientific_name')),
    estimate('name_valid_given_nonempty','已有非空学名输出的记录中，名称完整或部分可用',lambda r:usable(r,'scientific_name'),lambda r:bool(sample[r['sample_id']]['record']['scientific_name']),None),
    estimate('name_correct_empty','学名为空且整张标本无可恢复学名',lambda r:r['answers']['scientific_name']=='correct_empty'),
    estimate('name_missed','整张标本有学名但当前记录遗漏',lambda r:r['answers']['scientific_name']=='missed'),
    estimate('collector_complete','采集人完整正确',lambda r:r['answers']['collector']=='correct'),
    estimate('collector_usable','采集人完整或部分可用',lambda r:usable(r,'collector')),
    estimate('date_consistent','标签支持关联日期或相同原始精度区间',lambda r:r['answers']['date']=='consistent'),
    estimate('joint_name_space','可靠学名与已支持空间信息同时具备',lambda r:usable(r,'scientific_name') and supported(r)),
    estimate('joint_four','可靠学名、采集人、图文一致日期与已支持空间同时具备',lambda r:usable(r,'scientific_name') and usable(r,'collector') and r['answers']['date']=='consistent' and supported(r)),
    estimate('unresolved_missed','原未解决的51份中存在可补空间信息的比例',lambda r:r['answers']['spatial']=='missed_resolvable',lambda r:r['stratum']=='unresolved',51),
]
save('results/weighted_quality_before_corrections.json',metrics)
csvout('results/weighted_quality_before_corrections.csv',[{**m,'approx_95ci_percent':json.dumps(m['approx_95ci_percent'])} for m in metrics])
counts=[]
for field in required+['precision_gain']:
    for status,count in Counter(r['answers'][field] for r in rows).items():
        weight=sum(r['design_weight'] for r in rows if r['answers'][field]==status)
        counts.append({'field':field,'status':status,'sample_count':count,'sample_denominator':60,'weighted_count':weight,'weighted_percentage_of319':weight/319*100})
csvout('results/field_judgments_before_corrections.csv',counts)
strata=[]
for h,nh in N.items():
    rr=[r for r in rows if r['stratum']==h];c=Counter(r['answers']['spatial'] for r in rr)
    strata.append({'stratum':h,'population_n':nh,'sample_n':len(rr),'supported':c['supported'],'coarsen':c['coarsen'],'wrong':c['wrong'],'insufficient':c['insufficient'],'unresolved_supported':c['unresolved_supported'],'missed_resolvable':c['missed_resolvable'],'supported_percent':100*c['supported']/len(rr) if h!='unresolved' else None})
csvout('results/spatial_strata_before_corrections.csv',strata);save('results/spatial_strata_before_corrections.json',strata)
save('results/statistical_method.json',{'population':319,'unit':'specimen','sample':60,'seed':20261024,'strata':plan['strata'],'weight_formula':'N_h/n_h','quality_timepoint':'Frozen final records BEFORE current review corrections','variance_formula':'Var(p_hat)=sum_h[N_h^2(1-n_h/N_h)s_h^2/n_h]/D^2. For ratio estimands use residual y-p_hat*d.','interval':'Approximate 95% normal design-based interval with finite-population correction, clipped to [0,1]. Sparse error counts make intervals approximate; class census 13/13 is exact for those 13, not external generalization.','indeterminate':'Insufficient evidence is reported separately, not relabeled as error. Primary confirmed coverage excludes it; adding the unresolved covered-record weight gives a quality-evidence upper endpoint, not a confidence bound.','field_missingness':'Correct_empty is a correct abstention, not a recovered scientific name. Partial is usable partial information, not complete transcription.','pre_post_separation':'Correction outcomes are new curated data; they are not new independently measured accuracy, and corrected sample success is not reweighted to claim automatic improvement on the 259 unreviewed records.'})

sources=[]
def remember(p):
    sources.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
for p in [review_path,history_path,OLD/'inputs/frozen_sample60.json',OLD/'results/sampling_plan.json']:
    remember(p)
base_path=ROOT/'16_paper/revision_20261023_14_zh/release/derived/specimen_information_records.jsonl'
shutil.copy2(base_path,OUT/'inputs/baseline_specimen_information_records.jsonl');remember(base_path)
geo_path=ROOT/'11_rag/geographic_resolution_20261023_04/results/spatial_records_paired.jsonl'
base_geo=[r for r in jl(geo_path) if r['input_version']=='human_corrected']
(OUT/'inputs/baseline_spatial_records_human_corrected.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in base_geo),encoding='utf-8');remember(geo_path)

# Revisit primary historical records and distinguish two different 49-specimen splits.
split_rows=list(csv.DictReader((DS/'splits.csv').open(encoding='utf-8-sig')))
final_ids={r['specimen_id'] for r in split_rows if r['split']=='final-test'}
dev_ids={r['specimen_id'] for r in split_rows if r['split']=='dev-test'}
remember(DS/'splits.csv')
roster_checks={'final49_vs_dev49':sorted(final_ids&dev_ids)}
for split in ['train','val','dev-test']:
    p=ROOT/f'08_ocr_baseline/paddle_finetune_20261012_01/data/{split}.jsonl';remember(p)
    text=p.read_text(encoding='utf-8');roster_checks['paddle_'+split]=sorted(final_ids&set(re.findall(r'TASH\d+',text)))
for key,rel in [('formal_yolo','17_validation/independent_20261018_01/experiments/YOLO_formal_01/train347_val50.sources.jsonl'),('legacy_OCR820','17_validation/independent_20261018_01/exposure/old_OCR820_full_image_trace.csv'),('legacy_training_folder999','17_validation/independent_20261018_01/exposure/training_folder_context_exclusion.csv'),('legacy_overlap21','17_validation/independent_20261018_01/exposure/historical_overlap21.csv'),('current319','16_paper/revision_20261023_14_zh/release/derived/specimen_information_records.jsonl')]:
    p=ROOT/rel;remember(p);roster_checks[key]=sorted(final_ids&set(re.findall(r'TASH\d+',p.read_text(encoding='utf-8-sig'))))
ledger=ROOT/'17_validation/independent_20261018_01/exposure/exposure_evidence.csv';remember(ledger)
exposure=[r for r in csv.DictReader(ledger.open(encoding='utf-8-sig')) if r['specimen_id'] in final_ids]
exposure_counts=Counter((r['stage'],r['exposure_type'],r['split']) for r in exposure)
save('results/historical49_roster_recheck.json',{'final_n':49,'dev_n':49,'intersections':roster_checks,'earlier_exposure_registry_matches':[{'stage':k[0],'type':k[1],'split':k[2],'rows':v} for k,v in exposure_counts.items()]})

timeline_specs=[
    ('2026-10-08','原始495份正式划分，dev-test和final-test是两组不同的49份','00_admin/change_log.md',r'P03-PRE-004|final.test.*隔离|四个 split|495/495 OK'),
    ('2026-10-09','V7使用final-test完成253行OCR测试；训练加载器仍为train/val/dev','logs/p08_closure_record.md',r'final.test|253|2026-10-09'),
    ('2026-10-11','后续方向修复与OCR开发使用dev-test 49份','logs/p05_review_20261011_01/review_report.md',r'dev.test|final.test|256'),
    ('2026-10-12','Paddle训练不打包final-test，参数与模型按val CER选择','logs/paddle_finetune_20261012_01.md',r'不打包final|参数和checkpoint|final.test不|按val选择|未上传或推理final'),
    ('2026-10-12','Paddle路线对照在另一组49份开发材料上进行','logs/p07_routes_20261012_01.md',r'49签|final.test'),
    ('2026-10-12','早期RAG导入明确排除49份final-test的编目记录','logs/p10_field_rag_20261012_01.md',r'排除49|保护ID|final.test'),
    ('2026-10-16','P11/P13/P14开发没有新增final-test推理；历史V7使用已披露','logs/p11_p14_completion_20261016_01.md',r'final.test|独立六字段|49张'),
    ('2026-10-18','独立材料审计保留历史暴露记录与两组49份的区别','17_validation/independent_20261018_01/exposure/summary.json',r'final.test|dev.test|historical_overlap21|training_context_unique'),
]
timeline=[]
for date,conclusion,rel,pattern in timeline_specs:
    p=ROOT/rel;remember(p)
    lines=p.read_text(encoding='utf-8-sig').splitlines()
    evidence=[{'line':i,'text':line} for i,line in enumerate(lines,1) if re.search(pattern,line,re.I)]
    timeline.append({'date':date,'conclusion':conclusion,'source':str(p),'sha256':sha(p),'evidence_lines':evidence})
for rel in ['tool/train_trocr_v7.py','08_ocr_baseline/paddle_finetune_20261012_01/selection.json','16_paper/evidence_20261016_01/report_01/final_test_usage_ledger.json','13_review/prepaper_human_workpack_20261016_01/delivery_receipt.json']:
    remember(ROOT/rel)
save('results/historical49_timeline.json',timeline)
hist=read(OLD/'results/final_test49_audit.json')
hist.update({'author_confirmation':history,'history_rechecked_this_round':True,'timeline_file':'historical49_timeline.json','additional_legacy_training_membership':roster_checks,'current_rag_rechecked':read(OUT/'results/current_reference49_record_recheck.json'),'eligibility_decision':'eligible_for_frozen_current_system_validation_as_previously_evaluated_same_source_holdout','eligible_for_current_frozen_evaluation':history['answer']=='no_later_tuning' and not any(roster_checks.values()),'eligible_as_never_used_blind_external_set':False,'conclusion_zh':'结合历史记录与作者确认，49份可以开展当前冻结流程的历史留出队列验证；它们独立于本轮319份和已检查的开发/训练样本，但不是从未使用的盲测集或外部馆藏验证集。','still_needed_before_performance_claim':['固定待评估的具体模型、提示词、地名库、规则和输入范围；先锁定后运行。','在不显示当前模型答案的条件下，利用原图与已有253行转录建立字段及空间参考；对歧义作独立核对。','以原始图像或预先声明的裁图输入当前系统，检索排除本样本编目答案；报告49份的实际结果。'],'not_run_this_round':'No new49 model inference or field/spatial performance measurement.'})
hist.pop('human_questions',None);hist.pop('decision',None)
save('results/historical49_eligibility_updated.json',hist)
save('inputs/analysis_source_manifest.json',list({s['path']:s for s in sources}.values()))
print(json.dumps({'review_imported':60,'weighted_metrics':{m['key']:round(m['percentage'],3) for m in metrics},'historical49_eligible_for_frozen_validation':hist['eligible_for_current_frozen_evaluation'],'legacy_intersections':roster_checks},ensure_ascii=False))
