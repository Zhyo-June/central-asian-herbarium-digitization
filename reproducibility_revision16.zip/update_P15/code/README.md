# Archived P15 quality-analysis implementations used by P16

`archived/analyse_review.py` and `archived/apply_review.py` preserve the existing quality-analysis and correction implementations. Their original algorithms and integrity assertions are retained. The source paths require local configuration.

In the original project both scripts were under `17_validation/quality_audit_20261024_02/code/`. `OUT` therefore resolved to the phase-02 audit directory, `ROOT` to the project, and `OLD` to `quality_audit_20261024_01`. Before a rerun, restore the original layout and provide original input artifacts and external dependencies. Paths beginning with `project/` or `external_dataset/` are provenance labels requiring configuration.

| Original input | Location in this archive |
| --- | --- |
| phase 01 `inputs/frozen_sample60.json` | `update_P15/quality_audit/frozen_sample60.json` |
| phase 01 `inputs/review60_evidence.json` | `update_P15/quality_audit/review60_evidence.json` |
| phase 01 `results/sampling_plan.json` | `update_P15/quality_audit/sampling_plan.json` |
| phase 02 60-specimen review | `update_P15/quality_audit/60份最终记录_质量核查_20261024015135.json` |
| phase 02 49-specimen use confirmation | `update_P15/historical49/49份历史测试_用途确认_1792777758660.json` |
| phase 02 frozen baseline specimen and spatial records | `update_P15/baseline/baseline_specimen_information_records.jsonl` and `baseline_spatial_records_human_corrected.jsonl` |
| Original external split roster | `update_P15/historical49/splits.csv` (released copy) |
| Frozen paired geography | `baseline_P12/geography/spatial_records_paired.jsonl` |
| Additional training/exposure rosters, original logs and phase-01 historical audit | Recorded in `update_P15/quality_audit/analysis_source_manifest.json`; not all upstream inputs are redistributed. Existing saved recheck outputs are in `update_P15/historical49/`. |

The code checks SHA-256 values of original frozen inputs. Portable-path substitutions can change a released file hash. Consult `SOURCE_FILES.csv` at the package root for original and released hashes, and supply the original input bytes when using the original integrity assertions. Saved estimates and correction records are available directly in `update_P15/quality_audit/`.
