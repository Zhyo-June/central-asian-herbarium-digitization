# Baseline research records

This directory contains the saved extraction, retrieval, review, geography and resource-curation records used as the historical baseline of P16. Current reviewed specimen and spatial records are in `../update_P15/derived/`.

Use `../docs/EVIDENCE_MAP.md` for the P16 main-text and supplementary table numbering, and `docs/DATA_DICTIONARY.md` for the baseline field definitions. Current figure files are in `../figures_P16/`.

From this directory, `python code/export_tables.py` exports descriptive tables from the saved baseline results. Archived research pipelines require the original source holdings, project layout and configuration. Source versions and terms are recorded in `sources/source_license_register.csv` and `sources/source_registry.json`.
