"""Reuse frozen scores and submitted annotations; never invoke a model."""
import math
from collections import Counter
from datetime import datetime, timezone
from .common import *


def wilson(k, n):
    z = 1.959963984540054
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    radius = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return max(0., centre - radius), min(1., centre + radius)


def main():
    scores = rows(OLD / "evaluation/per_field_counts.csv")
    old = read(OLD / "evaluation/summary.json")
    ratings = rows(HUMAN / "human_method_ratings.csv")
    human_old = read(HUMAN / "summary.json")
    primary = [r for r in ratings if r["role"] == "primary"]
    assert len(scores) == 319 * 6 * 3 and len(primary) == 50 * 6 * 3
    assert len({(r["sample_id"], r["arm_alias"], r["field"]) for r in scores}) == len(scores)
    assert len({(r["sample_id"], r["arm"], r["field"]) for r in primary}) == len(primary)
    automatic, per_item, human, eligibility = [], [], [], []
    for field in FIELDS:
        members = {r["sample_id"]: r for r in primary
                   if r["field"] == field and r["arm"] == "A"}
        ids = {sid for sid, r in members.items() if r["initial_visibility"] == "readable"}
        for sid, r in sorted(members.items()):
            eligibility.append({
                "sample_id": sid, "field": field,
                "initial_R1_visibility": r["initial_visibility"],
                "eligible_readable": sid in ids,
                "reviewer_amendment": r["amendment"]
            })
        for arm, method in METHODS.items():
            sr = [r for r in scores if r["arm_alias"] == arm and r["field"] == field]
            known = [r for r in sr if r["reference_known"] == "True"]
            m = sum(int(r["M"]) for r in known)
            nr = sum(int(r["Nref"]) for r in known)
            c85 = sum(r["field_pass"] == "True" for r in known)
            c80 = sum(r["status"] == "ok" and float(r["field_similarity"]) >= .80
                      for r in known) if field == "locality" else c85
            if field == "locality":
                assert c85 == sum(r["status"] == "ok" and float(r["field_similarity"]) >= .85
                                  for r in known)
            previous = old["metrics"]["output_stream"][method][field]
            assert (m, nr, c85, len(known)) == (
                previous["M"], previous["Nref"], previous["pass_count"], previous["n"])
            automatic.append({
                "arm": arm, "method": method, "field": field,
                "N_specimens": 319, "reference_known_n": len(known),
                "M": m, "Nref": nr, "coverage_percent": 100*m/nr,
                "pass_080_n": c80, "pass_080_percent": 100*c80/len(known),
                "pass_085_n": c85, "pass_085_percent": 100*c85/len(known),
                "added_passes_080": c80-c85,
                "threshold_applies": field == "locality",
                "rule": "normalized_locality_Levenshtein" if field == "locality"
                        else "unchanged_scientific_core" if field == "scientific_name"
                        else "unchanged_collector_word_multiset",
            })
            for r in sr:
                ok85 = r["field_pass"] == "True"
                ok80 = (r["reference_known"] == "True" and r["status"] == "ok"
                        and float(r["field_similarity"]) >= .80) if field == "locality" else ok85
                per_item.append(r | {"pass_080": ok80, "pass_085": ok85,
                                     "newly_passes_080": ok80 and not ok85})
            selected = [r for r in primary if r["arm"] == arm and r["field"] == field
                        and r["sample_id"] in ids]
            assert {r["sample_id"] for r in selected} == ids
            assert all(r["initial_visibility"] == "readable" for r in selected)
            counts = Counter(r["grade"] for r in selected)
            n = len(selected)
            k = counts["correct"] + counts["partial"]
            lo, hi = wilson(k, n)
            human.append({
                "arm": arm, "method": method, "field": field,
                "reviewer": "R1", "selection": "initial_image_first_readable",
                "audited_specimens": 50, "readable_n": n,
                **{g: counts[g] for g in GRADES},
                "confirmed_n": k, "confirmed_percent": 100*k/n,
                "wilson_ci95_low_percent": 100*lo,
                "wilson_ci95_high_percent": 100*hi,
                "readable_fraction_percent": 100*n/50,
            })
    paired = []
    for r in automatic:
        h = next(h for h in human if (h["arm"], h["field"]) == (r["arm"], r["field"]))
        paired.append(r | {f"human_{k}": v for k, v in h.items()
                            if k not in ("arm", "method", "field")})
    # Later comments are not used to rewrite the pre-output eligibility snapshot.
    # Excluding their three collector visibility downgrades is a transparent sensitivity.
    downgraded = {"TASH066020", "TASH070653", "TASH074253"}
    amendment_sensitivity = []
    for arm, method in METHODS.items():
        selected = [r for r in primary if r["field"] == "collector" and r["arm"] == arm
                    and r["initial_visibility"] == "readable" and r["sample_id"] not in downgraded]
        c = Counter(r["grade"] for r in selected)
        k, n = c["correct"] + c["partial"], len(selected)
        amendment_sensitivity.append({"arm": arm, "method": method, "field": "collector",
                                      "n": n, "correct": c["correct"], "partial": c["partial"],
                                      "confirmed_n": k, "confirmed_percent": 100*k/n})
    inputs = [OLD / "evaluation/per_field_counts.csv", OLD / "evaluation/summary.json",
              HUMAN / "human_method_ratings.csv", HUMAN / "summary.json",
              HUMAN / "validation.json", AUDIT / "protocol.json",
              AUDIT / "admin/sampling_manifest.json", AUDIT / "admin/blind_key.json",
              *sorted((AUDIT / "output").glob("*.json"))]
    manifest = {rel(p): sha(p) for p in inputs}
    protocol = {
        "version": "graded_recovery_v1", "created_at": datetime.now(timezone.utc).isoformat(),
        "requested_by_author_after_review": True,
        "automatic_population": 319,
        "coverage": "unchanged revision07 NFC-only continuous-span Q0 alignment; sum(M)/sum(Nref); concatenate three actual label_text fields",
        "automatic_pass": {
            "locality": "status ok and 1-Levenshtein/max_normalized_length >= t; t=0.80 and 0.85",
            "normalization": "NFC, casefold, ё to е, alphanumeric only (reuse saved similarity)",
            "scientific_name": "unchanged exact botanical core, qualifiers retained, authors ignored",
            "collector": "unchanged multiset of remaining name words after initials/labels removed",
            "failure": "retained as nonpass", "empty_reference": "excluded from that field denominator",
            "threshold_085": "original prereun field criterion", "threshold_080": "post-hoc author-requested sensitivity"
        },
        "human": {
            "selection": "R1 initial image-first snapshot visibility==readable; independently fixed for each field",
            "numerator": "correct+partial within the selected readable subset",
            "denominator": "all selected readable specimen-fields; identical membership across A-F",
            "other_grades": "retained in denominator without confirmation; unassessable is not asserted to be wrong",
            "state": "R1 primary; R2 disagreements not adjudicated",
            "definition_timing": "complete+partial endpoint and readable-only restriction requested post hoc",
            "uncertainty": "95% Wilson intervals for a conditional binary endpoint; no method-independence or generalization claim",
            "geographic_resolution": "not measured by these grades; partial does not guarantee a correct place name or administrative level"
        },
        "new_model_calls": 0, "new_tokens": 0, "new_api_cost_usd": 0,
        "inputs_sha256": manifest,
    }
    summary = {
        "protocol": protocol, "automatic": automatic, "human": human,
        "collector_amendment_sensitivity": amendment_sensitivity,
        "initial_readability_counts": {
            f: dict(Counter(r["initial_visibility"] for r in primary
                            if r["field"] == f and r["arm"] == "A")) for f in FIELDS},
        "legacy_strict_visible": [r for r in human_old["human_rates"] if r["subset"] == "initial_visible"],
        **{k: human_old[k] for k in [
            "visibility_counts", "absence_scope_counts", "reliability", "rag_change_counts",
            "rag_evidence_counts", "rag_E_grade_counts", "rag_F_grade_counts",
            "reviewer_amendments", "issue_counts", "issue_specimens", "issue_field_groups"]},
    }
    for name, data in [
        ("automatic_summary.csv", automatic), ("human_readable_summary.csv", human),
        ("metrics_side_by_side.csv", paired), ("per_specimen_field_metrics.csv", per_item),
        ("human_eligibility.csv", eligibility),
        ("collector_amendment_sensitivity.csv", amendment_sensitivity),
        ("legacy_strict_visible.csv", summary["legacy_strict_visible"]),
    ]:
        write_csv(OUT / "evaluation" / name, data)
    save(OUT / "evaluation/summary.json", summary)
    save(OUT / "protocol.json", protocol)
    save(OUT / "source_manifest.json", manifest)
    print(json.dumps({"automatic_locality": [r for r in automatic if r["field"] == "locality"],
                      "human_denominators": {f: next(r["readable_n"] for r in human if r["field"] == f) for f in FIELDS},
                      "collector_later_comment_sensitivity": amendment_sensitivity},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
