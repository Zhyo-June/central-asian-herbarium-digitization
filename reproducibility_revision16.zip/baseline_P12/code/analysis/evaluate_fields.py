"""Apply the byte-frozen revision07 alignment to saved A-F output text.

No model calls, corrections, reference-driven assembly or changes to H scores.
The common source is the actual three-field output stream, not a retrospectively
invented full-label transcription. Same-field coverage is a separate diagnostic.
"""
from concurrent.futures import ProcessPoolExecutor
from functools import lru_cache
from collections import Counter
import csv
import json
import runpy
import time
import unicodedata
from .common import *

FROZEN = EXPERIMENTS / "D_TASH_excel_recovery_01/alignment_owner/candidate_03/align_saved_ocr.py"
FROZEN_SHA = "7f3a5434a2e169cea757093e466c4d914ee3af63afd9b6445de04080bd47b605"
_dp = None


@lru_cache(maxsize=24000)
def align(reference, source):
    global _dp
    if _dp is None:
        assert sha(FROZEN) == FROZEN_SHA
        _dp = runpy.run_path(str(FROZEN), run_name="revision07_frozen")["local_alignment"]
    units = [dict(char=c, route_order_index=0, route_order_end_index=0) for c in source]
    best, columns = _dp(reference, units)
    runs = []
    for col in columns:
        if not runs or runs[-1]["op"] != col["op"]:
            runs.append({"op": col["op"], "reference": "", "prediction": ""})
        runs[-1]["reference"] += col["reference_char"]
        runs[-1]["prediction"] += col["prediction_char"]
    return {"Nref": len(reference), "M": best.M, "S": best.S, "D": best.D, "I": best.I,
            "score": best.score, "start": best.start, "end": best.end,
            "selected_text": source[best.start:best.end], "operations": runs,
            "coverage": best.M / len(reference) if reference else None}


def evaluate_one(row):
    results = []
    for arm, method in METHODS.items():
        response = row["arms"][arm]
        usable = response["status"] == "ok"
        strings = {f: unicodedata.normalize("NFC", response.get("fields", {}).get(f, {}).get("label_text", ""))
                   if usable else "" for f in FIELDS}
        stream = "".join(strings.values())
        # Zero synthetic separators, as in revision07. NFC is per stored field.
        assert unicodedata.normalize("NFC", stream) == stream
        offsets, start = {}, 0
        for field, text in strings.items():
            offsets[field] = [start, start + len(text)]
            start += len(text)
        for field in FIELDS:
            reference = unicodedata.normalize("NFC", row["reference"]["fields"][field]["value"] or "")
            common = {
                "sample_id": row["sample_id"], "split": row["split"], "presence_label": row["presence_label"],
                "arm_alias": arm, "method": method["id"], "field": field, "status": response["status"],
                "reference": reference, "label_text": strings[field], "stream": stream,
                "field_offsets": offsets, "reference_known": bool(reference),
                "field_pass": row["scores"][arm][field]["pass"],
                "field_similarity": row["scores"][arm][field]["similarity"],
            }
            common["output_stream"] = align(reference, stream)
            common["same_field"] = align(reference, strings[field])
            results.append(common)
    return results


def summarize(rows):
    summary = {}
    for scope in ("output_stream", "same_field"):
        summary[scope] = {}
        for arm, method in METHODS.items():
            fields = {}
            for f in FIELDS:
                selected = [r for r in rows if r["arm_alias"] == arm and r["field"] == f and r["reference_known"]]
                counts = {k: sum(r[scope][k] for r in selected) for k in ("M", "S", "D", "I", "Nref")}
                nref = counts["Nref"]
                fields[f] = {**counts, "n": len(selected), "coverage_percent": 100*counts["M"]/nref if nref else None,
                             "pass_count": sum(r["field_pass"] for r in selected),
                             "pass_percent": 100*sum(r["field_pass"] for r in selected)/len(selected) if selected else None}
            summary[scope][method["id"]] = fields
    return summary


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def main():
    start = time.perf_counter()
    OUT.mkdir(exist_ok=True)
    rows = read(SOURCE / "evaluation/per_specimen.json")
    previous = read(SOURCE / "evaluation/summary.json")
    assert len(rows) == 319 and len({r["sample_id"] for r in rows}) == 319
    protected_paths = [FROZEN, LEGACY/"full319_01/per_column_summary.json",
                       SOURCE/"evaluation/summary.json", SOURCE/"evaluation/per_specimen.json",
                       SOURCE/"cost/cost_audit.json", SOURCE/"review/index.html",
                       ROOT/"outputs/full319_metrics_20261020_01/全量319份_ABCDEF评测与成本.xlsx"]
    protected_paths += sorted((SOURCE/"results").glob("*.json"))
    protected_paths += [p for p in (ROOT/"16_paper/revision_20261019_07").rglob("*")
                        if p.is_file() and "__pycache__" not in p.parts]
    protected = {str(p.relative_to(ROOT)): sha(p) for p in protected_paths}
    save(OUT/"protected_sources.json", protected)
    save(OUT/"methods.json", {"current": METHODS, "historical": LEGACY_METHODS})
    protocol = {
        "version": "unified319_revision07_alignment_v1", "n": 319,
        "algorithm": str(FROZEN.relative_to(ROOT)), "algorithm_sha256": FROZEN_SHA,
        "normalization": "NFC only; retain case, punctuation, spaces and newlines",
        "objective": "max Q0=2M-S-D-I, entire reference versus one continuous source span; free source ends",
        "tie_order": "frozen revision07: score, span length, edits, start; M/S before D before I before empty",
        "block_penalty": 0, "coverage": "sum(M)/sum(Nref); Nref=M+S+D; not mean specimen coverage",
        "primary_source": "output_stream: concatenate actual label_text in scientific_name,locality,collector order with no added characters",
        "source_scope_boundary": "Only three target fields were saved for A-F. This is output-text coverage under the revision07 algorithm, not full-label OCR coverage.",
        "secondary_source": "same_field: apply identical alignment to the corresponding label_text only",
        "no_other_text": "No raw OCR, normalized_candidate, reason, retrieval evidence or other arm output is appended to A-F.",
        "failure_policy": "Keep all 319; failed arm has empty source and all reference characters deleted",
        "missing_reference": "Exclude reference-empty field only; no empty-empty reward",
        "denominators": "scientific_name319/locality319/collector314; same denominators across all methods",
        "visibility": "Full cohort primary; common image-screen-present174 subset is secondary and not human gold.",
        "field_pass_rule": "Reuse H scores unchanged, including the fixed locality>=0.85 threshold",
        "legacy_baselines": "OCR-Historical=old D and OCR-Repaired=old E; reuse F full319_01 whole-label scores and verify Nref",
        "status": "Post-hoc descriptive secondary metric requested after field results; no fresh blind test",
        "paid_calls": 0, "new_model_tokens": 0,
    }
    save(OUT/"protocol.json", protocol)
    all_scores = []
    with ProcessPoolExecutor(max_workers=4) as pool:
        for i, evaluated in enumerate(pool.map(evaluate_one, rows, chunksize=4), 1):
            all_scores.extend(evaluated)
            if i % 40 == 0:
                print(f"Scored {i}/319 specimens in {time.perf_counter()-start:.1f}s", flush=True)
    save(OUT/"evaluation/per_field.json", all_scores)
    legacy = read(LEGACY/"full319_01/per_column_summary.json")
    if isinstance(legacy, dict):
        print("Legacy summary keys", list(legacy), flush=True)
        legacy = legacy["summaries"]
    fields_map = {"AE": "scientific_name", "L": "locality", "F": "collector"}
    historical = [{**r, "method": LEGACY_METHODS[r["system"]], "field": fields_map[r["column_key"]]}
                  for r in legacy if r["population"] == "all319" and r["system"] in LEGACY_METHODS and r["version"] == "nfc_raw"]
    summary = {"n": 319, "methods": METHODS, "metrics": summarize(all_scores), "historical": historical,
               "groups": {split: summarize([r for r in all_scores if r["split"] == split])
                          for split in ("development", "reserve_train", "locked_test")},
               "name_present_image_screen": summarize([r for r in all_scores if r["presence_label"] == "present"]),
               "prior_field_summary": previous, "protocol": protocol}
    for a, method in METHODS.items():
        for f in FIELDS:
            s = summary["metrics"]["output_stream"][method["id"]][f]
            h = previous["metrics"]["all_reference_known"][a][f]
            assert (s["n"], s["pass_count"]) == (h["n"], h["correct"])
            for baseline in historical:
                if baseline["field"] == f:
                    assert baseline["Nref"] == s["Nref"]
    assert len(historical) == 6
    save(OUT/"evaluation/summary.json", summary)
    flat = [{"method": METHODS[a]["id"], "old_alias": a, "field": f,
             **summary["metrics"]["output_stream"][METHODS[a]["id"]][f],
             "same_field_M": summary["metrics"]["same_field"][METHODS[a]["id"]][f]["M"],
             "same_field_coverage_percent": summary["metrics"]["same_field"][METHODS[a]["id"]][f]["coverage_percent"]}
            for a in METHODS for f in FIELDS]
    write_csv(OUT/"evaluation/paired_metrics.csv", flat)
    detail = [{k: r[k] for k in ("sample_id", "split", "presence_label", "method", "arm_alias", "field", "status", "reference_known", "field_pass", "field_similarity")} |
              {k: r["output_stream"][k] for k in ("M", "S", "D", "I", "Nref", "coverage")} |
              {"same_field_M": r["same_field"]["M"], "same_field_coverage": r["same_field"]["coverage"]}
              for r in all_scores]
    write_csv(OUT/"evaluation/per_field_counts.csv", detail)
    changed = [p for p, h in protected.items() if sha(ROOT/p) != h]
    assert not changed, changed
    receipt = {"status": "passed", "specimens": 319, "field_records": len(all_scores),
               "scopes": ["output_stream", "same_field"], "protected_files": len(protected),
               "protected_files_changed": changed, "old_field_scores_unchanged": True,
               "legacy_and_current_denominators_identical": True,
               "seconds": time.perf_counter()-start, "new_model_calls": 0, "new_tokens": 0,
               "additional_api_cost_usd": 0, "prior_cost_sha256": sha(SOURCE/"cost/cost_audit.json")}
    save(OUT/"evaluation/receipt.json", receipt)
    print(json.dumps({"receipt": receipt, "metrics": flat}, ensure_ascii=True), flush=True)


if __name__ == "__main__":
    main()
