"""Analyse submitted human annotations only; never call models or modify inputs."""
from __future__ import annotations

import csv
import hashlib
import html
import json
import math
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
EXP = ROOT / "17_validation/independent_20261018_01/experiments"
J = EXP / "J_human_audit_20261020_01"
H = EXP / "H_full319_rag_20261020_01"
I = EXP / "I_unified319_evaluation_20261020_01"
OUT = J / "analysis_20261020_01"
HERE = Path(__file__).parent
FIELDS = ("scientific_name", "locality", "collector")
FIELD_NAMES = dict(zip(FIELDS, ("学名", "采集地", "采集人")))
ARMS = tuple("ABCDEF")
GRADES = ("correct", "partial", "incorrect", "unassessable", "correct_empty", "technical_failure")
GRADE_NAMES = dict(zip(GRADES, ("完整正确", "部分正确", "错误", "无法判断", "正确留空", "技术失败")))
PRESENCE = ("readable", "partial", "unreadable", "absent", "uncertain", "technical")
PRESENCE_NAMES = dict(zip(PRESENCE, ("清楚可读", "部分可读", "存在但不可读", "输入裁图未见", "是否存在不确定", "输入技术问题")))
CHANGE_NAMES = {
    "real_correction": "实质修正", "introduced_error": "引入错误", "mixed": "有修正也有损害",
    "writing_only": "仅书写或格式变化", "no_clear_gain": "无明确收益", "unassessable": "无法判断",
}
SUPPORT_NAMES = {
    "supports": "充分支持", "partial": "部分支持", "not_support": "不支持",
    "no_evidence": "无相应证据", "uncertain": "不确定",
}
VISIBLE = {"readable", "partial"}
BOOTSTRAPS = 10000
BOOTSTRAP_SEED = 2026102005


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_csv(name, rows):
    assert rows, name
    with (OUT / name).open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def payload(report_id):
    text = (J / "review" / f"{report_id}.html").read_text(encoding="utf-8")
    return json.loads(re.search(r'<script type="application/json" id="dataset">(.*?)</script>', text, re.S)[1])


def wilson(correct, n):
    if not n:
        return [None, None]
    z = 1.959963984540054
    p = correct / n
    scale = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / scale
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / scale
    return [max(0, centre - half), min(1, centre + half)]


def first_visibility(record, field):
    return record["snapshots"]["image_first"]["answers"][f"initial.{field}.visibility"]


def agreement(matrices, sampled_indices):
    total = matrices.sum(axis=0)

    def calculate(array):
        n = array.sum(axis=(-1, -2))
        po = np.trace(array, axis1=-2, axis2=-1) / n
        pe = (array.sum(axis=-1) * array.sum(axis=-2)).sum(axis=-1) / (n * n)
        # Kappa is undefined for a bootstrap draw with only one shared category.
        kappa = np.divide(po - pe, 1 - pe, out=np.full_like(po, np.nan), where=pe < 1)
        return po, kappa

    po, kappa = calculate(total)
    sampled = matrices[sampled_indices].sum(axis=1)
    boot_po, boot_kappa = calculate(sampled)
    return {
        "specimens": len(matrices), "unique_candidates": int(total.sum()),
        "agreements": int(np.trace(total)), "disagreements": int(total.sum() - np.trace(total)),
        "agreement": float(po), "kappa_unweighted": float(kappa),
        "agreement_ci95_cluster_percentile": np.quantile(boot_po, [0.025, 0.975]).tolist(),
        "kappa_ci95_cluster_percentile": np.nanquantile(boot_kappa, [0.025, 0.975]).tolist(),
        "defined_kappa_bootstraps": int(np.isfinite(boot_kappa).sum()),
        "confusion_matrix": total.tolist(), "grade_order": list(GRADES),
    }


def analyse():
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = read(J / "protocol.json")
    key = read(J / "admin/blind_key.json")
    methods = key["methods"]
    frozen = read(H / "evaluation/per_specimen.json")
    by_id = {r["sample_id"]: r for r in frozen}
    assert len(by_id) == 319
    reports = {}
    sources = {}
    checks = []
    amendments = []
    for meta in protocol["reports"]:
        report_id = meta["report_id"]
        files = list((J / "output").glob(report_id + "_*.json"))
        assert len(files) == 1, (report_id, "Choose one frozen submission explicitly", files)
        source = files[0]
        submitted = read(source)
        page = payload(report_id)
        recompute = dict(page)
        del recompute["dataset_digest"]
        expected_digest = hashlib.sha256(json.dumps(recompute, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
        assert expected_digest == submitted["dataset_digest"] == meta["dataset_digest"]
        assert submitted["schema"] == page["schema"] == "p22_review_v1"
        assert submitted["role"] == meta["role"]
        cases = {c["id"]: c for c in page["cases"]}
        assert set(submitted["records"]) == set(cases)
        assert len(cases) == meta["n"] == submitted["completed_n"]
        role = meta["role"]
        for sid, record in submitted["records"].items():
            ans, snapshots = record["answers"], record["snapshots"]
            if role in ("primary", "secondary"):
                assert snapshots["image_first"]["at"] <= snapshots["reference_check"]["at"]
                for field in FIELDS:
                    assert first_visibility(record, field) in PRESENCE
                    assert ans[f"reference.{field}.relation"]
                    actual = {k for k in ans if k.startswith(f"rating.{field}.") and k.endswith(".grade")}
                    expected = {f"rating.{field}.{c['code']}.grade" for c in cases[sid]["candidates"][field]}
                    assert actual == expected, (sid, field)
                    assert sorted(a for arms in key["key"][role][sid][field].values() for a in arms) == list(ARMS)
                    for candidate in cases[sid]["candidates"][field]:
                        code = candidate["code"]
                        grade = ans[f"rating.{field}.{code}.grade"]
                        valid = ({"technical_failure", "unassessable"} if not candidate["available"] else
                                 {"correct", "partial", "incorrect", "unassessable"} if candidate["text"] else
                                 {"incorrect", "unassessable", "correct_empty"})
                        assert grade in valid, (sid, field, code, grade)
                        for arm in key["key"][role][sid][field][code]:
                            frozen_arm = by_id[sid]["arms"][arm]
                            available = frozen_arm["status"] == "ok"
                            value = frozen_arm.get("fields", {}).get(field, {}).get("label_text") or ""
                            assert candidate == {"code": code, "text": value if available else "", "available": available}
                grading_events = [e["at"] for e in record["events"] if e["key"].startswith("rating.")]
                assert grading_events and min(grading_events) >= snapshots["reference_check"]["at"]
                for name in ("image_first", "reference_check"):
                    assert all(ans.get(k) == v for k, v in snapshots[name]["answers"].items())
                if ans.get("amendment"):
                    amendments.append({"sample_id": sid, "role": role, "note": ans["amendment"]})
            elif role == "visibility":
                assert ans["presence"] in PRESENCE and ans["input_quality"]
                if ans["presence"] in {"absent", "technical"}:
                    assert snapshots["full_sheet_opened"] and ans["full_sheet_presence"] != "not_needed"
                if "full_sheet_opened" in snapshots:
                    assert snapshots["full_sheet_opened"]["answers"]["presence"] == ans["presence"]
            else:
                assert ans["before.grade"] in GRADES and ans["after.grade"] in GRADES
                assert ans["change"] in CHANGE_NAMES and ans["evidence_support"] in SUPPORT_NAMES
                assert snapshots["evidence_opened"]
        reports[role] = {"submission": submitted, "cases": cases}
        sources[str(source.relative_to(ROOT))] = sha(source)
        checks.append({
            "report_id": report_id, "role": role, "completed": len(cases),
            "dataset_fingerprint_matches": True, "sample_ids_match": True,
            "required_answers_present": True, "reviewer": submitted["reviewer"],
            "browser_active_seconds": round(sum(r.get("active_seconds", 0) for r in submitted["records"].values()), 3),
        })

    # Verify that the submissions still refer to the original frozen experiment.
    frozen_hashes = {str((J / "protocol.json").relative_to(ROOT)): sha(J / "protocol.json"),
                     str((J / "admin/blind_key.json").relative_to(ROOT)): sha(J / "admin/blind_key.json"),
                     str((I / "evaluation/per_field_counts.csv").relative_to(ROOT)): sha(I / "evaluation/per_field_counts.csv")}
    for relative, expected in protocol["sources"].items():
        assert sha(ROOT / relative) == expected, relative
        frozen_hashes[relative] = expected
    for source in read(J / "admin/retrieval_sources.json"):
        assert sha(ROOT / source["path"]) == source["sha256"]
        frozen_hashes[source["path"]] = source["sha256"]
    for meta in protocol["reports"]:
        path = J / "review" / (meta["report_id"] + ".html")
        frozen_hashes[str(path.relative_to(ROOT))] = sha(path)

    unique = []
    expanded = []
    index = {}
    for role in ("primary", "secondary"):
        for sid, record in reports[role]["submission"]["records"].items():
            ans = record["answers"]
            case = reports[role]["cases"][sid]
            for field in FIELDS:
                for candidate in case["candidates"][field]:
                    code = candidate["code"]
                    arms = key["key"][role][sid][field][code]
                    entry = {
                        "role": role, "reviewer": reports[role]["submission"]["reviewer"]["code"],
                        "sample_id": sid, "split": by_id[sid]["split"], "field": field,
                        "candidate_code": code, "arms": "|".join(arms),
                        "text": candidate["text"], "available": candidate["available"],
                        "initial_visibility": first_visibility(record, field),
                        "grade": ans[f"rating.{field}.{code}.grade"],
                        "note": ans.get(f"rating.{field}.{code}.note", ""),
                        "initial_reading": record["snapshots"]["image_first"]["answers"].get(f"initial.{field}.reading", ""),
                        "reference_relation": record["snapshots"]["reference_check"]["answers"].get(f"reference.{field}.relation", ""),
                        "reference_note": ans.get(f"reference.{field}.note", ""),
                        "reference_reading": ans.get(f"reference.{field}.reading", ""),
                        "amendment": ans.get("amendment", ""),
                    }
                    unique.append(entry)
                    for arm in arms:
                        expanded.append({**entry, "arm": arm, "method": methods[arm]})
                        index[(role, sid, field, arm)] = entry
    assert len([r for r in unique if r["role"] == "primary"]) == 444
    assert len([r for r in unique if r["role"] == "secondary"]) == 135
    assert len(expanded) == 1170
    write_csv("human_candidate_ratings.csv", unique)
    write_csv("human_method_ratings.csv", expanded)
    write_csv("reviewer_amendments.csv", amendments)

    human_rates = []
    for subset in ("initial_visible", "initial_readable", "all50"):
        for field in FIELDS:
            for arm in ARMS:
                entries = [r for r in expanded if r["role"] == "primary" and r["field"] == field and r["arm"] == arm
                           and (subset == "all50" or r["initial_visibility"] in
                                (VISIBLE if subset == "initial_visible" else {"readable"}))]
                counts = Counter(r["grade"] for r in entries)
                n = len(entries)
                lo, hi = wilson(counts["correct"], n)
                human_rates.append({
                    "subset": subset, "field": field, "arm": arm, "method": methods[arm],
                    "n": n, **{grade: counts[grade] for grade in GRADES},
                    "confirmed_complete_fraction": counts["correct"] / n,
                    "wilson_ci95_low": lo, "wilson_ci95_high": hi,
                })
    write_csv("human_confirmation_rates.csv", human_rates)
    write_json("human_denominators.json", {
        field: dict(Counter(first_visibility(r, field) for r in reports["primary"]["submission"]["records"].values()))
        for field in FIELDS
    })
    relations = [{"field": field, "relation": relation, "n": count}
                 for field in FIELDS
                 for relation, count in sorted(Counter(
                     r["snapshots"]["reference_check"]["answers"][f"reference.{field}.relation"]
                     for r in reports["primary"]["submission"]["records"].values()).items())]
    write_csv("catalogue_reference_relations.csv", relations)

    # Common denominators; no unassessable or failed outputs are removed per method.
    paired = []
    for before, after in (("C", "D"), ("E", "F")):
        for field in FIELDS:
            pairs = [(index[("primary", sid, field, before)]["grade"], index[("primary", sid, field, after)]["grade"])
                     for sid, r in reports["primary"]["submission"]["records"].items()
                     if first_visibility(r, field) in VISIBLE]
            counts = Counter(("confirmed" if a == "correct" else "unconfirmed",
                              "confirmed" if b == "correct" else "unconfirmed") for a, b in pairs)
            paired.append({
                "pair": f"{before}->{after}", "field": field, "n": len(pairs),
                "both_confirmed": counts[("confirmed", "confirmed")],
                "newly_confirmed": counts[("unconfirmed", "confirmed")],
                "no_longer_confirmed": counts[("confirmed", "unconfirmed")],
                "both_unconfirmed": counts[("unconfirmed", "unconfirmed")],
                "net_confirmed_difference": counts[("unconfirmed", "confirmed")] - counts[("confirmed", "unconfirmed")],
            })
    write_csv("paired_human_changes.csv", paired)

    issues = []

    def issue(kind, sid, field, left_label, left, right_label, right, text="", arms="", left_note="", right_note=""):
        issues.append({
            "issue_id": f"Q{len(issues) + 1:03d}", "kind": kind, "sample_id": sid, "field": field,
            "left_label": left_label, "left": left, "right_label": right_label, "right": right,
            "text": text, "arms": arms, "left_note": left_note, "right_note": right_note,
        })

    second_ids = sorted(reports["secondary"]["submission"]["records"])
    matrices = {field: np.zeros((15, len(GRADES), len(GRADES)), dtype=np.int64) for field in FIELDS}
    agreement_pairs = []
    for sample_index, sid in enumerate(second_ids):
        for field in FIELDS:
            primary = [r for r in unique if r["role"] == "primary" and r["sample_id"] == sid and r["field"] == field]
            secondary = [r for r in unique if r["role"] == "secondary" and r["sample_id"] == sid and r["field"] == field]
            for left in primary:
                right, = [r for r in secondary if (r["text"], r["available"]) == (left["text"], left["available"])]
                assert set(left["arms"].split("|")) == set(right["arms"].split("|"))
                a, b = GRADES.index(left["grade"]), GRADES.index(right["grade"])
                matrices[field][sample_index, a, b] += 1
                agreement_pairs.append({
                    "sample_id": sid, "field": field, "arms": left["arms"],
                    "text": left["text"], "available": left["available"],
                    "R1_candidate": left["candidate_code"], "R2_candidate": right["candidate_code"],
                    "R1_grade": left["grade"], "R2_grade": right["grade"],
                    "agrees": a == b, "R1_note": left["note"], "R2_note": right["note"],
                })
                if a != b:
                    issue("candidate_grade", sid, field, "R1 盲审", left["grade"], "R2 盲审", right["grade"],
                          left["text"], left["arms"], left["note"], right["note"])
    sampled_indices = np.random.default_rng(BOOTSTRAP_SEED).integers(0, 15, size=(BOOTSTRAPS, 15))
    pooled = sum(matrices.values())
    reliability = {field: agreement(matrix, sampled_indices) for field, matrix in matrices.items()}
    reliability["pooled"] = agreement(pooled, sampled_indices)
    write_csv("double_review_pairs.csv", agreement_pairs)
    write_json("agreement.json", {
        "unit_of_resampling": "specimen", "n_clusters": 15, "bootstrap_repetitions": BOOTSTRAPS,
        "bootstrap_seed": BOOTSTRAP_SEED, "independent_observations_not_135": True,
        "equal_weight_per_unique_candidate_point_estimate": True,
        "duplicate_method_outputs_collapsed": True, "statistics": reliability,
    })

    for sid in second_ids:
        for field in FIELDS:
            a = first_visibility(reports["primary"]["submission"]["records"][sid], field)
            b = first_visibility(reports["secondary"]["submission"]["records"][sid], field)
            if a != b:
                issue("reviewer_visibility", sid, field, "R1 初始图像判断", a, "R2 初始图像判断", b)

    visibility = reports["visibility"]["submission"]["records"]
    visibility_rows = [{
        "sample_id": sid, "split": by_id[sid]["split"], "presence": r["answers"]["presence"],
        "input_quality": r["answers"]["input_quality"], "full_sheet_presence": r["answers"].get("full_sheet_presence", ""),
        "visible_reading": r["answers"].get("visible_reading", ""), "note": r["answers"].get("note", ""),
        "historical_automatic_presence": by_id[sid]["presence_label"],
    } for sid, r in sorted(visibility.items())]
    write_csv("visibility_319.csv", visibility_rows)
    visibility_counts = {v: sum(r["presence"] == v for r in visibility_rows) for v in PRESENCE}
    scopes = Counter((r["presence"], r["full_sheet_presence"]) for r in visibility_rows)
    scope_rows = [{"presence": p, "full_sheet_presence": s, "n": n} for (p, s), n in sorted(scopes.items())]
    write_csv("visibility_scope_counts.csv", scope_rows)
    cross = Counter((r["historical_automatic_presence"], r["presence"]) for r in visibility_rows)
    write_csv("automatic_vs_human_presence.csv", [
        {"automatic": a, "human": h, "n": n} for (a, h), n in sorted(cross.items())
    ])
    for sid, record in reports["primary"]["submission"]["records"].items():
        a = first_visibility(record, "scientific_name")
        b = visibility[sid]["answers"]["presence"]
        if a != b:
            issue("cross_task_visibility", sid, "scientific_name", "R1 50份初始图像判断", a,
                  "R1 319份可见性审核", b, left_note=record["snapshots"]["image_first"]["answers"].get("initial.scientific_name.reading", ""),
                  right_note=visibility[sid]["answers"].get("visible_reading", ""))

    with (I / "evaluation/per_field_counts.csv").open(encoding="utf-8-sig", newline="") as stream:
        auto_rows = list(csv.DictReader(stream))
    assert len(auto_rows) == 319 * 6 * 3
    auto_metrics = []
    for subset, eligible in (
        ("original319", set(by_id)),
        ("human_name_readable152", {r["sample_id"] for r in visibility_rows if r["presence"] == "readable"}),
        ("human_name_visible172", {r["sample_id"] for r in visibility_rows if r["presence"] in VISIBLE}),
    ):
        for field in FIELDS if subset == "original319" else ("scientific_name",):
            for arm in ARMS:
                selected = [r for r in auto_rows if r["sample_id"] in eligible and r["field"] == field
                            and r["arm_alias"] == arm and r["reference_known"] == "True"]
                counts = {k: sum(int(r[k]) for r in selected) for k in ("M", "S", "D", "I", "Nref")}
                passed = sum(r["field_pass"] == "True" for r in selected)
                auto_metrics.append({
                    "subset": subset, "field": field, "arm": arm, "method": methods[arm],
                    "n": len(selected), "catalogue_pass_n": passed, "catalogue_pass_fraction": passed / len(selected),
                    **counts, "coverage07_micro": counts["M"] / counts["Nref"],
                })
    write_csv("automatic_metrics_original_and_visibility_subsets.csv", auto_metrics)

    absence_outputs = []
    absent_ids = [r["sample_id"] for r in visibility_rows if r["presence"] == "absent"]
    for arm in ARMS:
        counts = Counter()
        for sid in absent_ids:
            output = by_id[sid]["arms"][arm]
            text = output.get("fields", {}).get("scientific_name", {}).get("label_text") or ""
            counts["technical_failure" if output["status"] != "ok" else "nonempty" if text.strip() else "valid_empty"] += 1
        absence_outputs.append({
            "arm": arm, "method": methods[arm], "n_absent_input": len(absent_ids),
            **{k: counts[k] for k in ("valid_empty", "nonempty", "technical_failure")},
        })
    write_csv("scientific_name_outputs_on_absent_inputs.csv", absence_outputs)

    rag_rows = []
    for sid, record in sorted(reports["rag"]["submission"]["records"].items()):
        case = reports["rag"]["cases"][sid]
        ans = record["answers"]
        rag_rows.append({
            "sample_id": sid,
            "automatic_direction": "improved" if case["selection"]["after"]["pass"] else "regressed",
            "E_auto_pass": case["selection"]["before"]["pass"], "F_auto_pass": case["selection"]["after"]["pass"],
            "E_text": case["before"]["label_text"], "F_text": case["after"]["label_text"],
            "E_grade": ans["before.grade"], "F_grade": ans["after.grade"],
            "change": ans["change"], "evidence_support": ans["evidence_support"],
            "E_note": ans.get("before.note", ""), "F_note": ans.get("after.note", ""),
            "evidence_note": ans.get("evidence_note", ""),
            "retrieved_items": len(case["evidence"]), "model_cited_ids": "|".join(case["cited_ids"]),
        })
        if sid in reports["primary"]["submission"]["records"]:
            for arm, key_name in (("E", "before"), ("F", "after")):
                left = index[("primary", sid, "locality", arm)]
                right = ans[f"{key_name}.grade"]
                if left["grade"] != right:
                    issue("blind_vs_rag_context", sid, "locality", "R1 匿名盲审", left["grade"],
                          "R1 RAG对照审核", right, left["text"], arm, left["note"], ans.get(f"{key_name}.note", ""))
    write_csv("rag_human_case_results.csv", rag_rows)
    write_csv("unresolved_issues.csv", issues)
    write_json("unresolved_issues.json", issues)
    write_json("reviewer_amendments.json", amendments)

    # Separate, initially blank adjudication. It does not edit either original reviewer.
    grouped = defaultdict(list)
    for item in issues:
        grouped[(item["sample_id"], item["field"])].append(item)
    adjudication_cases = []
    for (sid, field), case_issues in sorted(grouped.items()):
        source_case = reports["visibility"]["cases"][sid]
        judgements = {}
        for role in ("primary", "secondary"):
            record = reports[role]["submission"]["records"].get(sid)
            if record:
                judgements[role] = {
                    "initial": record["snapshots"]["image_first"]["answers"],
                    "reference": record["snapshots"]["reference_check"]["answers"],
                    "amendment": record["answers"].get("amendment", ""),
                }
        adjudication_cases.append({
            "id": f"{sid}:{field}", "sample_id": sid, "field": field, "field_name": FIELD_NAMES[field],
            "crop": source_case["crop"], "sheet": source_case["sheet"], "raw_sheet": source_case["raw_sheet"],
            "reference": by_id[sid]["reference"]["fields"][field],
            "judgements": judgements, "issues": case_issues,
        })
    dataset = {
        "schema": "p23_adjudication_v1", "purpose": "human consensus only; no automatic score changes",
        "input_hashes": sources, "cases": adjudication_cases,
    }
    dataset["dataset_digest"] = hashlib.sha256(json.dumps(dataset, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    write_json("adjudication_dataset.json", dataset)
    write_json("adjudication_blank.json", {
        "schema": dataset["schema"], "dataset_digest": dataset["dataset_digest"],
        "reviewer": "", "decisions": {}, "events": [],
    })

    summary = {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "R1 primary estimates; inter-reviewer and cross-task differences unresolved",
        "submissions": checks, "methods": methods, "visibility_counts": visibility_counts,
        "absence_scope_counts": {s: n for (p, s), n in scopes.items() if p == "absent"},
        "human_rates": human_rates, "reliability": reliability, "automatic_metrics": auto_metrics,
        "absence_outputs": absence_outputs, "paired_human_changes": paired,
        "rag_change_counts": dict(Counter(r["change"] for r in rag_rows)),
        "rag_evidence_counts": dict(Counter(r["evidence_support"] for r in rag_rows)),
        "rag_E_grade_counts": dict(Counter(r["E_grade"] for r in rag_rows)),
        "rag_F_grade_counts": dict(Counter(r["F_grade"] for r in rag_rows)),
        "rag_direction_by_change": [
            {"automatic_direction": d, "human_change": c, "n": n}
            for (d, c), n in sorted(Counter((r["automatic_direction"], r["change"]) for r in rag_rows).items())
        ],
        "issue_counts": dict(Counter(r["kind"] for r in issues)),
        "issue_specimens": len({r["sample_id"] for r in issues}), "issue_field_groups": len(grouped),
        "reviewer_amendments": amendments,
        "browser_active_seconds": round(sum(c["browser_active_seconds"] for c in checks), 3),
        "new_model_calls": 0, "new_tokens": 0, "new_api_cost_usd": 0,
    }
    write_json("summary.json", summary)
    write_json("analysis_rules.json", {
        "analysis_specified_after_annotations": True,
        "primary_reviewer": "R1; R2 used for reliability, never selectively substituted",
        "primary_denominator": "R1 image-first snapshot: readable or partial; common across A-F",
        "primary_numerator": "correct only; partial, incorrect, unassessable and technical_failure remain unconfirmed",
        "unassessable_means_incorrect": False,
        "correct_empty": "reported separately; not counted as successful visible-field extraction",
        "readable_only_sensitivity": "Initial snapshots only; later 4 amendment notes retained, no silent recoding",
        "human_readings_used_as_character_gold": False,
        "character_gold": "Original frozen workbook values; human free-text readings mix commentary and transcription",
        "automatic_subset": "Sum existing M / sum Nref on shared human visibility subsets; no alignment or model rerun",
        "automatic07_scope": "NFC; scientific_name + locality + collector label_text stream, not full OCR transcript",
        "agreement_unit": "One identical text+availability candidate per specimen/field, irrespective of number of methods",
        "agreement_ci": f"Percentile cluster bootstrap, specimen resampling, B={BOOTSTRAPS}, seed={BOOTSTRAP_SEED}",
        "confirmation_ci": "95% Wilson interval per method-field binary confirmed outcome; descriptive, no multiplicity-adjusted claims",
        "rag_selection": "27 threshold-crossing locality cases (14 improved, 13 regressed), diagnostic, not random",
        "posthoc_scope": "Existing frozen 319 cohort; no new unseen cohort or model tuning",
        "reviewer_identity": "R1/R2 codes and self-described language/specimen experience; no further credentials inferred",
        "time": "Browser active seconds are approximate, not validated labor time; all self-reported minutes missing",
    })
    validation = {
        "checks": checks, "raw_submission_sha256": sources, "frozen_source_sha256": frozen_hashes,
        "unblinding_checked_against_frozen_text": True,
        "phase_snapshots_present_and_ordered": True,
        "primary_method_field_rows": 900, "secondary_method_field_rows": 270,
        "primary_unique_candidate_rows": 444, "secondary_unique_candidate_rows": 135,
        "raw_inputs_unchanged": all(sha(ROOT / path) == expected for path, expected in sources.items()),
        "frozen_inputs_unchanged": all(sha(ROOT / path) == expected for path, expected in frozen_hashes.items()),
        "new_model_calls": 0,
    }
    assert validation["raw_inputs_unchanged"] and validation["frozen_inputs_unchanged"]
    write_json("validation.json", validation)
    return summary, dataset, rag_rows, relations


def pct(value, places=1):
    return f"{100 * value:.{places}f}%"


def esc(value):
    return html.escape(str(value))


def table(headers, rows):
    return '<div class="table-wrap"><table><thead><tr>' + "".join(f"<th>{esc(h)}</th>" for h in headers) + \
        "</tr></thead><tbody>" + "".join("<tr>" + "".join(f"<td>{cell}</td>" for cell in row) + "</tr>" for row in rows) + \
        "</tbody></table></div>"


def render(summary, dataset, rag_rows, relations):
    s = summary
    rates = {(r["subset"], r["field"], r["arm"]): r for r in s["human_rates"]}
    auto = {(r["subset"], r["field"], r["arm"]): r for r in s["automatic_metrics"]}
    reliability = s["reliability"]["pooled"]
    sections = []
    sections.append(f"""<div class="notice"><b>目前是第一审核者 R1 的统计结果，尚未合并裁决。</b>
    两位审核者的原始判断均保留。报告区分319份目录一致性、50份人工确认比例和27份定向案例，三者分母和含义不同。
    <a href="adjudication.html">打开分歧复核页：{s['issue_specimens']}份标本 / {s['issue_field_groups']}个字段组</a>。</div>""")
    sections.append('<section id="visibility"><h2>1 · 先确认输入中是否有学名</h2>')
    sections.append(table(["主标签裁图可见性", "份数", "占319份"], [
        [PRESENCE_NAMES[v], s["visibility_counts"][v], pct(s["visibility_counts"][v] / 319)]
        for v in PRESENCE
    ]))
    sections.append("""<p>143份输入裁图未见学名，其中32份在其他标签上发现学名；108份查看整张图后仍未发现，
    2份其他位置疑似有但不可读、1份仍不确定。“主签未见”不能写成“原标本不存在学名”。
    TASH117052没有有效主签裁图，其他标签上有学名，保留为上游技术问题。</p>
    <p>可读或部分可读共172份。下表只对这些共同样本筛选原有目录比较计数，<b>不是172份三字段人工准确率</b>。
    原319份结果完整保留。</p>""")
    sections.append(table(["方法", "原319份学名字符覆盖", "原319份目录达标", "可见172份字符覆盖", "可见172份目录达标"], [
        [f"{arm} · {s['methods'][arm]}",
         pct(auto[("original319", "scientific_name", arm)]["coverage07_micro"], 2),
         pct(auto[("original319", "scientific_name", arm)]["catalogue_pass_fraction"], 2),
         pct(auto[("human_name_visible172", "scientific_name", arm)]["coverage07_micro"], 2),
         pct(auto[("human_name_visible172", "scientific_name", arm)]["catalogue_pass_fraction"], 2)]
        for arm in ARMS
    ]))
    sections.append("""<p class="muted">字符覆盖率＝原07算法累计M / 累计Nref，仅NFC处理；检索范围是三个字段label_text拼接，
    不是完整OCR全文。另提供152份清楚可读样本的敏感性表。筛选可见样本后数值较高，反映了评测对象的变化，不能称为算法提升。</p>""")
    sections.append(table(["主签未见学名的143份", "有效空输出", "非空学名输出", "技术失败"], [
        [r["arm"] + " · " + r["method"], r["valid_empty"], r["nonempty"], r["technical_failure"]] for r in s["absence_outputs"]
    ]))
    sections.append('<p>非空输出表示与本次人工输入可见性判断不一致，并不自动证明该标本的目录鉴定错误。空的失败响应不计为正确留空。</p></section>')
    sections.append('<section id="blind"><h2>2 · 随机50份三字段人工审核</h2><p>只计“信息忠实且完整”为人工确认完整正确。'
                    '分母取R1看见目录和候选前锁定的“清楚可读＋部分可读”字段：学名26、采集地50、采集人49。'
                    '六种方法共用分母；无法判断和技术失败保留在分母，表示未获确认，不等同于已证明错误。</p>')
    human_table = []
    for arm in ARMS:
        row = [f"{arm} · {s['methods'][arm]}"]
        for field in FIELDS:
            r = rates[("initial_visible", field, arm)]
            row.append(f"<b>{r['correct']}/{r['n']} · {pct(r['confirmed_complete_fraction'])}</b>"
                       f"<small>95% CI {pct(r['wilson_ci95_low'])}–{pct(r['wilson_ci95_high'])}</small>")
        human_table.append(row)
    sections.append(table(["方法", "学名", "采集地", "采集人"], human_table))
    sections.append('<p class="muted">95%区间为逐方法、逐字段Wilson描述区间，不用于宣布方法差异显著。'
                    '每个字段的实验单位为标本。正确留空另列，未加入上述分子。阅片阶段已先记录，再显示目录核对，最后对匿名输出评分。</p>')
    sections.append('<details><summary>展开各等级计数、初始清楚可读子集和目录关系</summary>')
    sections.append(table(["字段", "方法", "n"] + list(GRADE_NAMES.values()), [
        [FIELD_NAMES[r["field"]], r["arm"], r["n"]] + [r[g] for g in GRADES]
        for r in s["human_rates"] if r["subset"] == "initial_visible"
    ]))
    sections.append('<p>以下子集仅按初始快照筛选。R1另有4条事后修正说明，其中3条降低采集人读法的确定性，'
                    '因此清楚可读子集仅作敏感性展示；完整说明见 reviewer_amendments.csv，不静默改写初始记录。</p>')
    sections.append(table(["字段", "方法", "初始清楚可读n", "完整正确", "确认比例"], [
        [FIELD_NAMES[r["field"]], r["arm"], r["n"], r["correct"], pct(r["confirmed_complete_fraction"])]
        for r in s["human_rates"] if r["subset"] == "initial_readable"
    ]))
    relation_names = {"consistent": "一致", "format": "仅格式差异", "catalogue_normalized": "目录规范名或后续鉴定",
                      "different_scope": "信息范围不同", "discrepancy": "实质差异", "empty_reference": "目录空缺",
                      "unassessable": "无法核对"}
    sections.append(table(["字段", "目录与图像关系（R1）", "份数"], [
        [FIELD_NAMES[r["field"]], relation_names[r["relation"]], r["n"]] for r in relations
    ]))
    sections.append('</details><details><summary>展开原319份三字段自动指标（旧结果原样保留）</summary>'
                    '<p>各单元格依次为“07字符覆盖率 / 目录达标率”。学名与采集地目录分母为319，采集人为314。'
                    '此表是完整队列的目录一致性，不能与上面的50份人工确认比例直接相减作为提升量。</p>')
    sections.append(table(["方法", "学名：覆盖 / 达标", "采集地：覆盖 / 达标", "采集人：覆盖 / 达标"], [
        [arm + " · " + s["methods"][arm]] + [
            pct(auto[("original319", field, arm)]["coverage07_micro"], 2) + " / " +
            pct(auto[("original319", field, arm)]["catalogue_pass_fraction"], 2) for field in FIELDS]
        for arm in ARMS
    ]))
    sections.append('</details><p>在50份人工评分中，E→F采集地完整正确由16份变15份，采集人由33份变36份；'
                    '学名维持19份。这里描述净变化，不将RAG在所有字段上的作用概括为一致增益。</p></section>')
    sections.append('<section id="agreement"><h2>3 · 15份双人复核与待裁决分歧</h2>')
    sections.append(table(["字段", "一致/去重候选", "原始一致率（95%区间）", "Cohen’s κ（95%区间）"], [
        [FIELD_NAMES.get(field, "合计"),
         f"{r['agreements']}/{r['unique_candidates']}",
         f"{pct(r['agreement'])} ({pct(r['agreement_ci95_cluster_percentile'][0])}–{pct(r['agreement_ci95_cluster_percentile'][1])})",
         f"{r['kappa_unweighted']:.3f} ({r['kappa_ci95_cluster_percentile'][0]:.3f}–{r['kappa_ci95_cluster_percentile'][1]:.3f})"]
        for field, r in s["reliability"].items()
    ]))
    sections.append(f"""<p>相同标本、字段、文本和可用状态的重复输出只计一次；K编号按各自随机映射解码，未直接对齐编号。
    135个候选属于15份标本，<b>不是135份独立样本</b>。区间按标本整组重抽样{BOOTSTRAPS:,}次，种子{BOOTSTRAP_SEED}。
    κ为六个名义类别的非加权值，受类别分布影响。</p>""")
    issue_names = {"candidate_grade": "双人候选评分", "reviewer_visibility": "双人初始可见性",
                   "cross_task_visibility": "R1跨任务学名可见性", "blind_vs_rag_context": "R1盲审与RAG情境评分"}
    sections.append(table(["需核对的差异", "项数"], [[issue_names[k], v] for k, v in s["issue_counts"].items()]))
    sections.append(f"""<p>共涉及{s['issue_specimens']}份标本、{s['issue_field_groups']}个字段组。
    <a class="button" href="adjudication.html">填写分歧复核（初始留空）</a>
    人工最终裁决不会覆盖R1/R2原始判断。31项候选分歧可以继续讨论，但本报告没有代替审核者取平均或选择较优评分。
    另外4条R1修正说明随原记录保留，不能把初读文本直接当作干净的字符级真值。</p></section>""")
    sections.append('<section id="rag"><h2>4 · 27份RAG地点变化案例</h2><p>这些案例按既有目录阈值跨越筛选：'
                    '14份自动达标改善、13份自动达标下降。它们是定向诊断样本，不能估计全部319份的总体收益，也不能单凭输出差异证明因果。</p>')
    sections.append(table(["人工判断变化", "份数", "占27份"], [
        [name, s["rag_change_counts"].get(value, 0), pct(s["rag_change_counts"].get(value, 0) / 27)]
        for value, name in CHANGE_NAMES.items()
    ]))
    sections.append(table(["检索证据是否支持变化", "份数"], [
        [name, s["rag_evidence_counts"].get(value, 0)] for value, name in SUPPORT_NAMES.items()
    ]))
    sections.append('<p>没有案例获得“证据充分支持”；3份部分支持、18份不支持、6份无相应证据。'
                    '“无相应证据”不等同于检索器未返回任何条目。即使文字有局部修正，也未必能归因于检索证据。</p>')
    sections.append(table(["自动方向", "人工变化", "份数"], [
        ["达标改善" if r["automatic_direction"] == "improved" else "达标下降", CHANGE_NAMES[r["human_change"]], r["n"]]
        for r in s["rag_direction_by_change"]
    ]))
    sections.append('<details><summary>展开27份逐例人工结论与证据说明</summary>')
    sections.append(table(["标本", "自动方向", "E / F人工等级", "变化", "证据", "人工依据"], [
        [f'<a href="../review/rag_changes_27.html#{r["sample_id"]}">{r["sample_id"]}</a>',
         "改善" if r["automatic_direction"] == "improved" else "下降",
         GRADE_NAMES[r["E_grade"]] + " / " + GRADE_NAMES[r["F_grade"]],
         CHANGE_NAMES[r["change"]], SUPPORT_NAMES[r["evidence_support"]],
         esc(r["evidence_note"]) + '<details><summary>输出与评分依据</summary><b>E · 直接读图</b><div class="transcript">' +
         esc(r["E_text"]) + '</div><p>' + esc(r["E_note"]) + '</p><b>F · 读图＋RAG</b><div class="transcript">' +
         esc(r["F_text"]) + '</div><p>' + esc(r["F_note"]) + '</p></details>']
        for r in rag_rows
    ]))
    sections.append('</details></section>')
    sections.append(f"""<section id="use"><h2>5 · 如何用于论文</h2>
    <p><b>可以新增的证据：</b>输入学名缺失与其他标签之间的信息范围差异；随机50份人工完整性评价；
    15份双人一致性；检索证据失配的具体案例。它们增强了评测的可解释性，并未证明所有方法都有更高准确率。</p>
    <p><b>需收紧的表述：</b>不把“原图不存在学名”用于所有主签空白样本；不把部分正确计作完整准确；
    不将字符覆盖或目录达标等同于语义正确；不写“RAG普遍提高准确率”。
    当前文本宜表述为：视觉直接读取在本次人工样本中获得较高完整正确确认比例，而检索增强的作用随字段和证据匹配情况变化。</p>
    <p>中英文方法与结果草稿已整理在 <a href="manuscript_addendum_zh_en.md">论文补充文字</a>，尚未替换revision08正文或旧PDF/Word。
    完成分歧裁决后可再冻结论文最终数值；当前R1估计和分歧均已可追溯。</p>
    <p>新增模型调用：<b>0</b>；新增token：<b>0</b>；新增API费用：<b>US$0</b>。
    四份文件累计记录浏览器活跃时间约{s['browser_active_seconds']/60:.1f}分钟，审核者自报分钟均留空；
    活跃计时不是经过验证的人工工时或效率实验，不能推算成本节省。</p></section>""")
    files = [
        ("summary.json", "全部统计JSON"), ("human_confirmation_rates.csv", "人工比例及95%区间"),
        ("human_method_ratings.csv", "A–F解盲明细（1170行）"),
        ("human_candidate_ratings.csv", "去重候选原始评分（579行）"),
        ("automatic_metrics_original_and_visibility_subsets.csv", "原319份及可见性子集自动指标"),
        ("visibility_319.csv", "319份可见性明细"), ("rag_human_case_results.csv", "27份RAG人工结论"),
        ("double_review_pairs.csv", "135个双人候选对照"), ("agreement.json", "一致性及重抽样说明"),
        ("unresolved_issues.csv", "48项待核对差异"), ("reviewer_amendments.csv", "4条R1后续修正"),
        ("analysis_rules.json", "统计口径"), ("validation.json", "验证和原文件指纹"),
    ]
    sections.append('<section id="files"><h2>数据与复算</h2><ul>' +
                    "".join(f'<li><a href="{name}" download>{label}</a></li>' for name, label in files) +
                    '</ul><p>统计脚本：tool/p23_human_analysis/analyse.py。分析规则在收到标注后制定，未宣称预注册。'
                    '原始提交仍在../output，历史结果、图片和论文文件未改写。</p></section>')
    css = (HERE / "report.css").read_text(encoding="utf-8")
    page = f"""<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>人工审核统计 · 319 / 50 / 15 / 27</title><style>{css}</style><body>
    <header><div class="eyebrow">TASH · HUMAN AUDIT · 20 OCT 2026</div><h1>人工审核统计与论文补充</h1>
    <p>319份学名可见性 · 随机50份三字段 · 15份双人复核 · 27份RAG变化</p>
    <nav><a href="#visibility">可见性</a><a href="#blind">人工评分</a><a href="#agreement">双人一致性</a>
    <a href="#rag">RAG案例</a><a href="#use">论文用途</a><a href="#files">数据下载</a></nav></header>
    <main>{''.join(sections)}</main><footer>分析时间 {esc(s['created_at'])} · 原始判断保留 · 无新增模型调用</footer></body></html>"""
    (OUT / "index.html").write_text(page, encoding="utf-8")
    adjudication = (HERE / "adjudication.html").read_text(encoding="utf-8")
    adjudication = adjudication.replace("__CSS__", css).replace(
        "__DATA__", json.dumps(dataset, ensure_ascii=False).replace("<", "\\u003c")
    ).replace("__JS__", (HERE / "adjudication.js").read_text(encoding="utf-8"))
    (OUT / "adjudication.html").write_text(adjudication, encoding="utf-8")
    draft_manuscript(summary, auto, rates, reliability)


def draft_manuscript(s, auto, rates, reliability):
    en_rows, zh_rows = [], []
    for arm in ARMS:
        values = [rates[("initial_visible", f, arm)] for f in FIELDS]
        strings = [f"{r['correct']}/{r['n']} ({pct(r['confirmed_complete_fraction'])})" for r in values]
        row = "| " + arm + " · " + s["methods"][arm] + " | " + " | ".join(strings) + " |"
        en_rows.append(row)
        zh_rows.append(row)
    ci = reliability["kappa_ci95_cluster_percentile"]
    coverage_e = auto[("human_name_visible172", "scientific_name", "E")]["coverage07_micro"]
    coverage_f = auto[("human_name_visible172", "scientific_name", "F")]["coverage07_micro"]
    manuscript = f"""# Human-audit manuscript addendum / 人工审核论文补充草稿

Status: Post-hoc analysis of submitted annotations. Primary estimates use R1; disagreements have not been adjudicated. This file does not replace revision08 or establish a new test cohort.

## Methods: post-hoc human audit

We performed a post-hoc human audit of frozen outputs from the 319-specimen evaluation cohort, without additional model calls or model tuning. A reviewer assessed scientific-name visibility in the actual primary-label input for all 319 specimens. Input absence, limited legibility, uncertain presence and technical input failure were recorded separately. When the primary-label input lacked a name or was unavailable, the full specimen sheet was inspected to distinguish information on another label from information available to the evaluated methods.

Fifty specimens were selected by simple random sampling without replacement from the sorted 319 identifiers (seed 2026102001). Fifteen of these specimens were randomly assigned to a second reviewer (seed 2026102002). The exported records identified reviewers as R1 and R2 and recorded language and specimen experience. Reviewers first recorded image-only field visibility and readings, then checked the frozen catalogue reference, and finally graded anonymized method outputs. Initial readings and reference checks were retained as separate snapshots. Candidate aliases were randomized separately by reviewer, specimen and field; identical text with the same output availability was displayed once and later mapped to all corresponding methods.

The primary descriptive outcome was the proportion of fields confirmed as fully correct: the number graded as faithful and complete divided by the number judged readable or partially readable in R1's initial image-only assessment. This produced common denominators of 26 scientific-name, 50 locality and 49 collector fields for all six methods. Partial, incorrect, unassessable and failed outputs remained in the denominator as unconfirmed outcomes; unassessable outputs were not interpreted as proven errors. Correct abstentions on absent fields were reported separately. We report grade distributions and 95% Wilson intervals, with an initial-fully-readable sensitivity analysis. These analysis rules were specified after receipt of the annotations. Four subsequent reviewer amendment notes were preserved without silently overwriting the initial snapshots.

Inter-reviewer agreement was calculated over distinct text-and-availability candidates within each specimen and field, with unweighted Cohen's kappa for the six nominal grades. The 135 matched candidates were clustered within 15 specimens; 95% percentile bootstrap intervals resampled whole specimens 10,000 times (seed 2026102005). No candidate was treated as an independent specimen. R1 estimates and R2 reliability judgments were retained separately pending adjudication.

For comparison with the original automatic evaluation, we reused frozen character-alignment counts and catalogue-threshold outcomes on common, human-defined scientific-name visibility subsets. Character coverage was computed as the sum of matched characters divided by the sum of reference characters. This retained the version-07 alignment convention on the concatenated three-field label_text output, rather than the full OCR transcript. Original 319-specimen results were retained alongside the subset analyses. Human free-text readings, which include uncertainty and explanatory comments, were not substituted as character-level gold references.

An additional qualitative review considered all 27 cases in which E and F crossed the original locality-matching threshold in opposite directions (14 automatic improvements and 13 regressions). The reviewer assessed the textual change and the relevance of the retrieved evidence separately. These selected cases were used for diagnosis, not estimation of population-level RAG benefit or causal attribution.

## Results: visibility, human confirmation and retrieval changes

Across 319 primary-label inputs, scientific names were clearly readable in 152, partially readable in 20, absent in 143, uncertain in three, and unavailable because of an input failure in one. Among the 143 inputs without a visible name, 32 specimen sheets contained a scientific name on another label. The reviewer did not find a name on the full sheet in 108 cases, recorded unreadable possible names in two, and remained uncertain in one. Thus, absence from the model input should not be equated with absence from the specimen sheet.

In the random 50-specimen audit, E and F each had 19/26 scientific-name fields confirmed as fully correct. For locality, the corresponding counts were 16/50 for E and 15/50 for F; for collector, they were 33/49 and 36/49. These proportions quantify complete information recovery under the human rubric and are distinct from character coverage or catalogue similarity. The common denominators retain unassessable outcomes, so the reported values describe confirmed correctness rather than treating all unconfirmed outputs as erroneous.

| Method | Scientific name | Locality | Collector |
| --- | --- | --- | --- |
{chr(10).join(en_rows)}

Table note: R1 image-first readable-or-partially-readable fields; fully correct only in the numerator. Intervals and full grade counts are in human_confirmation_rates.csv. Methods share specimens and are paired; differences are descriptive, without a claim of statistical significance.

The two reviewers agreed on {reliability['agreements']}/{reliability['unique_candidates']} distinct candidates ({pct(reliability['agreement'])}); unweighted kappa was {reliability['kappa_unweighted']:.3f} (specimen-cluster bootstrap 95% interval {ci[0]:.3f}–{ci[1]:.3f}). There were 31 candidate-grade disagreements, which remained unresolved at this analysis freeze. Cross-task visibility and grading differences were recorded separately. On the 172 inputs judged to contain readable or partially readable names in the 319-specimen visibility audit, the original character-coverage calculation yielded {pct(coverage_e, 2)} for E and {pct(coverage_f, 2)} for F. These are visibility-conditioned catalogue comparisons, not new human-accuracy estimates or evidence of an algorithmic improvement.

In the 27 selected locality-change cases, the human review classified four as substantive corrections, ten as introduced errors, four as mixed changes, two as writing-only changes, six as having no clear gain, and one as unassessable. Retrieved evidence was judged partially supportive in three cases, unsupported in 18, and lacking corresponding evidence in six; none received a fully supportive judgment. A local textual correction therefore did not necessarily establish support from retrieval. These findings support reporting field-dependent and evidence-dependent retrieval outcomes rather than a uniform accuracy gain.

## 中文对应文本

对既有319份标本的冻结输出开展了事后人工审核，未新增模型调用或据此调参。先审核实际输入主标签的学名可见性，再在主签未见学名或无有效输入时核对整张标本，以区分其他标签的信息。随机抽取50份标本进行三字段匿名审核，其中随机15份由第二位审核者重复审核。两位审核者在导出记录中标记为R1和R2，并填写“有语言背景与标本经验”。审核流程依次保留仅看图的初始判断、目录核对和匿名候选评分；相同文本和可用状态的候选合并展示，按独立随机编号解盲。

主要人工指标定义为“确认完整正确比例”：分子仅计信息忠实且完整的输出；分母统一采用R1初始图像判断中清楚可读或部分可读的字段。因此学名、采集地、采集人的共同分母分别为26、50和49。部分正确、错误、无法判断及技术失败均保留为未获完整正确确认；其中“无法判断”不等于已经证实错误。图中不存在字段时的正确留空另报。报告逐等级计数及95% Wilson区间，以初始清楚可读子集作为补充；4条后续修正说明保留，未静默改写初始快照。统计规则是在收到标注后确定的，未宣称预注册。

双人一致性以每份标本、每个字段中去重后的实际候选输出为单位，使用六类名义等级的非加权Cohen’s κ。135个候选来自15份标本；置信区间按标本整组重抽样10,000次，未把候选数当作独立标本数。主评分采用R1，R2用于一致性评估，分歧尚未由人工合并裁决。原319份自动指标保持不变，另按人工学名可见性筛选原有字符对齐计数；这仍是与冻结目录的比较，不是新增172份人工语义准确率。

319份实际主签输入中，152份学名清楚可读，20份部分可读，143份未见学名，3份是否存在不确定，1份输入技术失败。143份主签未见学名的样本中，32份在其他标签上有学名；108份查看整张图后仍未发现，2份其他位置疑似有但不可读，1份仍不确定。因此，应将“输入主签未见学名”与“整张标本不存在学名”分开表述。

随机50份的人工评价中，E和F的学名均有19/26份获得完整正确确认；采集地分别为16/50和15/50，采集人分别为33/49和36/49。这一口径衡量信息完整性，与字符覆盖及目录相似度不同。

| 方法 | 学名 | 采集地 | 采集人 |
| --- | --- | --- | --- |
{chr(10).join(zh_rows)}

双人复核在135个去重候选中一致104项，一致率为{pct(reliability['agreement'])}；κ={reliability['kappa_unweighted']:.3f}，按标本重抽样的95%区间为{ci[0]:.3f}–{ci[1]:.3f}。31项候选评分分歧尚待人工裁决，跨任务的可见性和评分差异另列。按319份可见性审核筛选出的172份可见学名样本，E和F沿用07口径的字符覆盖率分别为{pct(coverage_e, 2)}和{pct(coverage_f, 2)}。数值变化来自评测对象筛选，不表示算法获得了新的提升。

27份定向RAG地点变化案例中，4份被判为实质修正、10份引入错误、4份兼有修正与损害、2份仅书写变化、6份无明确收益、1份无法判断。检索证据在3份中获得部分支持、18份不支持、6份无相应证据，没有案例被判为充分支持。局部文本修正不必然能归因于检索证据，因而论文应报告字段及证据匹配条件下的差异，避免声称RAG普遍提高准确率。

## 供作者处理的边界（非正文）

- 本轮是旧319份队列的事后验证，不是新采集的独立测试队列；模型权重训练排除和开发阶段使用仍沿用原稿的区分。
- 以上数值使用R1主审核，尚未形成最终裁决数据。48条差异合并为{s['issue_field_groups']}个字段组、涉及{s['issue_specimens']}份标本，见adjudication.html。
- 审核者身份和专业背景目前仅有导出的代码及经验描述；投稿时应由作者补充真实分工与资历，不由脚本推断。
- 319份只覆盖学名可见性人工审核；不要将50份三字段确认比例外推称作319份全面人工准确率。
- 浏览器记录约{s['browser_active_seconds']/60:.1f}分钟活跃时间，自报工时均缺失。不能据此写经验证的人工作业速度或成本节省。
- 本轮新增模型调用、token和API费用均为0；原实验历史费用与模型构成不变。
- 术语：confirmed complete correctness＝确认完整正确比例；catalogue agreement＝目录一致性；character coverage＝字符覆盖率；input visibility＝输入可见性。
"""
    (OUT / "manuscript_addendum_zh_en.md").write_text(manuscript, encoding="utf-8")


if __name__ == "__main__":
    results = analyse()
    render(*results)
    print(json.dumps({
        "output": str(OUT), "visibility": results[0]["visibility_counts"],
        "agreement": results[0]["reliability"]["pooled"],
        "issues": results[0]["issue_counts"], "issue_specimens": results[0]["issue_specimens"],
        "issue_field_groups": results[0]["issue_field_groups"], "new_model_calls": 0,
    }, ensure_ascii=False))
