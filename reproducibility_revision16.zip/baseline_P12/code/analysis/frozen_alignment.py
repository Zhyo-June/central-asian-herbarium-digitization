"""Pure reference-assisted local OCR coverage. No model or reference-source IO.

Candidate v1; synthetic/development only until an independent audit and root
release. The API receives already sanitized OCR and per-column comparison text.
It never uses C extracted primary values and never edits saved OCR.
"""
from dataclasses import dataclass
from collections import defaultdict
import math
import unicodedata

VERSIONS = ('nfc_raw', 'strict_normalized')


def strict_normalized(value):
    text = unicodedata.normalize('NFC', value or '').casefold()
    return ' '.join(''.join(' ' if unicodedata.category(c).startswith('P') else c
                           for c in text).split())


def normalization_boundary_safe(window):
    """Never silently compose/reorder characters across saved line boundaries.

    Such multi-line windows fall back to their single-line candidates and are
    counted as rejected candidate windows, without removing any field record.
    """
    text = ''.join(unicodedata.normalize('NFC', line.get('raw_prediction') or '') for line in window)
    return unicodedata.normalize('NFC', text) == text


def normalized_window_units(window, version):
    """Each comparison-domain character maps to a saved-line NFC interval.

    Strict casefold expansion consumes distinct normalized characters but may
    map them to the same original NFC code point; that fact is disclosed.
    No source line separator or other character is invented.
    """
    source = []
    raw_concatenation = ''
    for line in window:
        nfc = unicodedata.normalize('NFC', line.get('raw_prediction') or '')
        raw_concatenation += nfc
        for offset, char in enumerate(nfc):
            span = {'line_id': line['line_id'], 'line_index': line['original_line_index'],
                    'route_order_index': line['route_order_index'], 'span_nfc': [offset, offset + 1],
                    'route': line['route'], 'path_id': line['path_id'], 'label_id': line['label_id']}
            source.append({'char': char, 'source_spans': [span]})
    if version == 'strict_normalized':
        folded = []
        for item in source:
            for new in item['char'].casefold():
                folded.append({'char': ' ' if unicodedata.category(new).startswith('P') else new,
                               'source_spans': item['source_spans']})
        tokens, token, whitespace = [], [], []
        for item in folded:
            if item['char'].isspace():
                if token:
                    tokens.append(('token', token)); token = []
                whitespace.append(item)
            else:
                if whitespace:
                    tokens.append(('space', whitespace)); whitespace = []
                token.append(item)
        if token:
            tokens.append(('token', token))
        source = []
        for index, (kind, items) in enumerate(tokens):
            if kind == 'token':
                source.extend(items)
            elif index and index < len(tokens) - 1:
                source.append({'char': ' ', 'source_spans': [span for item in items for span in item['source_spans']]})
        assert ''.join(x['char'] for x in source) == strict_normalized(raw_concatenation)
    elif version != 'nfc_raw':
        raise ValueError('Only raw NFC and separately declared strict normalization are allowed')
    units = []
    for offset, item in enumerate(source):
        first, last = item['source_spans'][0], item['source_spans'][-1]
        units.append({'char': item['char'], **first, 'comparison_offset_in_window': offset,
                      'route_order_end_index': last['route_order_index'],
                      'source_spans': item['source_spans']})
    return units


def reference_text(value, version):
    return unicodedata.normalize('NFC', value or '') if version == 'nfc_raw' else strict_normalized(value)


def valid_bbox(value):
    return (isinstance(value, (list, tuple)) and len(value) == 4
            and all(type(number) in (int, float) and math.isfinite(number) for number in value)
            and value[2] > value[0] and value[3] > value[1])


def geometry_adjacent(left, right, config):
    if any(left[key] != right[key] for key in ('route', 'label_id', 'path_id')):
        return False
    if right['route_order_index'] != left['route_order_index'] + 1:
        return False
    if right['original_line_index'] != left['original_line_index'] + 1:
        return False
    a, b = left.get('bbox_xyxy_oriented'), right.get('bbox_xyxy_oriented')
    if not valid_bbox(a) or not valid_bbox(b):
        return False
    if left.get('oriented_coordinate_system') != right.get('oriented_coordinate_system'):
        return False
    if left.get('oriented_coordinate_system') is None:
        return False
    ah, bh = a[3] - a[1], b[3] - b[1]
    if ah <= 0 or bh <= 0:
        return False
    if (a[1] + a[3]) / 2 >= (b[1] + b[3]) / 2:
        return False
    gap = max(0, b[1] - a[3])
    overlap = max(0, min(a[3], b[3]) - max(a[1], b[1]))
    return (gap <= config['maximum_vertical_gap_times_larger_line_height'] * max(ah, bh)
            and overlap <= config['maximum_vertical_overlap_times_smaller_line_height'] * min(ah, bh))


@dataclass(frozen=True)
class Node:
    M: int
    S: int
    D: int
    I: int
    breaks: int
    start: int
    end: int
    previous: object = None
    op: str = 'empty'
    reference_index: object = None
    source_index: object = None
    empty_prefix_D: int = 0

    @property
    def score(self):
        return 2 * self.M - self.S - self.D - self.I - self.breaks

    @property
    def edits(self):
        return self.S + self.D + self.I

    def key(self):
        return (self.score, -self.breaks, -(self.end - self.start), -self.edits, -self.start)


def local_alignment(reference, units):
    """Complete-reference / free-OCR-ends weighted sequence alignment.

    The output is one continuous span, never a union of separate local hits.
    Empty evidence remains available and produces N reference deletions.
    This maximizes a frozen local alignment score, not minimum edit CER.
    """
    nr, np = len(reference), len(units)
    matrix = [[None] * (np + 1) for _ in range(nr + 1)]
    for i in range(nr + 1):
        for j in range(np + 1):
            empty = Node(0, 0, i, 0, 0, j, j, empty_prefix_D=i)
            if not i or not j:
                matrix[i][j] = empty
                continue
            candidates = []
            prev = matrix[i - 1][j - 1]
            crossed = (units[j - 1]['route_order_end_index'] - units[j - 2]['route_order_end_index']
                       if j >= 2 and prev.start < j - 1 else
                       units[j - 1]['route_order_end_index'] - units[j - 1]['route_order_index'])
            equal = reference[i - 1] == units[j - 1]['char']
            candidates.append(Node(prev.M + int(equal), prev.S + int(not equal), prev.D, prev.I,
                                   prev.breaks + crossed, prev.start, j, prev,
                                   'equal' if equal else 'substitute', i - 1, j - 1))
            prev = matrix[i - 1][j]
            candidates.append(Node(prev.M, prev.S, prev.D + 1, prev.I, prev.breaks,
                                   prev.start, j, prev, 'delete', i - 1, None))
            prev = matrix[i][j - 1]
            crossed = (units[j - 1]['route_order_end_index'] - units[j - 2]['route_order_end_index']
                       if j >= 2 and prev.start < j - 1 else
                       units[j - 1]['route_order_end_index'] - units[j - 1]['route_order_index'])
            candidates.append(Node(prev.M, prev.S, prev.D, prev.I + 1,
                                   prev.breaks + crossed, prev.start, j, prev,
                                   'insert', None, j - 1))
            candidates.append(empty)
            # Stable list order breaks otherwise identical ties: M/S, D, I, empty.
            matrix[i][j] = max(candidates, key=lambda node: node.key())
    best = max(matrix[nr], key=lambda node: node.key())
    columns, current = [], best
    while current.previous is not None:
        ri, si = current.reference_index, current.source_index
        columns.append({'op': current.op, 'reference_index': ri,
                        'reference_char': reference[ri] if ri is not None else '',
                        'prediction_char': units[si]['char'] if si is not None else '',
                        'source_unit_index': si,
                        'source': dict(units[si]) if si is not None else None})
        current = current.previous
    for i in range(current.empty_prefix_D - 1, -1, -1):
        columns.append({'op': 'delete', 'reference_index': i, 'reference_char': reference[i],
                        'prediction_char': '', 'source_unit_index': None, 'source': None})
    columns.reverse()
    consumed = [c['source_unit_index'] for c in columns if c['source_unit_index'] is not None]
    refs = [c['reference_index'] for c in columns if c['reference_index'] is not None]
    assert refs == list(range(nr))
    assert consumed == list(range(best.start, best.end))
    assert len(consumed) == len(set(consumed))
    assert best.M + best.S + best.D == nr
    assert best.M + best.S + best.I == best.end - best.start
    assert ''.join(c['reference_char'] for c in columns) == reference
    assert ''.join(c['prediction_char'] for c in columns) == ''.join(u['char'] for u in units[best.start:best.end])
    if consumed:
        assert best.breaks == units[consumed[-1]]['route_order_end_index'] - units[consumed[0]]['route_order_index']
    return best, columns


def make_runs(columns):
    runs = []
    for column in columns:
        line_id = column['source']['line_id'] if column['source'] else None
        if runs and runs[-1]['op'] == column['op'] and runs[-1]['line_id'] == line_id:
            run = runs[-1]
        else:
            run = {'op': column['op'], 'line_id': line_id, 'reference_text': '',
                   'prediction_text': '', 'reference_indices': [], 'source_NFC_spans': []}
            runs.append(run)
        run['reference_text'] += column['reference_char']
        run['prediction_text'] += column['prediction_char']
        if column['reference_index'] is not None:
            run['reference_indices'].append(column['reference_index'])
        if column['source']:
            run['source_NFC_spans'].extend(column['source']['source_spans'])
    return runs


def merge_intervals(intervals):
    merged = []
    for start, end in sorted(intervals):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return merged


def complement(length, selected):
    output, last = [], 0
    for start, end in selected:
        if last < start:
            output.append([last, start])
        last = end
    if last < length:
        output.append([last, length])
    return output


def token_cut(units, start, end):
    if start == end:
        return False, False
    left = bool(start and units[start - 1]['line_id'] == units[start]['line_id']
                and units[start - 1]['char'].isalnum() and units[start]['char'].isalnum())
    right = bool(end < len(units) and units[end - 1]['line_id'] == units[end]['line_id']
                 and units[end - 1]['char'].isalnum() and units[end]['char'].isalnum())
    return left, right


def validate_record(record):
    assert record['schema'] == 'D_sanitized_group_v1'
    assert record['sample_id'].startswith('TASH')
    assert record['excel_link']['unique_exact_key'] is True
    assert record['excel_link']['exact_key'] == record['sample_id']
    assert isinstance(record['columns'], list)
    assert len({column['column_key'] for column in record['columns']}) == len(record['columns'])
    lines = record['ocr_lines']
    assert len({line['line_id'] for line in lines}) == len(lines)
    assert len({line['original_line_index'] for line in lines}) == len(lines)
    for line in lines:
        assert all(key in line for key in ('line_id', 'original_line_index', 'route_order_index', 'route', 'path_id', 'label_id'))
        raw = line.get('raw_prediction')
        assert raw is None or isinstance(raw, str)
        if line.get('nfc_prediction') is not None:
            assert line['nfc_prediction'] == unicodedata.normalize('NFC', raw or '')
    for column in record['columns']:
        assert 'comparison_text' in column
        assert column['comparison_text'] is None or isinstance(column['comparison_text'], str)
        assert type(column['include_in_primary_endpoint']) is bool
        assert column['comparison_text_policy']
        assert column['reference_status'] in {'valid_reference', 'empty_reference', 'withheld_admin', 'invalid_reference'}
        assert column['comparison_state'] in {'present', 'empty', 'withheld_admin', 'invalid_type', 'error', 'formula_unresolved'}
        assert type(column['evaluated_literal_column']) is bool
        assert type(column['export_raw_value']) is bool
        if column['reference_status'] != 'valid_reference':
            assert column['comparison_text'] is None
        if column['reference_status'] == 'withheld_admin':
            assert column.get('raw_value') is None and column['export_raw_value'] is False
            assert column['evaluated_literal_column'] is False
    return lines


def evaluate_column(record, column, version, config):
    lines = record['ocr_lines']
    reference = reference_text(column['comparison_text'], version)
    nr = len(reference)
    groups = defaultdict(list)
    for line in lines:
        groups[(line.get('path_order', 0), line.get('route_order', 0),
                line['path_id'], line['label_id'], line['route'])].append(line)
    candidates = []
    window_count = 0
    normalization_boundary_rejections = 0
    if nr:
        for path_key, path_lines in sorted(groups.items()):
            path_lines.sort(key=lambda line: line['route_order_index'])
            assert len({line['route_order_index'] for line in path_lines}) == len(path_lines)
            for start in range(len(path_lines)):
                for width in range(1, config['max_adjacent_line_slots'] + 1):
                    window = path_lines[start:start + width]
                    if len(window) != width:
                        break
                    if any(not geometry_adjacent(a, b, config) for a, b in zip(window, window[1:])):
                        continue
                    if width > 1 and not normalization_boundary_safe(window):
                        normalization_boundary_rejections += 1
                        continue
                    units = normalized_window_units(window, version)
                    best, columns = local_alignment(reference, units)
                    window_count += 1
                    first = units[best.start] if best.start < best.end else None
                    last = units[best.end - 1] if best.start < best.end else None
                    tie = (best.key()[:4], -path_key[0], -path_key[1],
                           -(first['route_order_index'] if first else 0),
                           -(first['span_nfc'][0] if first else 0),
                           -(last['span_nfc'][1] if last else 0), -width)
                    candidates.append((tie, best, columns, units, window, path_key))
    if candidates:
        _, best, columns, units, window, path_key = max(candidates, key=lambda item: item[0])
    else:
        best, columns = local_alignment(reference, [])
        units, window, path_key = [], [], None
    selected = units[best.start:best.end]
    selected_by_line = defaultdict(list)
    for unit in selected:
        for span in unit['source_spans']:
            selected_by_line[span['line_id']].append(span['span_nfc'])
    spans, unused = [], []
    for line in lines:
        nfc_line = unicodedata.normalize('NFC', line.get('raw_prediction') or '')
        intervals = merge_intervals(selected_by_line[line['line_id']])
        if intervals:
            spans.append({'line_id': line['line_id'], 'original_line_index': line['original_line_index'],
                          'route_order_index': line['route_order_index'], 'route': line['route'],
                          'path_id': line['path_id'], 'label_id': line['label_id'],
                          'span_domain': 'NFC Unicode code points, half-open', 'selected_spans_nfc': intervals,
                          'raw_key_present': 'raw_prediction' in line, 'rawline': line.get('raw_prediction'),
                          'nfc_line': nfc_line, 'polygon': line.get('raw_polygon_xy'),
                          'coordinate_system': line.get('raw_coordinate_system'),
                          'bbox_xyxy_oriented': line.get('bbox_xyxy_oriented')})
        unused.append({'line_id': line['line_id'], 'original_line_index': line['original_line_index'],
                       'span_domain': 'NFC Unicode code points, half-open',
                       'unselected_spans_nfc': complement(len(nfc_line), intervals),
                       'raw_key_present': 'raw_prediction' in line,
                       'raw_value_is_null': line.get('raw_prediction') is None,
                       'NFC_length': len(nfc_line)})
    left_cut, right_cut = token_cut(units, best.start, best.end)
    precision_denominator = best.M + best.S + best.I
    exact_span = bool(nr and best.M == nr and best.edits == 0)
    origin_groups = defaultdict(list)
    for index, unit in enumerate(units):
        origin = tuple((span['line_id'], *span['span_nfc']) for span in unit['source_spans'])
        origin_groups[origin].append(index)
    selected_indices = set(range(best.start, best.end))
    origin_extents = []
    for indices in origin_groups.values():
        chosen = [index for index in indices if index in selected_indices]
        if len(indices) > 1 and chosen:
            origin_extents.append({'source_spans': units[indices[0]]['source_spans'],
                                   'whole_normalized_origin_text': ''.join(units[i]['char'] for i in indices),
                                   'whole_comparison_offsets_in_window': indices,
                                   'selected_comparison_offsets_in_window': chosen,
                                   'selected_normalized_text': ''.join(units[i]['char'] for i in chosen),
                                   'partial_normalization_unit_cut': len(chosen) != len(indices)})
    partial_normalization = any(item['partial_normalization_unit_cut'] for item in origin_extents)
    complete = exact_span and not (left_cut or right_cut or partial_normalization)
    matched_raw_positions = {(span['line_id'], i) for c in columns if c['op'] == 'equal'
                             for span in c['source']['source_spans'] for i in range(*span['span_nfc'])}
    result = {'schema': 'D_alignment_record_v1', 'sample_id': record['sample_id'],
            'split': record['split'], 'global_index': record['global_index'],
            'upstream_status': record.get('upstream_status'),
            'upstream_failed': record.get('upstream_failed'),
            'column_key': column['column_key'], 'column_title': column['title'],
            'column_evaluation_role': column['evaluation_role'],
            'include_in_primary_endpoint': column['include_in_primary_endpoint'],
            'evaluated_literal_column': column['evaluated_literal_column'],
            'export_raw_value': column['export_raw_value'],
            'expected_from_label': column['expected_from_label'],
            'reference_status': column['reference_status'],
            'comparison_state': column['comparison_state'],
            'reference_invalid_reason': column.get('reference_invalid_reason'),
            'reference_raw_cell': column.get('raw_value'), 'reference_cell_type': column['cell_type'],
            'reference_decoded_type': column.get('decoded_type'),
            'reference_decoded_cell_type': column.get('decoded_cell_type'),
            'reference_number_format': column.get('number_format'),
            'reference_ooxml': column.get('ooxml'),
            'reference_display_value': column.get('display_value'),
            'reference_comparison_text': column['comparison_text'],
            'comparison_text_policy': column['comparison_text_policy'], 'reference_source': column['source'],
            'reference_key_present': True, 'reference_value_is_null': column['comparison_text'] is None,
            'reference_value_is_null_domain': 'comparison_text, not original raw Excel cell',
            'comparison_text_is_null': column['comparison_text'] is None,
            'raw_cell_value_is_null': column.get('raw_value') is None,
            'reference_empty': column['reference_status'] == 'empty_reference',
            'normalized_reference_empty': nr == 0 if column['reference_status'] in {'valid_reference', 'empty_reference'} else None,
            'version': version, 'reference_normalized': reference,
            'Nref': nr, 'M': best.M, 'S': best.S, 'D': best.D, 'I': best.I,
            'selected_comparison_characters': precision_denominator, 'edit_count': best.edits,
            'information_recovery': best.M / nr if nr else None,
            'aligned_fragment_precision': best.M / precision_denominator if precision_denominator else None,
            'CER': best.edits / nr if nr else None,
            'CER_definition': 'Error count from the frozen score-selected alignment divided by full reference length; this alignment is not selected by minimum CER.',
            'all_reference_characters_matched': bool(nr and best.M == nr),
            'exact_selected_span': exact_span, 'complete_field_recovered': complete if nr else None,
            'selected_window': {'path_id': path_key[2] if path_key and selected else None,
                                'label_id': path_key[3] if path_key and selected else None,
                                'route': path_key[4] if path_key and selected else None,
                                'line_ids': [line['line_id'] for line in window] if selected else [],
                                'consumed_line_ids': list(dict.fromkeys(span['line_id'] for unit in selected for span in unit['source_spans'])),
                                'line_slots_crossed': best.breaks, 'skipped_line_slots': 0,
                                'break_penalty': best.breaks, 'selection_score': best.score,
                                'selection_objective': config['selection_score'],
                                'comparison_window_text': ''.join(unit['char'] for unit in units),
                                'comparison_span_in_window': [best.start, best.end],
                                'selected_comparison_text': ''.join(unit['char'] for unit in selected),
                                'normalization_origin_extents': origin_extents,
                                'selected_NFC_spans': spans},
            'alignment_columns': columns, 'alignment_runs': make_runs(columns),
            'unselected_ocr_positions': unused, 'candidate_window_count': window_count,
            'rejected_crossline_normalization_boundary_window_N': normalization_boundary_rejections,
            'flags': {'all_saved_OCR_empty': not any(isinstance(line.get('raw_prediction'), str) and line['raw_prediction'] for line in lines),
                      'upstream_failed': record.get('upstream_failed'),
                      'short_reference': 0 < nr <= config['short_reference_flag_max_length'],
                      'word_internal_start': left_cut, 'word_internal_end': right_cut,
                      'strict_expansion_maps_multiple_comparison_characters_to_one_NFC_position': bool(origin_extents),
                      'partial_normalization_unit_cut': partial_normalization,
                      'crossline_normalization_boundary_fallback': normalization_boundary_rejections > 0,
                      'matched_unique_source_NFC_positions': len(matched_raw_positions),
                      'cross_route_physical_overlap_status': 'not_exhaustively_assessed_no_joint_total_allowed',
                      'needs_visual': column.get('needs_visual', True), 'input_needs_visual': column.get('needs_visual', True),
                      'catalogue_is_label_gold': False, 'reference_assisted_offline': True,
                      'fresh_blind_test': False, 'known_prior_C_exposure': True,
                      'low_score_excluded': False},
            'cross_column_source_reuse': []}
    if column['reference_status'] in {'withheld_admin', 'invalid_reference'}:
        # Unknown/withheld reference length is not an empty Excel reference.
        for key in ('Nref', 'M', 'S', 'D', 'I', 'edit_count', 'all_reference_characters_matched',
                    'exact_selected_span', 'complete_field_recovered'):
            result[key] = None
        result['reference_normalized'] = None
        result['selected_window']['selection_score'] = None
        result['alignment_status'] = 'not_evaluated_' + column['reference_status']
    else:
        result['alignment_status'] = 'defined' if nr else 'undefined_zero_reference_length'
        if not nr:
            result['all_reference_characters_matched'] = None
            result['exact_selected_span'] = None
    return result


def evaluate_group(record, config):
    validate_record(record)
    assert config['match_reward'] == 2 and config['line_break_cost'] == 1
    assert all(config[k] == 1 for k in ('substitution_cost', 'deletion_cost', 'insertion_cost'))
    output = [evaluate_column(record, column, version, config)
              for column in record['columns'] for version in VERSIONS]
    for version in VERSIONS:
        source_to_columns = defaultdict(set)
        for result in output:
            if result['version'] != version:
                continue
            for span in result['selected_window']['selected_NFC_spans']:
                for start, end in span['selected_spans_nfc']:
                    for index in range(start, end):
                        source_to_columns[(span['line_id'], index)].add(result['column_key'])
        for result in output:
            if result['version'] != version:
                continue
            reuse = defaultdict(list)
            for (line_id, index), keys in source_to_columns.items():
                if result['column_key'] in keys and len(keys) > 1:
                    reuse[(line_id, tuple(sorted(keys)))].append([index, index + 1])
            result['cross_column_source_reuse'] = [{'line_id': key[0], 'column_keys': list(key[1]),
                                                   'spans_nfc': merge_intervals(intervals)}
                                                  for key, intervals in sorted(reuse.items())]
    return output
