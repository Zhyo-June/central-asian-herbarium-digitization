from pathlib import Path
import csv,json,gzip,collections
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'generated';OUT.mkdir(exist_ok=True)
def save(name,rows):
    with (OUT/name).open('w',encoding='utf-8',newline='') as f:
        columns=list(dict.fromkeys(k for row in rows for k in row))
        w=csv.DictWriter(f,fieldnames=columns);w.writeheader();w.writerows(rows)
summary=json.loads((ROOT/'tables/unified319_summary.json').read_text('utf-8'))
rows=[]
for scope,methods in summary['metrics'].items():
    for method,fields in methods.items():
        for field,v in fields.items():
            rows.append({'scope':scope,'method':method,'field':field,'coverage_percent':100*v['M']/v['Nref'],'agreement_percent':100*v['pass_count']/v['n'],'n':v['n'],'Nref':v['Nref']})
save('field_metrics.csv',rows)
ratings=list(csv.DictReader((ROOT/'human/human_method_ratings.csv').open(encoding='utf-8-sig')))
counts=collections.Counter((r['initial_visibility'],r['arm'],r['field'],r['grade']) for r in ratings if r['role']=='primary')
save('human_by_readability.csv',[dict(zip(['readability','arm','field','grade','n'],[*k,v])) for k,v in sorted(counts.items())])
with gzip.open(ROOT/'retrieval/ranked_results.jsonl.gz','rt',encoding='utf-8') as f:
    results=[json.loads(line) for line in f]
groups=collections.defaultdict(lambda:collections.Counter())
for row in results:
    g=groups[row['query']['group']];g['n']+=1
    for arm,rank in row['ranks'].items():
        for k in [1,5,10]:g[arm+'_hits_at_'+str(k)]+=int(rank is not None and 0<rank<=k)
save('retrieval_by_group.csv',[{'group':name,**vals} for name,vals in sorted(groups.items())])
print('Saved three descriptive tables to',OUT)
