from __future__ import annotations

import argparse
import difflib
import json
import re
import sqlite3
import time
from pathlib import Path

from . import VERSION
from .common import dumps, edit_distance, lexical, normalize, specimen_key, stable_id


FIELD_DOMAIN = {"taxon": "taxon", "current_taxon": "taxon", "historical_taxon": "taxon",
    "place": "place", "historical_place": "place", "collector": "person", "identifier": "person",
    "person": "person", "specimen": "specimen"}
TYPE_CLASSES = {"city": {"P"}, "village": {"P"}, "river": {"H"}, "lake": {"H"},
    "mountain": {"T"}, "administrative": {"A"}}
COUNTRY_AREAS = {"KZ": "Kazakhstan", "KG": "Kirgizstan", "TJ": "Tadzhikistan",
    "TM": "Turkmenistan", "UZ": "Uzbekistan"}


class Retriever:
    def __init__(self, db_path):
        self.path = Path(db_path).resolve()
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        self.db = sqlite3.connect(self.path.as_uri() + "?mode=ro", uri=True)
        self.db.row_factory = sqlite3.Row
        self.metadata = {r[0]: json.loads(r[1]) for r in self.db.execute("SELECT key,value FROM metadata")}

    def close(self):
        self.db.close()

    def evidence(self, evidence_id, include_raw=False):
        row = self.db.execute("""SELECT ev.*, b.path, b.sha256, s.url, s.title, s.license,
            s.upstream_group, s.availability FROM evidence ev JOIN build_input b USING(input_id)
            JOIN evidence_source s USING(source_id) WHERE evidence_id=?""", (evidence_id,)).fetchone()
        if not row:
            raise KeyError(evidence_id)
        obj = dict(row); raw = json.loads(obj.pop("raw_json"))
        obj["source_file"] = obj.pop("path"); obj["source_file_sha256"] = obj.pop("sha256")
        obj["snapshot_version_kind"] = "source_declared" if obj["snapshot_version"] else "sha256_content_snapshot"
        if not obj["snapshot_version"]:
            obj["snapshot_version"] = "sha256:" + obj["source_file_sha256"]
        if include_raw:
            obj["original_source_record"] = raw
        return obj

    def filters(self, domain, mode, include_catalogue, query_specimen_id, context):
        conditions = ["n.domain=?"]; params = [domain]
        if not include_catalogue:
            conditions.append("n.subject_specimen IS NULL")
        elif mode == "generalization":
            key = specimen_key(query_specimen_id)
            if not key:
                raise ValueError("Generalization with catalogue requires query_specimen_id")
            conditions.append("(n.subject_specimen IS NULL OR (n.subject_specimen<>? AND NOT EXISTS "
                "(SELECT 1 FROM specimen_record own WHERE own.specimen_key=? AND own.content_group=n.content_group)))")
            params.extend([key, key])
        if domain == "place" and context.get("country"):
            conditions.append("(e.country IS NULL OR e.country='' OR e.country=?)")
            params.append(context["country"].upper())
        if domain == "place" and context.get("entity_type"):
            kind = context["entity_type"]
            # Specific event identity is stricter than broad gazetteer feature classes.
            classes = TYPE_CLASSES.get(kind, set())
            marks = ",".join("?" for _ in classes) or "NULL"
            conditions.append(f"(e.entity_type=? OR EXISTS (SELECT 1 FROM place p WHERE p.entity_id=e.entity_id AND p.feature_class IN ({marks})))")
            params.extend([kind] + sorted(classes))
        return " AND ".join(conditions), params

    def _pool(self, query, domain, where, params, strategy, candidate_limit):
        base = "SELECT n.*, e.canonical_name, e.country, e.entity_type, e.provenance_kind, e.attributes_json FROM name_variant n JOIN entity e USING(entity_id) "
        found = {}
        for key, column, match in [(normalize(query), "normalized_name", "exact"), (lexical(query), "lexical_key", "normalized")]:
            if match == "normalized" and strategy == "exact":
                continue
            for row in self.db.execute(base + f"WHERE {where} AND n.{column}=? ORDER BY n.priority,n.name_id LIMIT ?", params + [key, candidate_limit]):
                found.setdefault(row["name_id"], (dict(row), match))
        if strategy != "fuzzy" or found:
            return list(found.values())
        key = lexical(query)
        grams = sorted({key[i:i + 3] for i in range(len(key) - 2) if key[i:i + 3].strip()})
        if not grams:
            return list(found.values())
        expression = " OR ".join('"' + g.replace('"', '""') + '"' for g in grams)
        sql = base + "JOIN name_fts ON name_fts.rowid=n.name_id WHERE name_fts MATCH ? AND " + where + " ORDER BY bm25(name_fts),n.name_id LIMIT ?"
        for row in self.db.execute(sql, [expression] + params + [candidate_limit]):
            found.setdefault(row["name_id"], (dict(row), "fuzzy"))
        return list(found.values())

    def query(self, field, text, *, top_k=5, strategy="fuzzy", mode="generalization", include_catalogue=False,
              query_specimen_id=None, source_line_ids=None, context=None, min_similarity=0.76):
        started = time.perf_counter(); context = dict(context or {})
        if field not in FIELD_DOMAIN:
            raise ValueError("Unsupported field; choose " + ", ".join(FIELD_DOMAIN))
        if strategy not in {"exact", "normalized", "fuzzy"} or mode not in {"generalization", "catalogue_assisted"}:
            raise ValueError("Invalid retrieval strategy or evaluation mode")
        if not 1 <= top_k <= 50 or not 0.0 <= min_similarity <= 1.0:
            raise ValueError("top_k must be 1..50 and min_similarity 0..1")
        if not isinstance(text, str) or len(text) > 512:
            raise ValueError("Query must be a string of at most 512 characters; segment by field first")
        if mode == "catalogue_assisted":
            include_catalogue = True
        if field == "specimen" and not include_catalogue:
            raise ValueError("Specimen record lookup requires explicit catalogue inclusion")
        if context.get("label_year") is not None:
            context["label_year"] = int(context["label_year"])
        domain = FIELD_DOMAIN[field]
        where, params = self.filters(domain, mode, include_catalogue, query_specimen_id, context)
        if field == "collector":
            where += " AND n.name_kind<>'catalogue_identifier'"
        elif field == "identifier":
            where += " AND n.name_kind<>'catalogue_collector'"
        qualified = domain == "taxon" and bool(re.search(r"(?i)(?:\b(?:sp|spp|cf|aff)\s*\.?\b|\?)", text))
        key = lexical(text)
        # Accession/barcode lookup is exact only; adjacent numbers are different specimens.
        lookup_text = specimen_key(text) if domain == "specimen" else text
        lookup_strategy = "exact" if domain == "specimen" else strategy
        pool = self._pool(lookup_text, domain, where, params, lookup_strategy, 400) if key else []
        output = {}; suppressed = 0
        for row, method in pool:
            targetkey = row["lexical_key"]
            if method == "fuzzy":
                quick = difflib.SequenceMatcher(None, key, targetkey, autojunk=False).ratio()
                if quick < min_similarity - 0.12:
                    continue
                similarity = 1 - edit_distance(key, targetkey) / max(len(key), len(targetkey), 1)
                if similarity < min_similarity:
                    continue
            else:
                similarity = 1.0
            attrs = json.loads(row.pop("attributes_json")); flags = []
            tax = self.db.execute("SELECT * FROM taxon WHERE entity_id=?", (row["entity_id"],)).fetchone() if domain == "taxon" else None
            if qualified and ((tax and row["entity_type"].casefold() not in ("genus", "family")) or not tax):
                suppressed += 1; continue
            if method == "fuzzy":
                flags.append("approximate_spelling_candidate")
            if row["provenance_kind"] == "catalogue":
                flags.append("catalogue_value_not_independent_authority")
            if domain == "person":
                flags.append("authority_or_name_match_does_not_identify_specimen_collector")
            if qualified:
                flags.append("identification_qualifier_retained_no_species_completion")
            if attrs.get("verification_status") and any(w in attrs["verification_status"] for w in ["conflict", "app_shell"]):
                flags.append(attrs["verification_status"])
            if tax and tax["geography_review_required"]:
                flags.append("global_candidate_requires_geography_review")
            if tax and tax["status"] not in ("Accepted", "Synonym"):
                flags.append("taxon_status_requires_review:" + tax["status"])
            year = context.get("label_year")
            if year is not None:
                for col, relation in [("valid_from", "before_known_name_period"), ("valid_to", "after_known_name_period")]:
                    value = row.get(col) or ""
                    m = re.match(r"(\d{4})", value)
                    if m and ((col == "valid_from" and year < int(m[1])) or (col == "valid_to" and year > int(m[1]))):
                        flags.append(relation)
                if domain == "person":
                    person = self.db.execute("SELECT * FROM person WHERE entity_id=?", (row["entity_id"],)).fetchone()
                    if person and person["birth_year"].isdigit() and year < int(person["birth_year"]):
                        flags.append("label_predates_person_birth")
                    if person and person["death_year"].isdigit() and year > int(person["death_year"]):
                        flags.append("label_postdates_person_death_role_review")
            priority = row["priority"]
            if field == "historical_taxon" and tax:
                priority = 5
            # Match method precedes priority; priority orders comparable lexical matches only.
            rank = (0 if method == "exact" else 1 if method == "normalized" else 2, -similarity, priority, row["entity_id"], row["name_id"])
            prev = output.get(row["entity_id"])
            ev = self.evidence(row["evidence_id"])
            if prev and prev["_rank"] <= rank:
                if ev["evidence_id"] not in prev["evidence_ids"]:
                    prev["evidence_ids"].append(ev["evidence_id"]); prev["evidence"].append(ev)
                continue
            item = {"entity_id": row["entity_id"], "canonical_name": row["canonical_name"],
                "matched_span": row["raw_name"], "match_method": method, "country": row["country"],
                "matched_name_metadata": {"name_kind": row["name_kind"], "language": row["language"],
                    "valid_from": row["valid_from"], "valid_to": row["valid_to"]},
                "entity_type": row["entity_type"], "provenance_kind": row["provenance_kind"],
                "score_components": {"edit_similarity": similarity, "source_priority": priority,
                    "similarity_is_probability": False}, "review_required": True, "review_reasons": sorted(set(flags)),
                "evidence_ids": [ev["evidence_id"]], "evidence": [ev], "_rank": rank}
            if prev:
                for oldev in prev["evidence"]:
                    if oldev["evidence_id"] not in item["evidence_ids"]:
                        item["evidence_ids"].append(oldev["evidence_id"]); item["evidence"].append(oldev)
            if tax:
                item["taxon"] = dict(tax)
                if tax["accepted_entity_id"]:
                    accepted = self.db.execute("SELECT canonical_name FROM entity WHERE entity_id=?", (tax["accepted_entity_id"],)).fetchone()
                    item["accepted_name_candidate"] = accepted[0] if accepted else None
                area = COUNTRY_AREAS.get(context.get("country", "").upper())
                if area:
                    present = self.db.execute("SELECT 1 FROM taxon_distribution WHERE entity_id IN (?,?) AND area=? LIMIT 1",
                        (row["entity_id"], tax["accepted_entity_id"], area)).fetchone()
                    item["country_distribution_in_snapshot"] = bool(present)
                    if not present:
                        item["review_reasons"].append("country_distribution_unknown_not_excluded")
            item["relations"] = [dict(x) for x in self.db.execute("SELECT * FROM relation WHERE subject_id=? ORDER BY relation_id", (row["entity_id"],))]
            for rel in item["relations"]:
                rel["attributes"] = json.loads(rel.pop("attributes_json"))
                rel["evidence"] = self.evidence(rel["evidence_id"])
            if row["provenance_kind"] == "catalogue":
                spec = self.db.execute("SELECT * FROM specimen_record WHERE entity_id=?", (row["entity_id"],)).fetchone()
                item["catalogue_record"] = {**dict(spec), "fields": json.loads(spec["fields_json"])}
                item["catalogue_record"].pop("fields_json")
                if row["name_kind"] == "catalogue_collector":
                    item["collector_name_form"] = {"collector_id": stable_id("collector_name_form", normalize(row["raw_name"])),
                        "normalized_name": normalize(row["raw_name"]), "identity_status": "unresolved_name_form_not_verified_person"}
            if domain == "place":
                geo = self.db.execute("SELECT * FROM place WHERE entity_id=?", (row["entity_id"],)).fetchone()
                if geo:
                    item["geographic_reference"] = dict(geo)
                item["assertion_context"] = attrs
            output[row["entity_id"]] = item
        items = sorted(output.values(), key=lambda r: r["_rank"])
        # Conflicting dated assertions are retained as distinct evidence, never majority voted.
        conflicts = []
        dates = {}
        for item in items:
            a = item.get("assertion_context", {})
            old, new = a.get("old_name"), a.get("new_name")
            if old and new and a.get("event_date"):
                dates.setdefault((old, new), set()).add(a["event_date"])
        for (old, new), values in sorted(dates.items()):
            if len(values) > 1:
                conflicts.append({"type": "different_source_event_dates", "old_name": old, "new_name": new, "dates": sorted(values)})
        for item in items:
            item.pop("_rank")
        passages = self.passages(field, text, top_k, context) if key and field != "specimen" else []
        return {"retriever_version": VERSION, "field": field, "field_raw": text,
            "field_normalized": None, "source_line_ids": source_line_ids or [],
            "evaluation_mode": mode, "catalogue_included": include_catalogue,
            "query_specimen_id": query_specimen_id, "context": context,
            "status": "candidates" if items else "evidence_only" if passages else "no_match",
            "no_match_reason": "qualified_identification_no_species_completion" if qualified and not items else
                "empty_query" if not key else "no_candidate_above_threshold" if not items and not passages else None,
            "candidates": items[:top_k], "passages": passages, "conflicts": conflicts,
            "automatic_replacement_allowed": False, "review_required": True,
            "identification_qualifier_preserved": qualified, "suppressed_species_candidates": suppressed,
            "retrieval_seconds": time.perf_counter() - started,
            "limits": {"name_candidate_pool": 400, "min_similarity": min_similarity,
                "confidence_calibrated": False, "vector_retrieval_used": False}}

    def passages(self, field, text, top_k, context):
        if field in ("taxon", "current_taxon"):
            domains = ["taxon"]
        elif field == "historical_taxon":
            domains = ["historical_taxon", "taxon"]
        elif field in ("place", "historical_place"):
            domains = ["place"]
        else:
            return []
        tokens = re.findall(r"[^\W_]+", text, re.UNICODE)
        # Require all significant query tokens; avoid broad single-character noise retrieval.
        tokens = [x for x in tokens if len(x) >= 3][:16]
        if not tokens:
            return []
        expression = " AND ".join('"' + x.replace('"', '""') + '"' for x in tokens)
        marks = ",".join("?" for _ in domains)
        params = [expression] + domains
        where = ""
        if context.get("publication_year_max") is not None:
            where = " AND p.publication_year IS NOT NULL AND p.publication_year<=?"
            params.append(int(context["publication_year_max"]))
        # Historical identification asks for dated historical evidence first;
        # modern nomenclature remains supplementary even with a better BM25 score.
        ordering = "CASE WHEN p.domain='historical_taxon' THEN 0 ELSE 1 END," if field == "historical_taxon" else ""
        sql = f"""SELECT p.*,d.source_file,d.upstream_group,d.publication_year AS doc_year
            FROM passage_fts JOIN passage p ON passage_fts.rowid=p.passage_id
            JOIN document d USING(document_id) WHERE passage_fts MATCH ?
            AND p.enabled=1 AND d.enabled=1 AND p.domain IN ({marks}){where}
            ORDER BY {ordering}bm25(passage_fts),p.passage_id LIMIT ?"""
        rows = self.db.execute(sql, params + [top_k * 5]).fetchall(); output = []; seen = set()
        for r in rows:
            textkey = lexical(r["text"])
            # Same-source duplicate carriers are disabled at import; exact text duplicates collapsed here.
            identity = (r["upstream_group"], textkey)
            if identity in seen:
                continue
            seen.add(identity)
            output.append({"chunk_id": r["chunk_id"], "domain": r["domain"], "text": r["text"],
                "source_file": r["source_file"], "publication_year": r["publication_year"],
                "evidence_id": r["evidence_id"], "evidence": self.evidence(r["evidence_id"]),
                "review_required": True, "original_scan_review_required": r["domain"] == "historical_taxon",
                "retrieval_method": "lexical_FTS5_BM25", "automatic_replacement_allowed": False})
            if len(output) >= top_k:
                break
        return output


def main():
    p = argparse.ArgumentParser(description="Offline field retrieval; never writes original fields")
    p.add_argument("--db", type=Path, required=True)
    p.add_argument("--field", choices=sorted(FIELD_DOMAIN)); p.add_argument("--text")
    p.add_argument("--queries", type=Path); p.add_argument("--output", type=Path)
    p.add_argument("--top-k", type=int, default=5)
    p.add_argument("--mode", choices=["generalization", "catalogue_assisted"], default="generalization")
    p.add_argument("--strategy", choices=["exact", "normalized", "fuzzy"], default="fuzzy")
    p.add_argument("--include-catalogue", action="store_true"); p.add_argument("--specimen-id")
    p.add_argument("--country"); p.add_argument("--label-year", type=int); p.add_argument("--entity-type")
    p.add_argument("--evidence-id")
    args = p.parse_args(); r = Retriever(args.db)
    if args.evidence_id:
        output = [r.evidence(args.evidence_id, include_raw=True)]
    else:
        if args.queries:
            with args.queries.open(encoding="utf-8-sig") as f:
                queries = [json.loads(s) for s in f if s.strip()]
        elif args.field and args.text is not None:
            queries = [{"field": args.field, "text": args.text, "query_specimen_id": args.specimen_id,
                "context": {k: v for k, v in {"country": args.country, "label_year": args.label_year,
                    "entity_type": args.entity_type}.items() if v is not None}}]
        else:
            p.error("Provide --field and --text, --queries, or --evidence-id")
        output = []
        for q in queries:
            result = r.query(q["field"], q["text"], top_k=q.get("top_k", args.top_k),
                strategy=q.get("strategy", args.strategy), mode=q.get("mode", args.mode),
                include_catalogue=q.get("include_catalogue", args.include_catalogue),
                query_specimen_id=q.get("query_specimen_id"), source_line_ids=q.get("source_line_ids"), context=q.get("context"))
            result["query_id"] = q.get("query_id"); output.append(result)
    r.close()
    if args.output:
        # Exclusive creation avoids overwriting previous retrieval evidence.
        with args.output.open("x", encoding="utf-8", newline="\n") as f:
            for item in output:
                f.write(dumps(item) + "\n")
        print(dumps({"results": len(output), "output": str(args.output)}))
    else:
        print(json.dumps(output[0] if len(output) == 1 else output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
