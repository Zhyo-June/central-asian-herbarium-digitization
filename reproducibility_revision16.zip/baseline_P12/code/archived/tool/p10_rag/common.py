from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path


def dumps(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def stable_id(prefix, *parts):
    return prefix + ":" + hashlib.sha256(dumps(parts).encode("utf-8")).hexdigest()[:32]


def normalize(value):
    """NFC + whitespace only. Never silently replace Cyrillic/Latin homoglyphs."""
    return " ".join(unicodedata.normalize("NFC", str(value or "")).split())


def lexical(value):
    # A separate search key; verbatim and conservative normalized values remain available.
    return " ".join(re.findall(r"[^\W_]+", normalize(value).casefold(), re.UNICODE))


def specimen_key(value):
    return re.sub(r"\s+", "", unicodedata.normalize("NFC", str(value or ""))).upper()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")


def edit_distance(a, b):
    if len(a) < len(b):
        a, b = b, a
    previous = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        current = [i]
        for j, cb in enumerate(b, 1):
            current.append(min(current[-1] + 1, previous[j] + 1, previous[j - 1] + (ca != cb)))
        previous = current
    return previous[-1]
