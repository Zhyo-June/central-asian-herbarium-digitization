from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
EXP = ROOT / '17_validation/independent_20261018_01/experiments'
DEFAULT_OUT = EXP / 'G_llm_rag_review_20261019_01'
OCR_SOURCE = EXP / 'E_mainroute_repair_01/full319_route_01/assembled/specimen_results.jsonl'
EXCEL = Path('data/catalogue.xlsx')
LEGACY_DB = ROOT / '11_rag/p10_index_20261012_01/rag.sqlite3'
FLORA_DB = ROOT / '11_rag/new_flora_20261016_01/flora.sqlite3'
FIELDS = ('scientific_name', 'locality', 'collector')
FIELD_LABELS = {'scientific_name': '学名', 'locality': '采集地', 'collector': '采集人'}
PRIMARY = 'claude-sonnet-5-5'
FALLBACK = 'deepseek-flash'
BASE_URL = __import__('os').environ.get('GATEWAY_BASE_URL', '')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def save(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))
