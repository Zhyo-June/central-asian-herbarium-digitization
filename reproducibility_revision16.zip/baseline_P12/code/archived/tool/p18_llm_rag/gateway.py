"""OpenAI-compatible gateway. Credentials stay in memory, never in receipts."""
from __future__ import annotations

import json
import base64
import copy
import hashlib
import os
import re
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

from .common import BASE_URL, digest, save


def request(endpoint, payload=None):
    # curl uses the Windows certificate store. Direct access is required on this
    # host; its configured proxy fails TLS. Certificate verification stays on.
    key = os.environ['ZHI_API_KEY']
    config = 'header = "Authorization: Bearer ' + key + '"\n'
    config += 'header = "Content-Type: application/json"\n'
    if endpoint == '/messages':
        config += 'header = "x-api-key: ' + key + '"\n'
        config += 'header = "anthropic-version: 2023-06-01"\n'
    if payload is not None:
        body = json.dumps(payload, ensure_ascii=True)
        config += 'data = "' + body.replace('\\', '\\\\').replace('"', '\\"') + '"\n'
    started = time.perf_counter()
    for attempt in range(2):
        proc = subprocess.run(
            ['curl.exe', '--ipv4', '--noproxy', '*', '--silent', '--show-error',
             '--connect-timeout', '20', '--max-time', '180', '--config', '-',
             '--write-out', '\n%{http_code}', BASE_URL + endpoint],
            input=config, text=True, encoding='utf-8', capture_output=True,
        )
        # Retry once only if the connection/TLS handshake failed before sending
        # the request. Do not replay a timed-out model inference automatically.
        connection_failure = proc.returncode in (6, 7, 35) or (
            proc.returncode == 28 and 'Connection timed out' in proc.stderr)
        if not connection_failure or attempt:
            break
        time.sleep(1)
    elapsed = round(time.perf_counter() - started, 3)
    if proc.returncode:
        raise RuntimeError(f'Gateway transport error {proc.returncode}: {proc.stderr[:400]}')
    body, status = proc.stdout.rsplit('\n', 1)
    if int(status) != 200:
        raise RuntimeError(f'Gateway HTTP {status}: {body[:900]}')
    return json.loads(body), elapsed


def complete(model, system, user, log_path, schema, *, image_path=None):
    message = {'role': 'user', 'content': json.dumps(user, ensure_ascii=False)}
    image_meta = None
    if image_path is not None:
        image_path = Path(image_path)
        encoded = base64.b64encode(image_path.read_bytes()).decode('ascii')
        image_meta = {'path': str(image_path.resolve()), 'sha256': digest(image_path),
                      'bytes': image_path.stat().st_size, 'media_type': 'image/png'}
        image_block = ({'type': 'image', 'source': {'type': 'base64',
                        'media_type': 'image/png', 'data': encoded}}
                       if model.startswith('claude-') else
                       {'type': 'image_url', 'image_url': {
                           'url': 'data:image/png;base64,' + encoded, 'detail': 'original'}})
        message['content'] = [image_block, {'type': 'text', 'text': message['content']}]
    if model.startswith('claude-'):
        endpoint = '/messages'
        # Sonnet 5.5 requires between_tools to turn off up-front thinking and
        # only accepts default sampling parameters (official model documentation).
        payload = {'model': model, 'max_tokens': 4096, 'stream': False,
                   'thinking': {'type': 'between_tools'},
                   'output_config': {'effort': 'medium', 'format': {'type': 'json_schema', 'schema': schema}},
                   'system': system, 'messages': [message]}
    else:
        endpoint = '/chat/completions'
        payload = {'model': model, 'temperature': 0, 'max_tokens': 4096,
                   'thinking': {'type': 'disabled'}, 'stream': False,
                   'response_format': {'type': 'json_object'},
                   'messages': [{'role': 'system', 'content': system}, message]}
    logged_payload = copy.deepcopy(payload)
    if image_meta:
        # Keep the exact image on disk once; receipts use its path and SHA256.
        # Replacing this marker with those bytes reconstructs the wire request.
        block = logged_payload['messages'][-1]['content'][0]
        marker = '@local_image_sha256:' + image_meta['sha256']
        if model.startswith('claude-'):
            block['source']['data'] = marker
        else:
            block['image_url']['url'] = marker
    receipt = {'requested_model': model, 'endpoint': BASE_URL + endpoint,
               'started_at': datetime.now(timezone.utc).isoformat(), 'request': logged_payload}
    if image_meta:
        receipt.update(image=image_meta, request_representation='image_bytes_replaced_by_sha256_locator',
                       request_sha256=hashlib.sha256(json.dumps(payload, ensure_ascii=True).encode()).hexdigest())
    try:
        response, elapsed = request(endpoint, payload)
        receipt.update(response=response, seconds=elapsed, status='received')
        # Store even invalid model output. The runner can use the authorized
        # fallback, but never silently edit a response into a successful run.
        save(log_path, receipt)
        if endpoint == '/messages':
            content = ''.join(b['text'] for b in response['content'] if b['type'] == 'text')
            finish = response.get('stop_reason')
        else:
            content = response['choices'][0]['message']['content']
            finish = response['choices'][0].get('finish_reason')
        content = re.sub(r'^```(?:json)?\s*|\s*```$', '', content.strip())
        parsed = json.loads(content)
        if finish in ('length', 'max_tokens'):
            raise ValueError('Output truncated by max_tokens')
        return parsed, {'requested_model': model, 'reported_model': response.get('model'),
                        'usage': response.get('usage', {}), 'seconds': elapsed,
                        'receipt': str(log_path), 'endpoint': BASE_URL + endpoint,
                        **({'image': image_meta} if image_meta else {})}
    except (RuntimeError, ValueError, KeyError, TypeError) as exc:
        receipt.update(status='failed', error=str(exc))
        save(log_path, receipt)
        raise


if __name__ == '__main__':
    data, elapsed = request('/models')
    ids = [x['id'] for x in data.get('data', [])]
    print(json.dumps({'model_count': len(ids), 'seconds': elapsed,
                      'requested_models': {m: m in ids for m in
                                           ['claude-sonnet-5-5', 'deepseek-flash']}}, indent=2))
