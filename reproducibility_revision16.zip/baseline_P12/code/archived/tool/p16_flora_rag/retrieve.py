"""Read-only retrieval. Results are located excerpts, never corrected field values."""
from __future__ import annotations
import argparse, hashlib, json, re, sqlite3, sys, time, unicodedata
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
DEFAULT_DB=ROOT/'11_rag/new_flora_20261016_01/flora.sqlite3'
SUPPORTED={'fulltext','literature','taxon','historical_taxon','current_taxon','place','historical_place'}

class FloraRetriever:
    def __init__(self,path=DEFAULT_DB):
        self.path=Path(path).resolve();self.db=sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True);self.db.row_factory=sqlite3.Row
        self.metadata={r[0]:json.loads(r[1]) for r in self.db.execute('SELECT key,value FROM metadata')}
        self.revision=None
        rev=self.path.parent/'revision_manifest.json'
        if rev.exists():
            self.revision=json.loads(rev.read_text(encoding='utf-8'));h=hashlib.sha256()
            with self.path.open('rb') as f:
                for b in iter(lambda:f.read(4194304),b''):h.update(b)
            if h.hexdigest()!=self.revision['database_sha256']:raise ValueError('OCR database does not match registered screening revision SHA256')
    def close(self):self.db.close()
    def evidence(self,chunk_id):
        r=self.db.execute('''SELECT c.*,p.source_id,p.pdf_page,p.pdf_page_label,p.printed_page_verified,p.raw_text page_raw_text,p.text_sha256 page_text_sha256,p.flags_json,s.path source_path,s.sha256 source_sha256,s.country,s.carrier_role,s.family,s.metadata_json FROM chunk c JOIN page p USING(page_id) JOIN source s USING(source_id) WHERE c.chunk_id=?''',(chunk_id,)).fetchone()
        if r is None:raise KeyError(chunk_id)
        x=dict(r);x['raw_excerpt']=x.pop('raw_text');x['chunk_text_sha256']=x.pop('text_sha256');x['quality_flags']=json.loads(x.pop('flags_json'));x['source_metadata']=json.loads(x.pop('metadata_json'))
        raw=x.pop('page_raw_text');x['chunk_slice_matches_page']=raw[x['start_char']:x['end_char']]==x['raw_excerpt']
        x['locator']={'kind':'PDF_page_1_based','pdf_page':x['pdf_page'],'pdf_page_label':x['pdf_page_label'],'printed_page_verified':x['printed_page_verified'],'character_offsets_in_extracted_page':[x['start_char'],x['end_char']]}
        x['authority']=({'unverified_chinese_translation':'auxiliary_unverified_translation_not_original_truth','unverified_local_ocr':'auxiliary_unverified_local_OCR_not_original_truth'}.get(x['carrier_role'],'original_language_carrier_text_layer_not_botanical_validation'))
        if x['carrier_role']=='unverified_local_ocr':
            d=self.db.execute('SELECT derivation_json FROM ocr_line WHERE chunk_id=?',(chunk_id,)).fetchone();x['ocr_derivation']=json.loads(d[0]) if d else None
        if x['carrier_role']=='unverified_chinese_translation':
            a=self.db.execute('SELECT * FROM alignment WHERE translation_page_id=?',(x['page_id'],)).fetchone();x['original_correspondence']=dict(a) if a else None
            if x['original_correspondence']:x['original_correspondence']['evidence']=json.loads(x['original_correspondence'].pop('evidence_json'))
        else:
            a=self.db.execute('SELECT translation_page_id,relation_status,evidence_json FROM alignment WHERE original_source_id=? AND original_pdf_page=?',(x['source_id'],x['pdf_page'])).fetchall();x['chinese_correspondence']=[{'translation_page_id':r[0],'status':r[1],'evidence':json.loads(r[2])} for r in a]
        x['automatic_replacement_allowed']=False;x['requires_source_page_review']=True;x['source_snapshot_verification']='build_time_sha256; rehash source before external reliance'
        x['index_version']=self.metadata['summary']['version'];x['screening_revision']=self.revision['screening_revision'] if self.revision else None;x['database_sha256']=self.revision['database_sha256'] if self.revision else None
        return x
    def query(self,text,*,field='fulltext',country=None,top_k=5,source_line_ids=None,include_translations=False,include_ocr=False):
        if not 1<=top_k<=50:raise ValueError('top_k must be 1..50')
        if not isinstance(text,str) or len(text)>512:raise ValueError('text must be a string of at most 512 characters')
        st=time.perf_counter();q=' '.join(unicodedata.normalize('NFC',str(text)).split())
        result={'index_version':self.metadata['summary']['version'],'collection_boundary':'new_flora_sidecar_only','field':field,'field_raw':text,'source_line_ids':source_line_ids or [],'field_normalized':None,'automatic_replacement_allowed':False,'primary_candidates':[],'auxiliary_translation_candidates':[],'auxiliary_ocr_candidates':[],'answer_status':'refused','refusal_reasons':[],'trace':{'query_normalization':'NFC and whitespace search key only; source raw text preserved','country_filter':country,'fts_attempts':[]},'limitations':['located text is not independent botanical validation','PDF page number is not a verified printed page number','unverified Chinese translation cannot establish original wording','unverified OCR remains a low-confidence locator with possible missing/merged lines','no specimen catalogue input, LLM inference or final-test data used']}
        result['screening_revision']=self.revision['screening_revision'] if self.revision else None;result['database_sha256']=self.revision['database_sha256'] if self.revision else None
        if field not in SUPPORTED:result['refusal_reasons'].append('unsupported_field_for_flora_sidecar');return result
        if len(q)<3 or not re.search(r'[^\W_]',q,re.UNICODE):result['refusal_reasons'].append('query_too_short_or_no_lexical_content');return result
        where=' AND s.country=?' if country else '';params=[country.upper()] if country else []
        roles=['original_language_carrier']+(['unverified_chinese_translation'] if include_translations else [])+(['unverified_local_ocr'] if include_ocr else [])
        where+=' AND s.carrier_role IN ('+','.join('?' for _ in roles)+')';params.extend(roles)
        phrase='"'+q.replace('"','""')+'"'
        tokens=re.findall(r'[^\W_]+',q,re.UNICODE)
        # AND fallback is a conservative lexical locator, never a semantic answer.
        modes=[('trigram_phrase','chunks_trigram',phrase)]
        if tokens and not (len(tokens)==1 and any('\u3400'<=c<='\u9fff' for c in q)):
            modes.append(('unicode61_all_tokens','chunks_words',' AND '.join('"'+t.replace('"','""')+'"' for t in tokens)))
        found={}
        for mode,table,expression in modes:
            rows=self.db.execute(f'''SELECT c.chunk_id,bm25({table}) rank,s.carrier_role FROM {table} JOIN chunk c ON c.rowid={table}.rowid JOIN page p USING(page_id) JOIN source s USING(source_id) WHERE {table} MATCH ? {where} ORDER BY rank,c.chunk_id LIMIT ?''',[expression,*params,max(100,top_k*20)]).fetchall()
            result['trace']['fts_attempts'].append({'method':mode,'expression':expression,'returned_candidates':len(rows)})
            for r in rows:found.setdefault(r[0],{'chunk_id':r[0],'rank':r[1],'method':mode,'carrier_role':r[2]})
            # Continue fallback only if phrase found no excerpts.
            if rows:break
        seen_pages=set();seen_text_hashes=set();duplicate_text_suppressed=0
        for hit in sorted(found.values(),key=lambda x:(x['rank'],x['chunk_id'])):
            e=self.evidence(hit['chunk_id']);key=({'unverified_chinese_translation':'auxiliary_translation_candidates','unverified_local_ocr':'auxiliary_ocr_candidates'}.get(e['carrier_role'],'primary_candidates'))
            if e['page_id'] in seen_pages or len(result[key])>=top_k:continue
            if e['chunk_text_sha256'] in seen_text_hashes:
                duplicate_text_suppressed+=1;continue
            seen_pages.add(e['page_id']);seen_text_hashes.add(e['chunk_text_sha256']);e['retrieval_method']=hit['method'];e['bm25_rank']=hit['rank'];result[key].append(e)
        if result['primary_candidates']:result['answer_status']='located_original_language_excerpts_requires_review'
        elif result['auxiliary_translation_candidates']:result['answer_status']='auxiliary_translation_only_original_answer_refused';result['refusal_reasons'].append('only_unverified_translation_evidence_found')
        elif result['auxiliary_ocr_candidates']:result['answer_status']='unverified_derived_ocr_only_original_answer_refused';result['refusal_reasons'].append('only_unverified_local_ocr_found')
        else:result['refusal_reasons'].append('no_lexical_evidence_in_indexed_text')
        if country:
            n=self.db.execute("SELECT COUNT(*) FROM source WHERE country=? AND carrier_role='original_language_carrier' AND source_id IN (SELECT source_id FROM page WHERE indexable=1)",(country.upper(),)).fetchone()[0]
            if not n:result['refusal_reasons'].append('requested_country_has_no_indexed_original_language_carrier')
        result['trace']['duplicate_text_candidates_suppressed']=duplicate_text_suppressed
        result['trace']['elapsed_ms']=round((time.perf_counter()-st)*1000,3)
        return result

def composed_query(text,legacy_db=None,**kwargs):
    rag=FloraRetriever(kwargs.pop('db',DEFAULT_DB))
    try:res=rag.query(text,**kwargs)
    finally:rag.close()
    if legacy_db:
        # Import the frozen read-only API, explicitly preserving its own collection identity.
        sys.path.insert(0,str(ROOT/'tool'));from p10_rag.retrieve import Retriever,FIELD_DOMAIN
        if kwargs.get('field','fulltext') not in FIELD_DOMAIN:
            return {'route':'parallel_read_only_collections','scores_combined':False,'new_flora':res,'legacy_p10':{'collection_version':'p10_index_20261012_01','path':str(Path(legacy_db).resolve()),'status':'skipped_unsupported_field','supported_fields':sorted(FIELD_DOMAIN)},'automatic_replacement_allowed':False}
        old=Retriever(legacy_db)
        try:legacy=old.query(kwargs.get('field','taxon'),text,top_k=kwargs.get('top_k',5),source_line_ids=kwargs.get('source_line_ids',[]),context={'country':kwargs.get('country')} if kwargs.get('country') else {})
        finally:old.close()
        return {'route':'parallel_read_only_collections','scores_combined':False,'new_flora':res,'legacy_p10':{'collection_version':'p10_index_20261012_01','path':str(Path(legacy_db).resolve()),'result':legacy},'automatic_replacement_allowed':False}
    return res

def profile_query(text,profile,**kwargs):
    cfg=json.loads(Path(profile).read_text(encoding='utf-8'));params={**cfg.get('defaults',{}),**kwargs}
    include_ocr=params.pop('include_ocr',False)
    result=composed_query(text,db=ROOT/cfg['flora_db'],legacy_db=ROOT/cfg['legacy_db'] if cfg.get('legacy_db') else None,**params)
    if include_ocr and cfg.get('ocr_db'):
        ocr=FloraRetriever(ROOT/cfg['ocr_db'])
        try:result['derived_ocr_pilot']=ocr.query(text,**{**params,'include_translations':False,'include_ocr':True})
        finally:ocr.close()
    return {'profile_id':cfg['profile_id'],'collections':cfg['collections'],'result':result,'derived_ocr_enabled':include_ocr}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--db',type=Path,default=DEFAULT_DB);p.add_argument('--profile',type=Path);p.add_argument('--text');p.add_argument('--evidence-id');p.add_argument('--field',default='fulltext');p.add_argument('--country');p.add_argument('--top-k',type=int,default=5);p.add_argument('--include-translations',action='store_true');p.add_argument('--include-ocr',action='store_true');p.add_argument('--legacy-db',type=Path);p.add_argument('--source-line-id',action='append',default=[]);p.add_argument('--output',type=Path);a=p.parse_args()
    if a.evidence_id:
        r=FloraRetriever(a.db)
        try:o=r.evidence(a.evidence_id)
        finally:r.close()
    elif a.text is not None:
        params={'field':a.field,'country':a.country,'top_k':a.top_k,'source_line_ids':a.source_line_id,'include_translations':a.include_translations,'include_ocr':a.include_ocr}
        o=profile_query(a.text,a.profile,**params) if a.profile else composed_query(a.text,legacy_db=a.legacy_db,db=a.db,**params)
    else:p.error('provide --text or --evidence-id')
    txt=json.dumps(o,ensure_ascii=False,indent=2)+'\n'
    if a.output:
        with a.output.open('x',encoding='utf-8') as f:f.write(txt)
    else:print(txt,end='')
