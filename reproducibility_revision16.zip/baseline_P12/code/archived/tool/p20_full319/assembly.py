"""Reference-free multiline baseline and source-preserving LLM assembly."""
from __future__ import annotations

import re
import sys

from .common import FIELDS, ROOT

sys.path.insert(0, str(ROOT / 'tool/src'))
from plant_specimen_prep.ocr_text_assembly import visual_lines_for_display


def make_blocks(record):
    # The combined stream already contains the accepted Paddle/P06 blocks.
    # Using all ocr_lines would duplicate Paddle text and mix alternatives.
    lines = sorted((x for x in record['ocr_lines']
                    if x['route'] == 'paddle_main_plus_p06'),
                   key=lambda x: (x.get('path_order', 0), x['route_order_index']))
    rows = visual_lines_for_display(lines)
    visual_row = {lid: r['visual_line_index'] + 1 for r in rows
                  for lid in r['line_ids_saved_order']}
    return [{'block_id': f'b{i + 1:03d}', 'source_line_id': x['line_id'],
             'text': x.get('raw_prediction') or '', 'status': x['status'],
             'bbox': x.get('bbox_xyxy_oriented'),
             'visual_row': visual_row[x['line_id']],
             'source_order': x['route_order_index'],
             'path_id': x['path_id'], 'label_id': x['label_id']}
            for i, x in enumerate(lines)]


def reconstruct(selection, blocks):
    """Only source substrings and explicit whitespace joins can enter arm B."""
    by_id = {b['block_id']: b for b in blocks}
    result = {}
    for field in FIELDS:
        proposed = selection['fields'][field]
        parts, text = [], ''
        used = set()
        for part in proposed['parts']:
            block = by_id[part['block_id']]
            quote = part.get('quote')
            raw = block['text']
            if quote is None:
                start, end = 0, len(raw)
            else:
                if not quote or raw.count(quote) != 1:
                    raise ValueError(f'{field}/{block["block_id"]}: quote must be an exact unique substring')
                start, end = raw.index(quote), raw.index(quote) + len(quote)
            origin = (block['block_id'], start, end)
            if origin in used:
                raise ValueError(f'{field}: repeated source span {origin}')
            used.add(origin)
            sep = part.get('separator_before', ' ') if parts else ''
            if sep not in ('', ' ', '\n'):
                raise ValueError('Join separators must be empty, space or newline')
            text += sep + raw[start:end]
            parts.append({'block_id': block['block_id'], 'source_line_id': block['source_line_id'],
                          'start': start, 'end': end, 'quote': raw[start:end],
                          'separator_before': sep})
        result[field] = {'raw_text': text, 'label_text': text, 'parts': parts,
                         'normalized_candidate': None, 'evidence_ids': [],
                         'reason': proposed.get('reason', ''), 'status': 'assembled' if parts else 'not_found'}
    return result


# The baseline joins complete visual rows and locality continuation rows. Rules
# depend only on script, field labels, dates and geometry, never Excel strings.
GEO = re.compile(r'\b(?:обл|рай|р-н|хреб|хр\.|долин|долна|басс|перев|ущел|окр|ур\.|берег|береч|гора|горы|Тянь|Гянь|Памир|Алай|Ферган|Заравш|Туркест|Центральн|север|южн|восточ|запад|mont|prov|regio|distr|flum|vall|prope|ad\b|in\b)|\bр\.', re.I)
DATE = re.compile(r'\b\d{1,2}\s*[/.,-]\s*(?:[IVXІХⅤⅦⅧ]+|\d{1,2})\s*[/.,-]|\b(?:18|19|20)\d{2}\b', re.I)
COLLECTOR = re.compile(r'(?:(?:leg|coll|собр|собрал|собрала)\.?\s*[:：]?\s*)(.+)', re.I)
INITIALS = re.compile(r'(?:[A-ZА-ЯЁ]\s*\.\s*){1,3}[A-ZА-ЯЁ][a-zа-яё-]{3,}(?:\s*(?:,|и|&)\s*.+)?')
BINOMIAL = re.compile(r'\b[A-Z][a-z]{3,}\s+[a-z][a-z-]{3,}\b')
HEADER = re.compile(r'гербар|herbar|институт|академ|экс[пн]еди|флора|flora|univers|ТашГ|САНИ', re.I)


def baseline(blocks):
    rows = {}
    for b in blocks:
        rows.setdefault(b['visual_row'], []).append(b)
    grouped = []
    for _, row in sorted(rows.items()):
        row.sort(key=lambda b: b['bbox'][0] if b['bbox'] else b['source_order'])
        grouped.append((row, ' '.join(b['text'] for b in row)))
    selected = {f: {'parts': [], 'reason': '预设规则：同一视觉行拼接，地点连续行延伸，日期及采集人作为边界。'} for f in FIELDS}
    taxon_rows, collector_rows = set(), set()
    for i, (row, text) in enumerate(grouped):
        # Scientific names may be split between OCR blocks on the same row.
        if BINOMIAL.search(text) and not GEO.search(text) and not HEADER.search(text) and not DATE.search(text):
            if not selected['scientific_name']['parts']:
                selected['scientific_name']['parts'] = [{'block_id': b['block_id'], 'quote': None} for b in row]
                taxon_rows.add(i)
        for b in row:
            match = COLLECTOR.search(b['text']) or INITIALS.search(b['text'])
            if match and i not in taxon_rows:
                quote = match.group(1) if match.lastindex else match.group(0)
                if not re.search(r'[^\W\d_]', quote):
                    continue
                selected['collector']['parts'].append({'block_id': b['block_id'], 'quote': quote})
                collector_rows.add(i)
    starts = [i for i, (_, t) in enumerate(grouped)
              if GEO.search(t) and not HEADER.search(t) and i not in taxon_rows | collector_rows]
    if starts:
        start = starts[0]
        for i in range(start, len(grouped)):
            row, text = grouped[i]
            if i in taxon_rows | collector_rows or DATE.search(text) or HEADER.search(text):
                break
            selected['locality']['parts'].extend({'block_id': b['block_id'], 'quote': None} for b in row)
    return reconstruct({'fields': selected}, blocks)
