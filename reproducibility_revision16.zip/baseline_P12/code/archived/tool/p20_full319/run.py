import argparse
import json
import shutil
import time
import threading
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor, as_completed
from p18_llm_rag.assembly import reconstruct
from p18_llm_rag.run import corrected
from p18_llm_rag.vision import validate
from .common import *
from .prompts import *
from .gateway import complete
from .rag import retrieve

ERRORS=(RuntimeError,ValueError,KeyError,TypeError)
API_SLOTS=threading.Semaphore(4)
START_LOCK=threading.Lock()
LAST_START=0.0

def limited_complete(*args,**kwargs):
    global LAST_START
    with API_SLOTS:
        with START_LOCK:
            delay=max(0,1.1-(time.perf_counter()-LAST_START))
            if delay:time.sleep(delay)
            LAST_START=time.perf_counter()
        return complete(*args,**kwargs)

def presence(response):
    if response['scientific_name_presence'] not in ('present','absent','uncertain'):
        raise ValueError('Unsupported visibility status')
    return response

def call(sid,arm,model,system,user,schema,validator,image=None):
    cache=OUT/'intermediate'/sid/f'{arm}_{model}.json'
    if cache.exists():return read(cache)
    last='No attempt available'
    prior=sorted((OUT/'api'/sid).glob(f'{arm}_{model}_*.json'))
    def rejected(r):
        return 'Gateway HTTP 429' in r.get('error','') or r.get('status')=='started'
    inference_attempts=sum(not rejected(read(p)) for p in prior)
    transport_retries=0
    for attempt in range(len(prior)+1,len(prior)+7):
        if inference_attempts>=2 or transport_retries>=4:break
        log=OUT/'api'/sid/f'{arm}_{model}_{attempt:02d}.json'
        try:
            response,meta=limited_complete(model,system,user,log,schema,image_path=image,
                max_tokens=1024 if arm=='P' else 4096)
            fields=validator(response)
            result={'status':'ok','fields':fields,'api':meta}
            save(cache,result)
            return result
        except ERRORS as exc:
            last=str(exc)
            if log.exists():
                receipt=read(log);receipt.update(validation_error=last,status='failed');save(log,receipt)
            print(json.dumps({'sample_id':sid,'arm':arm,'model':model,'attempt':attempt,'failed':last[:180]},ensure_ascii=False),flush=True)
            if 'Gateway HTTP 429' in last:
                transport_retries+=1;time.sleep(3*transport_retries)
            else:inference_attempts+=1
    raise RuntimeError(last)

def rag_cached(sid,branch,model,fields):
    path=OUT/'retrieval'/sid/f'{branch}_{model}.json'
    if path.exists():return read(path)
    rag=retrieve(fields,sid);rag['query_source']='B_OCR_fields' if branch=='D' else 'E_image_fields'
    save(path,rag)
    return rag

def run_one(sid):
    target=OUT/'results'/f'{sid}.json'
    if target.exists():return {'sample_id':sid,'status':'cached'}
    started=time.perf_counter()
    item=read(OUT/'inputs'/f'{sid}.json')
    result={'sample_id':sid,'split':item['split'],'A':item['A'],'attempts':[]}
    if not item['image']:
        result.update({a:{'status':'upstream_failed'} for a in 'BCDEF'})
        result['presence']={'status':'no_image','fields':{'scientific_name_presence':'uncertain','reason':'原冻结流程未检测到主标签'}}
        save(target,result);return {'sample_id':sid,'status':'upstream_failed'}
    image=Path(item['image']['path'])
    # This first call receives only the image and a visibility instruction.
    for model in (PRIMARY,FALLBACK):
        try:
            result['presence']=call(sid,'P',model,PRESENCE_SYSTEM,{},PRESENCE_SCHEMA,presence,image)
            break
        except ERRORS as exc:result['attempts'].append({'arm':'P','model':model,'error':str(exc)})
    result.setdefault('presence',{'status':'failed','fields':{'scientific_name_presence':'uncertain','reason':'可见性筛查失败'}})
    blocks=[{k:b[k] for k in ('block_id','text','bbox','visual_row')} for b in item['blocks']]
    for model in (PRIMARY,FALLBACK):
        try:
            result['B']=call(sid,'B',model,B_SYSTEM,{'blocks':blocks},B_SCHEMA,lambda p:reconstruct(p,item['blocks']))
            break
        except ERRORS as exc:result['attempts'].append({'arm':'B','model':model,'error':str(exc)})
    result.setdefault('B',{'status':'failed'})
    if result['B']['status']=='ok':
        fixed=result['B']['fields']
        payload={'blocks':blocks,'fixed_fields':{f:{'raw_text':fixed[f]['raw_text'],'source_parts':fixed[f]['parts']} for f in FIELDS}}
        rag=rag_cached(sid,'D',result['B']['api']['requested_model'],fixed)
        for model in (PRIMARY,FALLBACK):
            try:
                pair={}
                for arm,evidence in [('C',[]),('D',rag['evidence'])]:
                    pair[arm]=call(sid,arm,model,CORRECTION_SYSTEM,{**payload,'evidence':evidence},
                        CORRECTION_SCHEMA,lambda p:corrected(p,fixed,evidence))
                if pair['C']['api']['reported_model']!=pair['D']['api']['reported_model']:
                    raise ValueError('C/D reported models differ')
                result.update(pair);result['CD_model']=model;result['D_retrieval_seconds']=rag['seconds']
                break
            except ERRORS as exc:result['attempts'].append({'arm':'CD','model':model,'error':str(exc)})
    for arm in 'CD':result.setdefault(arm,{'status':'failed_pair' if result['B']['status']=='ok' else 'not_run_B_failed'})
    for model in (PRIMARY,FALLBACK):
        try:
            e=call(sid,'E',model,VISION_SYSTEM,{'evidence':[]},VISION_SCHEMA,lambda p:validate(p,[]),image)
            rag=rag_cached(sid,'F',model,e['fields'])
            f=call(sid,'F',model,VISION_SYSTEM,{'evidence':rag['evidence']},VISION_SCHEMA,lambda p:validate(p,rag['evidence']),image)
            if e['api']['reported_model']!=f['api']['reported_model']:raise ValueError('E/F reported models differ')
            result.update(E=e,F=f,EF_model=model,F_retrieval_seconds=rag['seconds'])
            break
        except ERRORS as exc:result['attempts'].append({'arm':'EF','model':model,'error':str(exc)})
    for arm in 'EF':result.setdefault(arm,{'status':'failed_pair'})
    result['pipeline_seconds']=time.perf_counter()-started
    save(target,result)
    return {'sample_id':sid,'arms':{a:result[a]['status'] for a in ARMS},
            'presence':result['presence']['fields']['scientific_name_presence'],
            'seconds':round(result['pipeline_seconds'],1)}

def freeze():
    files=list(Path(__file__).parent.glob('*.py'))
    files += [ROOT/'tool/p18_llm_rag'/f for f in ['common.py','gateway.py','assembly.py','prompts.py','run.py','vision.py']]
    files += list((ROOT/'tool/p19_reference_rag').glob('*.py'))
    files += [ROOT/'tool/p10_rag'/f for f in ['retrieve.py','common.py']]
    files += [ROOT/'tool/p16_flora_rag/retrieve.py']
    config={'primary':PRIMARY,'fallback':FALLBACK,'protocol_sha256':digest(OUT/'protocol.json'),
        'B_system':B_SYSTEM,'CD_system':CORRECTION_SYSTEM,'EF_system':VISION_SYSTEM,
        'presence_system':PRESENCE_SYSTEM,'max_tokens':4096,'presence_max_tokens':1024,
        'attempts_per_model':2,'code_sha256':{str(p.relative_to(ROOT)):digest(p) for p in files}}
    path=OUT/'run_config.json'
    if path.exists():
        # Report/evaluation additions do not alter the frozen inference functions.
        old=read(path)
        for p,h in old['code_sha256'].items():
            if digest(ROOT/p)!=h:raise ValueError('Frozen inference file changed: '+p)
    else:
        save(path,config)
        for p in files:
            dst=OUT/'code_snapshot'/p.relative_to(ROOT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)

def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--ids',nargs='+')
    args=p.parse_args();freeze()
    allowed=[x['sample_id'] for x in read(OUT/'manifest.json')['samples']]
    ids=args.ids or allowed
    assert set(ids)<=set(allowed)
    started=time.perf_counter();stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    run={'started_at':datetime.now(timezone.utc).isoformat(),'workers':args.workers,'ids':ids,'status':'running'}
    save(OUT/'sessions'/f'{stamp}.json',run)
    crashes=[]
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(run_one,sid):sid for sid in ids}
        for future in as_completed(futures):
            try:print(json.dumps(future.result(),ensure_ascii=False),flush=True)
            except Exception as exc:
                error={'sample_id':futures[future],'runner_error':repr(exc)};crashes.append(error)
                print(json.dumps(error,ensure_ascii=False),flush=True)
    run.update(status='completed' if not crashes else 'runner_errors',errors=crashes,
               seconds=time.perf_counter()-started,finished_at=datetime.now(timezone.utc).isoformat())
    save(OUT/'sessions'/f'{stamp}.json',run)
    print(json.dumps({'session_seconds':run['seconds'],'runner_errors':len(crashes)},ensure_ascii=False))

if __name__=='__main__':main()
