"""One logged attempt; credentials never enter a receipt."""
import base64
import copy
import hashlib
import json
import os
import re
import time
from datetime import datetime, timezone
from p18_llm_rag.gateway import request
from .common import BASE_URL, digest, save

def complete(model, system, user, log_path, schema, image_path=None, max_tokens=4096):
    if log_path.exists():
        raise FileExistsError(str(log_path))
    message={'role':'user','content':json.dumps(user,ensure_ascii=False)}
    image_meta=None
    if image_path:
        mime='image/webp' if image_path.suffix=='.webp' else 'image/png'
        image_meta={'path':str(image_path),'sha256':digest(image_path),'bytes':image_path.stat().st_size,'media_type':mime}
        encoded=base64.b64encode(image_path.read_bytes()).decode('ascii')
        block=({'type':'image','source':{'type':'base64','media_type':mime,'data':encoded}}
               if model.startswith('claude-') else
               {'type':'image_url','image_url':{'url':f'data:{mime};base64,'+encoded,'detail':'original'}})
        message['content']=[block,{'type':'text','text':message['content']}]
    if model.startswith('claude-'):
        endpoint='/messages'
        payload={'model':model,'max_tokens':max_tokens,'stream':False,
            'thinking':{'type':'between_tools'},
            'output_config':{'effort':'medium','format':{'type':'json_schema','schema':schema}},
            'system':system,'messages':[message]}
    else:
        endpoint='/chat/completions'
        payload={'model':model,'temperature':0,'max_tokens':max_tokens,'stream':False,
            'thinking':{'type':'disabled'},'response_format':{'type':'json_object'},
            'messages':[{'role':'system','content':system},message]}
    logged=copy.deepcopy(payload)
    if image_meta:
        b=logged['messages'][-1]['content'][0]
        marker='@local_image_sha256:'+image_meta['sha256']
        if model.startswith('claude-'):b['source']['data']=marker
        else:b['image_url']['url']=marker
    receipt={'requested_model':model,'endpoint':BASE_URL+endpoint,
        'started_at':datetime.now(timezone.utc).isoformat(),'request':logged,
        'request_sha256':hashlib.sha256(json.dumps(payload,ensure_ascii=True).encode()).hexdigest(),
        'image':image_meta,'status':'started'}
    save(log_path,receipt)
    t=time.perf_counter()
    try:
        response,elapsed=request(endpoint,payload)
        receipt.update(response=response,seconds=elapsed,status='received')
        save(log_path,receipt)
        if endpoint=='/messages':
            content=''.join(b['text'] for b in response['content'] if b['type']=='text')
            finish=response.get('stop_reason')
        else:
            content=response['choices'][0]['message']['content']
            finish=response['choices'][0].get('finish_reason')
        parsed=json.loads(re.sub(r'^```(?:json)?\s*|\s*```$','',content.strip()))
        if finish in ('length','max_tokens'):raise ValueError('Output truncated')
        return parsed,{'requested_model':model,'reported_model':response.get('model'),
            'usage':response.get('usage',{}),'seconds':elapsed,'receipt':str(log_path)}
    except (RuntimeError,ValueError,KeyError,TypeError) as exc:
        receipt.update(status='failed',error=str(exc).replace(os.environ.get('ZHI_API_KEY','__NO_KEY__'),'[REDACTED]'))
        raise
    finally:
        receipt.setdefault('seconds',round(time.perf_counter()-t,3))
        receipt['finished_at']=datetime.now(timezone.utc).isoformat()
        save(log_path,receipt)
