from pathlib import Path
from p18_llm_rag.common import ROOT, EXP, FIELDS, PRIMARY, FALLBACK, BASE_URL, OCR_SOURCE, EXCEL, FLORA_DB, digest, read, save

OUT = EXP / 'H_full319_rag_20261020_01'
ARMS = tuple('ABCDEF')
PROTOCOL = {
    'version': 'full319_v1', 'unit': 'specimen', 'n': 319,
    'arms': {'A': 'frozen multiline OCR rules', 'B': 'LLM exact OCR substring assembly',
             'C': 'B plus LLM OCR correction', 'D': 'B plus same LLM correction and P19 external-only RAG',
             'E': 'direct reading of oriented primary-label image',
             'F': 'same image and model, plus P19 RAG queried only from E'},
    'reference': 'Original human Excel 主表 AE scientific_name, L locality, F collector; one row per barcode.',
    'evaluation_target': 'label_text, never normalized_candidate; automated catalogue agreement, not adjudicated transcription accuracy',
    'normalization': 'NFC, casefold, ё→е; ignore whitespace and punctuation. No transliteration, spelling repair, synonym mapping or reference-dependent substitutions.',
    'scientific_name': 'Exact botanical core (genus, epithet, optional infra-rank/epithet); ignore authors; preserve cf/aff/sp/spp/question qualifiers. Genus-only never equals species.',
    'locality': '1 - Levenshtein distance / max normalized character length >= 0.85. Order preserved; whole field, including geography/habitat/elevation.',
    'collector': 'Exact multiset of surname/word tokens of length >=2, ignoring order and standalone initials. This is surname-level agreement, not verified person identity. Full normalized exact agreement also reported.',
    'strict_secondary': 'Full-field normalized exact equality for all three fields, retaining authors and initials.',
    'empty_reference': 'Exclude unknown reference values; do not score empty-empty as correct.',
    'failed_output': 'Any unavailable or failed arm counts as incorrect on every otherwise eligible field; do not drop failed cases.',
    'primary_denominator': 'All reference-known records: scientific_name319/locality319/collector314, including upstream image failure.',
    'name_visibility_sensitivity': 'Separate blind image-only presence audit, before extraction, no OCR/Excel/arm outputs. present/absent/uncertain. Present-only name agreement uses one common denominator for A-F. Absence is provisional automatic screening, never inferred from all-empty outputs.',
    'scope': 'Frozen primary_top1 oriented label crop, not all slips on full specimen. No crop for TASH117052: retain as upstream failure; do not infer absent name.',
    'retrieval': 'P19 external_only=True, catalogue vocabulary and joint-record context entirely disabled; original-language flora only, no translated or derived OCR evidence.',
    'image_policy': 'Use unchanged PNG pixels. PNGs over 7.4MB losslessly re-encoded as WebP, pixel equality checked; no resizing.',
    'fallback': 'Primary claude-sonnet-5-5; fallback deepseek-flash. At most two attempts per arm per model (identical input); C/D and E/F selected only as same-model pairs. All attempts retained. No accuracy-driven retry.',
    'reporting': 'Pooled and pre-existing split strata; these previously exposed samples are not a fresh blinded test. Descriptive estimates only; no post-hoc threshold tuning.',
    'cost': {'input_usd_per_million': 2, 'output_usd_per_million': 10,
             'source': 'https://platform.claude.com/docs/en/about-claude/pricing', 'checked_date': '2026-10-20',
             'meaning': 'Sonnet 5.5 standard uncached-rate equivalent from returned usage, not gateway invoice. F includes E dependency; C/D include B dependency. Actual experiment ledger counts shared calls once. Audit separate. Missing usage is unknown, not zero.'}
}
