import time
from p19_reference_rag.retrieve import ReferenceRetriever
from p16_flora_rag.retrieve import FloraRetriever
from .common import *

DOMAIN={'scientific_name':'taxon','locality':'place','collector':'collector'}

def retrieve(fields, sid):
    started=time.perf_counter()
    config=read(OUT/'manifest.json')['rag_config']
    retriever=ReferenceRetriever(ROOT/config['reference_database'], ROOT/config['external_database'])
    flora=FloraRetriever(FLORA_DB)
    evidence=[]; trace={}; flora_trace=[]
    try:
        for field in FIELDS:
            value=fields[field].get('raw_text',fields[field].get('label_text',''))
            result=retriever.query(DOMAIN[field],value[:2000],top_k=2,
                exclude_specimen_id=None,external_only=True)
            trace[field]=result
            candidates=[];seen=set()
            for fragment in result.get('fragments',[]):
                for c in fragment['candidates']:
                    assert c['origin']=='external_name_source' and c['context_boost']==0 and c['joint_support_records']==0
                    if c['candidate_id'] not in seen:
                        candidates.append(c);seen.add(c['candidate_id'])
            for c in candidates[:12 if field=='locality' else 3]:
                evidence.append({'id':f'R{len(evidence)+1:03d}', 'field':field,
                    'kind':'external_name_candidate','query_fragment':c['query_fragment'],
                    'canonical_name':c['name'],'matched_name':c['matched_name'],
                    'lexical_score':c['lexical_score'],'accepted_name_candidate':c.get('accepted_name_candidate'),
                    'warnings':c['warnings'],'sources':c['sources'][:2]})
            if field!='collector' and value.strip():
                queries=[x['text'] for x in result.get('fragments',[])][:3] or [value[:512]]
                hits={}
                for q in queries:
                    fr=flora.query(q[:512],field=DOMAIN[field],top_k=1,include_translations=False,include_ocr=False)
                    flora_trace.append({'field':field,'query':q,'status':fr['answer_status'],'seconds':fr['trace']['elapsed_ms']/1000})
                    for h in fr['primary_candidates']:hits.setdefault(h['chunk_id'],h)
                for h in list(hits.values())[:1]:
                    evidence.append({'id':f'R{len(evidence)+1:03d}','field':field,
                        'kind':'original_flora_excerpt','text':h['raw_excerpt'][:1600],
                        'excerpt_truncated':len(h['raw_excerpt'])>1600,
                        'sources':[{'source_file':h['source_path'],'source_file_sha256':h['source_sha256'],
                                    'locator':h['locator'],'chunk_id':h['chunk_id'],'authority':h['authority']}]})
    finally:
        retriever.close();flora.close()
    return {'sample_id':sid,'catalogue_included':False,'external_only':True,
        'joint_record_context':False,'query_trace':trace,'flora_trace':flora_trace,
        'translations_included':False,'derived_ocr_included':False,
        'evidence':evidence,'seconds':time.perf_counter()-started}
