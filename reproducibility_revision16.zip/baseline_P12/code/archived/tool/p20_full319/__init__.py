"""Frozen full-cohort comparison with catalogue-free retrieval."""
