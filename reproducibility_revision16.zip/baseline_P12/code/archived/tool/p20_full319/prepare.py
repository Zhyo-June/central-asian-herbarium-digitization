import json
import shutil
import time
from datetime import datetime, timezone
from PIL import Image
import openpyxl
from .assembly import baseline, make_blocks
from .common import *

def main():
    if (OUT/'manifest.json').exists():
        raise FileExistsError('Full cohort already frozen')
    started = time.perf_counter()
    records = [json.loads(x) for x in OCR_SOURCE.open(encoding='utf-8')]
    samples = []
    for r in sorted(records, key=lambda x:x['sample_id']):
        sid = r['sample_id']
        t = time.perf_counter(); blocks = make_blocks(r); block_seconds = time.perf_counter()-t
        t = time.perf_counter(); fields = baseline(blocks); rule_seconds = time.perf_counter()-t
        source = r.get('oriented_image_path')
        asset = None; image_meta = None
        if source:
            source = Path(source)
            asset = OUT/'review/assets'/f'{sid}{".webp" if source.stat().st_size > 7400000 else ".png"}'
            asset.parent.mkdir(parents=True, exist_ok=True)
            if asset.suffix == '.webp':
                with Image.open(source) as im:
                    rgb = im.convert('RGB'); rgb.save(asset, lossless=True, method=6)
                    with Image.open(asset) as encoded:
                        assert rgb.size == encoded.size and rgb.tobytes() == encoded.convert('RGB').tobytes()
            else:
                shutil.copy2(source, asset)
            assert asset.stat().st_size*4/3 < 10000000
            image_meta = {'source': str(source), 'source_sha256': digest(source),
                          'path': str(asset), 'sha256': digest(asset), 'bytes': asset.stat().st_size,
                          'pixels_unchanged': True, 'encoding': asset.suffix}
        item = {'sample_id':sid, 'split':r['split'], 'ocr_status':r['status'],
                'scope':r['scope'], 'blocks':blocks, 'image':image_meta,
                'block_assembly_seconds':block_seconds,
                'A':{'status':'ok' if source else 'upstream_failed', 'fields':fields, 'seconds':rule_seconds}}
        save(OUT/'inputs'/f'{sid}.json', item)
        samples.append({'sample_id':sid,'split':r['split'],'ocr_status':r['status'],
                        'input_sha256':digest(OUT/'inputs'/f'{sid}.json'), 'image':image_meta})
    ids = {x['sample_id'] for x in samples}
    references = {sid:[] for sid in ids}
    w = openpyxl.load_workbook(EXCEL, read_only=True, data_only=True)
    for i, row in enumerate(w['主表'].iter_rows(values_only=True),1):
        sid = ''.join(str(row[2] or '').split()).upper()
        if sid in ids:
            references[sid].append({'sheet':'主表','row':i,'barcode_cell':f'C{i}',
                'fields':{f:{'value':str(row[j]) if row[j] is not None else None,'cell':f'{col}{i}'}
                          for f,col,j in [('scientific_name','AE',30),('locality','L',11),('collector','F',5)]}})
    w.close()
    assert len(samples)==319 and all(len(v)==1 for v in references.values())
    save(OUT/'references.json', {'workbook':str(EXCEL),'sha256':digest(EXCEL),
        'usage':'local evaluation only, never loaded by inference or retrieval','specimens':references})
    config=read(ROOT/'11_rag/current_ocr_reference.json')
    save(OUT/'protocol.json',PROTOCOL)
    save(OUT/'manifest.json', {'created_at':datetime.now(timezone.utc).isoformat(),
        'samples':samples,'source_ocr':str(OCR_SOURCE),'source_sha256':digest(OCR_SOURCE),
        'protocol_sha256':digest(OUT/'protocol.json'),'reference_sha256':digest(OUT/'references.json'),
        'rag_config':config,'databases':{k:{'path':config[k],'sha256':digest(ROOT/config[k])}
            for k in ['reference_database','external_database']},
        'flora_database':{'path':str(FLORA_DB),'sha256':digest(FLORA_DB)},
        'preparation_seconds':time.perf_counter()-started})
    print(json.dumps({'prepared':len(samples),'images':sum(bool(x['image']) for x in samples),
                       'lossless_webp':sum(x['image'] and x['image']['encoding']=='.webp' or 0 for x in samples)},ensure_ascii=False))

if __name__=='__main__':main()
