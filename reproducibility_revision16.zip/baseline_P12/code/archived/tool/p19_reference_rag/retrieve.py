"""Read-only OCR correction candidates with bounded, transparent joint context."""
from __future__ import annotations

import argparse
import difflib
import json
import re
import time
from functools import lru_cache
from pathlib import Path

from p10_rag.retrieve import Retriever
from p10_rag.common import edit_distance
from .build import BASE, DEFAULT, ROOT, read_db
from .parse import key, norm, ocr_key, parse_date, parse_taxon, person_key, split_locality,is_generic_place


class ReferenceRetriever:
    def __init__(self, db_path=DEFAULT/'reference.sqlite3', base_db=BASE):
        self.db=read_db(db_path)
        self.legacy=Retriever(base_db)
        self.metadata=json.loads(self.db.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()[0])

    def close(self):
        self.db.close();self.legacy.close()

    def exclusion(self, specimen_id):
        if not specimen_id:return set()
        sid=re.sub(r'\s+','',specimen_id).upper()
        return {r[0] for r in self.db.execute('''SELECT record_id FROM record WHERE specimen_key=?
            OR content_group IN(SELECT content_group FROM record WHERE specimen_key=?)''',(sid,sid))}

    @lru_cache(maxsize=12000)
    def _mentions(self, term_id):
        return [dict(x) for x in self.db.execute('''SELECT m.raw,m.start,m.end,r.record_id,
             r.specimen_key,r.sheet,r.source_row FROM mention m JOIN record r USING(record_id)
             WHERE m.term_id=? ORDER BY r.source_row,m.mention_id''',(term_id,))]

    @staticmethod
    def similarity(a,b):
        if a==b:return 1.
        if not a or not b:return 0.
        if difflib.SequenceMatcher(None,a,b,autojunk=False).ratio()<.60:return 0.
        return 1-edit_distance(a,b)/max(len(a),len(b))

    def _vocabulary(self,domain,text,excluded):
        query=person_key(text) if domain=='collector' else key(text)
        oq=ocr_key(query,domain)
        if len(query)<3:return []
        if domain=='place' and is_generic_place(query):return []
        pool={}
        for col,value in [('search_key',query),('ocr_key',oq)]:
            for r in self.db.execute(f'SELECT rowid,* FROM term WHERE domain=? AND {col}=?',(domain,value)):
                pool[r['term_id']]=dict(r)
        grams=sorted({oq[i:i+3] for i in range(len(oq)-2) if oq[i:i+3].strip()})
        # Bounded OR query. Exact candidates and nearby alternatives are both retained.
        if grams:
            if len(grams)>40:grams=grams[::max(1,len(grams)//40)][:40]
            expr=' OR '.join('"'+g.replace('"','""')+'"' for g in grams)
            for r in self.db.execute('''SELECT t.rowid,t.* FROM term_fts JOIN term t ON t.rowid=term_fts.rowid
                WHERE term_fts MATCH ? AND t.domain=? ORDER BY bm25(term_fts),t.term_id LIMIT 160''',(expr,domain)):
                pool.setdefault(r['term_id'],dict(r))
        results=[]
        for row in pool.values():
            exact=self.similarity(query,row['search_key'])
            folded=self.similarity(oq,row['ocr_key'])
            similarity=max(exact,folded-.01 if oq!=query or row['ocr_key']!=row['search_key'] else folded)
            if domain=='place' and len(query)>=4 and (' '+query+' ') in (' '+row['search_key']+' '):
                similarity=max(similarity,.93)
            # A five-character OCR token may be a six-character name with one
            # missing letter (similarity 5/6). Keep this common OCR case.
            threshold=.80 if len(query)<=5 else .76
            if similarity<threshold:continue
            mentions=[m for m in self._mentions(row['term_id']) if m['record_id'] not in excluded]
            if not mentions:continue
            sources=[]
            for m in mentions[:3]:
                col='AE' if domain=='taxon' and m['sheet']=='主表' else 'E' if domain=='taxon' else 'L' if domain=='place' else 'F'
                sources.append({'source':'catalogue_observed_form','source_file':'resource/中亚ok.xlsx',
                    'source_sha256':self.metadata['source_workbook_sha256'],
                    'locator':f"{m['sheet']}!{col}{m['source_row']}",'source_span':[m['start'],m['end']],
                    'text':m['raw'],'verification':'unreviewed_name_form'})
            links=[dict(x) for x in self.db.execute('SELECT * FROM authority_link WHERE term_id=?',(row['term_id'],))]
            results.append({'candidate_id':row['term_id'],'name':row['display'],'matched_name':row['display'],
                'domain':domain,'semantic_type':row['semantic_type'],'lexical_score':round(similarity,6),
                'origin':'observed_vocabulary','authority_links':links,'sources':sources,
                'support_records':len({m['record_id'] for m in mentions}),
                'review_required':True,'automatic_replacement_allowed':False,
                'warnings':['catalogue_spelling_not_independent_authority']+
                    (['mixed_script_or_yo_fold_search_hypothesis'] if folded>exact else []),
                '_records':{m['record_id'] for m in mentions},'_key':row['search_key']})
        return sorted(results,key=lambda c:(-c['lexical_score'],c['candidate_id']))[:30]

    @lru_cache(maxsize=2000)
    def _external(self,domain,text,country,year):
        context={}
        if country in {'KZ','KG','TJ','TM','UZ'}:context['country']=country
        if year:context['label_year']=year
        field='collector' if domain=='collector' else domain
        result=self.legacy.query(field,text[:512],top_k=8,include_catalogue=False,context=context)
        out=[]
        for c in result['candidates']:
            out.append({'candidate_id':c['entity_id'],'name':c['canonical_name'],'matched_name':c['matched_span'],
                'domain':domain,'semantic_type':c.get('entity_type'),
                'lexical_score':c['score_components']['edit_similarity'],'origin':'external_name_source',
                'authority_links':[{'entity_id':c['entity_id'],'canonical_name':c['canonical_name'],
                                   'link_status':'name_candidate_not_specimen_identity'}],
                'accepted_name_candidate':c.get('accepted_name_candidate'),
                'sources':c['evidence'][:3],'support_records':0,'review_required':True,
                'automatic_replacement_allowed':False,'warnings':c['review_reasons'],
                '_key':key(c['matched_span']),'_records':set()})
        return out

    def _candidates(self,domain,text,excluded,context,external_only=False):
        output=[]
        qualified=domain=='taxon' and parse_taxon(text)['qualifier']
        if not external_only:
            output+=self._vocabulary(domain,text,excluded)
        date_info=parse_date(str(context.get('date') or ''))
        year=int(date_info['start'][:4]) if date_info['start'] else None
        queries=[text]
        if domain=='taxon':
            tx=parse_taxon(text)
            if qualified and tx['genus']:queries=[tx['genus']]
            elif tx['name']!=text:queries.append(tx['name'])
        oq=ocr_key(text,domain)
        if oq!=key(text):queries.append(oq)
        for q in dict.fromkeys(queries):
            for original in self._external(domain,q,context.get('country'),year):
                c={**original,'warnings':list(original['warnings']),'_records':set()}
                if q!=text:c['warnings'].append('query_variant_preserves_original_input')
                if qualified:
                    if str(c.get('semantic_type','')).casefold() not in {'genus','family'}:continue
                    c['warnings'].append('qualified_name_not_completed_to_species')
                output.append(c)
        if qualified:
            output=[c for c in output if c['origin']=='external_name_source' or
                    (parse_taxon(c['name'])['qualifier'] and key(c['name'])==key(text))]
        # Merge identical reference spellings, preserving all authoritative identity candidates.
        merged={}
        for c in output:
            identity=(c['_key'],c['semantic_type']) if c['origin']=='observed_vocabulary' else ('external',c['candidate_id'])
            previous=merged.get(identity)
            if previous is None or c['lexical_score']>previous['lexical_score']:merged[identity]=c
        return list(merged.values())

    def query(self,field,text,*,context=None,top_k=5,exclude_specimen_id=None,external_only=False):
        if field not in {'taxon','place','collector'}:raise ValueError('field must be taxon, place or collector')
        if not isinstance(text,str) or len(text)>2000:raise ValueError('text must contain at most 2000 characters')
        if not 1<=top_k<=30:raise ValueError('top_k must be 1..30')
        started=time.perf_counter();context=dict(context or {});excluded=self.exclusion(exclude_specimen_id)
        if not text.strip():
            return {'field_raw':text,'field':field,'candidates':[],'status':'missing_input','automatic_replacement_allowed':False}
        prefix=re.match(r'(?i)^\s*(?:место\s+сбора|locality|采集地)\s*[:：]\s*',text) if field=='place' else None
        offset=prefix.end() if prefix else 0
        query_text=text[offset:]
        units=[{'name':query_text,'name_start':offset,'name_end':len(text),'kind':'input'}]
        if field=='place':
            parsed=[dict(x) for x in split_locality(query_text) if x['name']]
            for x in parsed:
                if x['name_start'] is not None:x['name_start']+=offset;x['name_end']+=offset
            if parsed:units=parsed
        # Context support is from other fields of other allowed source records. It never supplies missing OCR text.
        support={}
        for other in ('taxon','place','collector'):
            value=context.get(other) or context.get('locality' if other=='place' else other)
            if external_only or other==field or not value:continue
            context_units=[str(value)]
            if other=='place':context_units=[s['name'] for s in split_locality(str(value)) if s['name']] or context_units
            pool=[]
            for u in context_units[:8]:pool+=self._vocabulary(other,u,excluded)
            strong=[c for c in pool if c['lexical_score']>=.88][:5]
            support[other]=set().union(*(c['_records'] for c in strong)) if strong else set()
        date_info=parse_date(str(context.get('date') or ''))
        if date_info['status']=='parsed' and not external_only:
            support['date']={r[0] for r in self.db.execute('''SELECT record_id FROM record
                WHERE date_start<=? AND date_end>=?''',(date_info['end'],date_info['start']))}-excluded
        all_candidates=[]
        for unit in units[:16]:
            pool=self._candidates(field,unit['name'],excluded,context,external_only)
            # Link external candidates to locally observed forms for contextual support only.
            local_keys={c['_key']:c['_records'] for c in pool if c['origin']=='observed_vocabulary'}
            for c in pool:
                if c['origin']=='external_name_source':
                    c['_records']=local_keys.get(c['_key'],set())
                    if not c['_records'] and not external_only:
                        for t in self.db.execute('SELECT term_id FROM authority_link WHERE entity_id=?',(c['candidate_id'],)):
                            c['_records'].update(m['record_id'] for m in self._mentions(t[0]) if m['record_id'] not in excluded)
                matched={k:len(c['_records']&v) for k,v in support.items()}
                # Also report simultaneous consistency; marginal matches must not fabricate one joint event.
                active=list(support.values())
                joint=len(c['_records'].intersection(*active)) if active else 0
                boost=min(.045,.012*sum(n>0 for n in matched.values())+(.009 if joint else 0))
                c.update(query_span=[unit['name_start'],unit['name_end']],query_fragment=unit['name'],
                    context_matches=matched,joint_support_records=joint,
                    score=round(c['lexical_score']+boost,6),context_boost=round(boost,6),
                    score_is_probability=False)
                c.pop('_records',None);c.pop('_key',None)
                all_candidates.append(c)
        candidates=[];seen=set()
        for c in sorted(all_candidates,key=lambda c:(-c['score'],c['origin']!='external_name_source',
                       c['semantic_type']=='toponym_untyped',-c['support_records'],c['candidate_id'])):
            ident=(c['candidate_id'],tuple(c['query_span']))
            if ident not in seen:candidates.append(c);seen.add(ident)
        fragments=[]
        for unit in units[:16]:
            span=[unit['name_start'],unit['name_end']]
            fragments.append({'text':unit['name'],'span':span,'semantic_type':unit['kind'],
                              'candidates':[c for c in candidates if c['query_span']==span][:top_k]})
        return {'field':field,'field_raw':text,'field_normalized':None,'status':'candidates' if candidates else 'no_match',
            'candidates':candidates[:top_k],'date_context':date_info,'automatic_replacement_allowed':False,
            'fragments':fragments,'unqueried_fragments':max(0,len(units)-16),
            'purpose':'OCR reference candidate calibration; not specimen lookup',
            'exclusion':{'specimen_id':exclude_specimen_id,'same_barcode_and_semantic_group_records':len(excluded)},
            'seconds':round(time.perf_counter()-started,6)}

    def calibrate(self,*,taxon='',locality='',collector='',collection_date='',exclude_specimen_id=None,top_k=5,external_only=False,country=None):
        context={'taxon':taxon,'place':locality,'collector':collector,'date':collection_date,'country':country}
        fields={f:self.query(f,text,context=context,top_k=top_k,exclude_specimen_id=exclude_specimen_id,
                             external_only=external_only) for f,text in [('taxon',taxon),('place',locality),('collector',collector)]}
        return {'purpose':'OCR reference calibration','fields':fields,'date':parse_date(str(collection_date)),
                'source_policy':'external authorities and labelled observed forms; missing OCR stays missing',
                'automatic_replacement_allowed':False}


def llm_reference_context(fields,**kwargs):
    """New opt-in adapter. Does not change the frozen P18 experiment or call a model."""
    def value(k):
        v=fields.get(k,'')
        return v.get('raw_text','') if isinstance(v,dict) else v
    r=ReferenceRetriever()
    try:
        return r.calibrate(taxon=value('scientific_name'),locality=value('locality'),collector=value('collector'),
                           collection_date=value('collection_date'),**kwargs)
    finally:r.close()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--db',type=Path,default=DEFAULT/'reference.sqlite3')
    p.add_argument('--field',choices=['taxon','place','collector']);p.add_argument('--text',default='')
    p.add_argument('--taxon',default='');p.add_argument('--locality',default='');p.add_argument('--collector',default='')
    p.add_argument('--date',default='');p.add_argument('--country');p.add_argument('--exclude-specimen')
    p.add_argument('--external-only',action='store_true');p.add_argument('--top-k',type=int,default=5)
    p.add_argument('--output',type=Path)
    a=p.parse_args();r=ReferenceRetriever(a.db)
    try:
        if a.field:out=r.query(a.field,a.text,context={'taxon':a.taxon,'place':a.locality,'collector':a.collector,'date':a.date,'country':a.country},
            exclude_specimen_id=a.exclude_specimen,external_only=a.external_only,top_k=a.top_k)
        else:out=r.calibrate(taxon=a.taxon,locality=a.locality,collector=a.collector,collection_date=a.date,country=a.country,
            exclude_specimen_id=a.exclude_specimen,external_only=a.external_only,top_k=a.top_k)
    finally:r.close()
    text=json.dumps(out,ensure_ascii=False,indent=2)
    if a.output:
        with a.output.open('x',encoding='utf-8') as f:f.write(text+'\n')
    else:print(text)


if __name__=='__main__':main()
