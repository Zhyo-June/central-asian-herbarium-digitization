"""Conservative, source-span-preserving parsing, with explicit unresolved states."""
from __future__ import annotations

import calendar
import re
import unicodedata
from datetime import date, datetime
from functools import lru_cache


def norm(value):
    return " ".join(unicodedata.normalize("NFC", str(value or "")).split())


def key(value):
    return " ".join(re.findall(r"[^\W_]+", norm(value).casefold(), re.UNICODE))


CYR_LAT = str.maketrans("АВЕКМНОРСТХаеорсухіІ", "ABEKMHOPCTXaeopcyxiI")
LAT_CYR = str.maketrans("ABEKMHOPCTXaceopxy", "АВЕКМНОРСТХасеорху")


def ocr_key(value, domain):
    """A query hypothesis only; never used to overwrite source characters."""
    text = norm(value)
    if domain == "taxon":
        text = text.translate(CYR_LAT)
    else:
        def repair(m):
            token = m[0]
            cy = len(re.findall(r"[А-Яа-яЁё]", token))
            la = len(re.findall(r"[A-Za-z]", token))
            return token.translate(LAT_CYR) if cy > la > 0 else token
        text = re.sub(r"[\w-]+", repair, text)
    return key(text).replace("ё", "е")


def person_key(value):
    # Reorder explicit initials, but do not infer a full identity from a surname.
    s = norm(value)
    initials = re.findall(r"(?<!\w)([A-Za-zА-Яа-яЁё])\s*\.", s)
    rest = re.sub(r"(?<!\w)[A-Za-zА-Яа-яЁё]\s*\.", " ", s)
    return key(rest + " " + " ".join(initials))


COUNTRIES = [
    ("KG", r"Кирг(?:изская|изия|изстан|ызстан|\.)\s*(?:ССР)?|Кыргызская\s+Республика|Kyrgyzstan|Kirgizstan"),
    ("KZ", r"Казахская\s+ССР|Казах(?:стан|ская|\.)|Kazakhstan"),
    ("TJ", r"Тадж(?:икская\s+ССР|икистан|икия|\.)|Tajikistan|Tadzhikistan"),
    ("UZ", r"Узб(?:екская\s+ССР|екистан|\.)|Uzbekistan"),
    ("TM", r"Туркм(?:енская\s+ССР|енистан|ения|\.)|Turkmenistan"),
]
ABBREVIATIONS = {"г", "гг", "р", "оз", "хр", "обл", "окр", "пос", "с", "д", "м", "им", "ст", "дол", "ур", "сел", "юж", "сев", "вост", "зап", "кирг", "каз", "узб", "тадж", "туркм", "б", "мал", "в", "н", "ср", "гор", "рн", "у"}
GEO_PREFIX = r"(?:оз(?:еро|ера|ёра|\.)|р\.|река|реки|хр\.|хребет|хребта|горы|гора|гор\.|пос\.|пос[её]лок|село|сел\.|деревня|город|г\.|ур\.|урочище|дол\.|долина|долины|ущелье|ущ\.)"
PREFIX_RE = re.compile(r"(?i)(?<!\w)" + GEO_PREFIX + r"(?=\s)")
REL_RE = re.compile(r"(?i)(?<!\w)(?:близ|около|между|вблизи|вдоль|выше|ниже|у подножия|на склоне|на склонах|на берегу)(?=\s)")
HABITAT = re.compile(r"(?i)^(?:на\s+)?(?:обнажения|песчан|каменист|галеч|щебнист|глинист|серые\s+песчан|красные\s+песчан|лугов|луга|луг\b|степь|степные|сорн|солончак|среди|по\s+обочин|в\s+посев|высота|почв)")
GEO_GENERIC = set('бассейн басс бас долина дол ущелье ущ урочище уроч ур окрестности окр верховья верховье низовья район р н область обл гора горы гор хребет хр река реки озеро озера оз р село сел поселок пос деревня дер кишлак киш станция ст центр центр центральная центральный север юг запад восток северный южный западный восточный верхний нижний средний верхняя нижняя средняя г м на у в по при от до'.split())


def is_generic_place(text):
    tokens=key(text).split()
    return not tokens or all(t in GEO_GENERIC for t in tokens)


@lru_cache(maxsize=100000)
def split_locality(raw):
    raw = str(raw or "")
    if not raw.strip():
        return []
    boundaries = {0, len(raw)}
    # Punctuation boundaries retain abbreviations, decimal numbers, and initials.
    for m in re.finditer(r"[.;,\n]", raw):
        pos = m.start()
        if m[0] == ".":
            word = re.search(r"([\w-]+)$", raw[:pos])
            if word and (word[1].casefold() in ABBREVIATIONS or len(word[1]) == 1):
                continue
            if pos and pos + 1 < len(raw) and raw[pos-1].isdigit() and raw[pos+1].isdigit():
                continue
        boundaries.add(m.end())
    for _, pattern in COUNTRIES:
        for m in re.finditer(r"(?i)(?<!\w)(?:" + pattern + r")(?!\w)", raw):
            boundaries.update([m.start(), m.end()])
    for m in PREFIX_RE.finditer(raw):
        boundaries.add(m.start())
    for m in REL_RE.finditer(raw):
        boundaries.add(m.start())
    # Supports adjacent administrative names even without punctuation.
    for m in re.finditer(r"(?i)\b(?:область|район|уезд)\b|\b(?:обл\.|р-н)(?=\s)", raw):
        boundaries.add(m.end())
    points = sorted(boundaries)
    segments = []
    for start, end in zip(points, points[1:]):
        text = raw[start:end]
        lo = len(text) - len(text.lstrip(" \t\r\n,;.()"))
        hi = len(text.rstrip(" \t\r\n,;.()"))
        content = text[lo:hi]
        kind, country, name = "unresolved", None, ""
        if content:
            for code, pattern in COUNTRIES:
                if re.fullmatch(r"(?i)(?:" + pattern + r")\.?", content):
                    kind, country, name = "country_historical_or_modern", code, content
                    break
            if not name:
                suffixes = [("administrative_region", r"\s+(?:область|обл)\.?$"),
                            ("administrative_district", r"\s+(?:район|р-н|уезд)\.?$")]
                for typ, pat in suffixes:
                    if re.search(pat, content, re.I):
                        kind, name = typ, re.sub(pat, "", content, flags=re.I).strip()
                        break
            if not name:
                prefix = PREFIX_RE.match(content + " ")
                if prefix:
                    marker = prefix[0].casefold()
                    kind = ("waterbody" if marker.startswith(("оз", "р.", "рек")) else
                            "mountain" if marker.startswith(("хр", "гор")) else
                            "valley_or_landmark" if marker.startswith(("дол", "ур", "ущ")) else
                            "ambiguous_city_or_mountain" if marker == "г." else "settlement")
                    name = content[prefix.end():].strip()
            if not name and HABITAT.search(content):
                kind = "habitat_or_terrain"
            elif not name and (REL_RE.match(content) or re.search(r"(?i)\b(?:км|метров|склон|склоны|берег|край|район)\b", content)):
                kind = "relative_location"
            elif not name and re.search(r"[A-ZА-ЯЁ]", content) and 2 <= len(content) <= 85 and len(key(content).split()) <= 7:
                kind, name = "toponym_untyped", content
            if name and (len(key(name)) < 3 or re.fullmatch(r"[\d\s.]+", name) or is_generic_place(name)):
                name = ""
                kind = "geographic_descriptor_without_name"
            if name:
                # Do not use trailing habitat prose as a single 'standard' name.
                name = re.split(r"(?i)\s+(?:на\s+|по\s+|при\s+|в\s+)(?=\w)", name, maxsplit=1)[0].strip(" ,;.")
        ns = raw.find(name, start, end) if name else -1
        segments.append({"start": start, "end": end, "raw": text, "kind": kind,
                         "name": name, "name_start": ns if ns >= 0 else None,
                         "name_end": ns + len(name) if ns >= 0 else None,
                         "country_candidate": country,
                         "status": "rule_parsed_unverified" if name else "retained_unresolved"})
    assert "".join(x["raw"] for x in segments) == raw
    return segments


@lru_cache(maxsize=10000)
def parse_taxon(raw):
    text = norm(raw)
    m = re.match(r"^([A-Z][a-zA-Z-]+)\s+((?:(?:cf|aff)\.?\s+)?[a-z][a-z-]+)(.*)$", text)
    qualified = bool(re.search(r"(?i)\b(?:sp|spp|cf|aff)\b|\?", text))
    out = {"raw": raw, "name": text, "authors": "", "qualifier": qualified,
           "status": "unparsed" if text else "missing", "genus": ""}
    if m:
        genus, species, tail = m.groups()
        name = genus + " " + species
        sub = re.match(r"\s+((?:subsp|ssp|var|f)\.?\s+[a-z][a-z-]+)(.*)$", tail)
        if sub:
            name += " " + sub[1]; tail = sub[2]
        out.update(name=name, authors=tail.strip(), genus=genus,
                   status="qualified_not_species_completion" if qualified else "parsed_name_not_taxonomic_validation")
    return out


@lru_cache(maxsize=30000)
def parse_date(raw):
    s = norm(raw)
    result = {"raw": raw, "start": None, "end": None, "precision": None, "status": "missing" if not s else "unparsed"}
    if not s:
        return result
    if "(" in s or ")" in s:
        result["status"] = "ambiguous_calendar_or_annotation"; return result
    s = re.sub(r"\s*(?:г\.?|год)$", "", s, flags=re.I).strip()
    def interval(y, m=None, d=None, d2=None):
        if d is not None:
            a, b, precision = date(y,m,d), date(y,m,d2 or d), "range" if d2 is not None else "day"
        elif m is not None:
            a,b,precision = date(y,m,1),date(y,m,calendar.monthrange(y,m)[1]),"month"
        else:
            a,b,precision = date(y,1,1),date(y,12,31),"year"
        if a > b: raise ValueError("reversed date")
        result.update(start=a.isoformat(),end=b.isoformat(),precision=precision,status="parsed")
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:[T ]00:00:00)?",s):
            interval(*map(int,s[:10].split("-")))
        elif re.fullmatch(r"\d{4}",s): interval(int(s))
        elif re.fullmatch(r"\d{4}-\d{1,2}",s): interval(*map(int,s.split("-")))
        elif (m:=re.fullmatch(r"(\d{1,2})\.(\d{4})",s)): interval(int(m[2]),int(m[1]))
        elif (m:=re.fullmatch(r"(\d{1,2})\s*[-–]\s*(\d{1,2})\s*\.\s*(\d{1,2})\s*\.\s*(\d{4})",s)):
            interval(int(m[4]),int(m[3]),int(m[1]),int(m[2]))
        elif (m:=re.fullmatch(r"(\d{1,2})\s*[./]\s*(\d{1,2})\s*[./]\s*(\d{4})",s)):
            interval(int(m[3]),int(m[2]),int(m[1]))
        elif (m:=re.fullmatch(r"(\d{1,2})[.\s-]+([IVXivx]+)[.\s-]+(\d{4})",s)):
            months={x:i+1 for i,x in enumerate(['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'])}
            interval(int(m[3]),months[m[2].upper()],int(m[1]))
        elif re.fullmatch(r"[\d.\s/-]+",s): result["status"]="invalid_or_unsupported_numeric_date"
    except (ValueError,KeyError,OverflowError):
        result.update(start=None,end=None,precision=None,status="invalid_calendar_date")
    return result
