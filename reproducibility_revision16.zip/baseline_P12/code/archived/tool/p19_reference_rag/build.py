from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import time
from collections import Counter
from pathlib import Path

from . import VERSION
from .parse import key, norm, ocr_key, parse_date, parse_taxon, person_key, split_locality

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / '11_rag/p10_index_20261012_01/rag.sqlite3'
DEFAULT = ROOT / '11_rag/reference_20261020_04'


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def save(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str)+'\n', encoding='utf-8')


def read_db(path):
    db = sqlite3.connect(Path(path).resolve().as_uri()+'?mode=ro', uri=True)
    db.row_factory = sqlite3.Row
    return db


SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE record(record_id TEXT PRIMARY KEY, specimen_key TEXT NOT NULL, sheet TEXT NOT NULL,
 source_row INTEGER NOT NULL, content_group TEXT NOT NULL, fields_json TEXT NOT NULL,
 date_start TEXT,date_end TEXT,date_precision TEXT,date_status TEXT NOT NULL);
CREATE INDEX record_specimen ON record(specimen_key);
CREATE INDEX record_group ON record(content_group);
CREATE INDEX record_date ON record(date_start,date_end);
CREATE TABLE term(term_id TEXT PRIMARY KEY,domain TEXT NOT NULL,display TEXT NOT NULL,
 search_key TEXT NOT NULL,ocr_key TEXT NOT NULL,semantic_type TEXT NOT NULL,
 status TEXT NOT NULL,record_count INTEGER NOT NULL DEFAULT 0,UNIQUE(domain,search_key,semantic_type));
CREATE INDEX term_key ON term(domain,search_key);
CREATE INDEX term_ocr ON term(domain,ocr_key);
CREATE TABLE mention(mention_id INTEGER PRIMARY KEY,term_id TEXT NOT NULL REFERENCES term,
 record_id TEXT NOT NULL REFERENCES record,raw TEXT NOT NULL,start INTEGER,end INTEGER);
CREATE INDEX mention_term ON mention(term_id,record_id);
CREATE INDEX mention_record ON mention(record_id,term_id);
CREATE TABLE segment(record_id TEXT NOT NULL REFERENCES record,sequence INTEGER NOT NULL,
 start INTEGER NOT NULL,end INTEGER NOT NULL,raw TEXT NOT NULL,kind TEXT NOT NULL,
 name TEXT NOT NULL,country_candidate TEXT,status TEXT NOT NULL,PRIMARY KEY(record_id,sequence));
CREATE TABLE authority_link(term_id TEXT NOT NULL REFERENCES term,entity_id TEXT NOT NULL,
 matched_name TEXT NOT NULL,canonical_name TEXT NOT NULL,name_kind TEXT NOT NULL,
 evidence_id TEXT NOT NULL,link_status TEXT NOT NULL,PRIMARY KEY(term_id,entity_id,evidence_id));
CREATE INDEX authority_term ON authority_link(term_id);
CREATE VIRTUAL TABLE term_fts USING fts5(search_key,ocr_key,content='term',content_rowid='rowid',tokenize='trigram');
'''


def protected_paths():
    paths = [ROOT/'resource/中亚ok.xlsx', BASE,
             ROOT/'11_rag/p10_catalogue_20261012_01/catalogue.jsonl',
             ROOT/'11_rag/new_flora_20261016_01/flora.sqlite3']
    for p in [ROOT/'tool/p10_rag', ROOT/'tool/p18_llm_rag']:
        paths += list(p.glob('*.py'))
    experiment = ROOT/'17_validation/independent_20261018_01/experiments/G_llm_rag_review_20261019_01'
    paths += [p for p in experiment.glob('*.json')]
    paths += list((experiment/'results').glob('*.json'))
    paths += list((experiment/'visual_baseline_01/results').glob('*.json'))
    return sorted(set(p for p in paths if p.is_file()))


def build(output=DEFAULT):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    protected = {p.relative_to(ROOT).as_posix(): digest(p) for p in protected_paths()}
    save(output/'protected_inputs_before.json', protected)
    base = read_db(BASE)
    db = sqlite3.connect(output/'reference.sqlite3')
    db.executescript(SCHEMA)
    db.execute('PRAGMA cache_size=-150000')
    seen, stats = {}, Counter()

    def term(domain, text, kind, record, a=None, b=None):
        raw_text=str(text)
        text = norm(text)
        sk = person_key(text) if domain == 'collector' else key(text)
        if len(sk) < 3:
            return
        token = (domain, sk, kind)
        tid = seen.get(token)
        if tid is None:
            tid = 'ref:'+hashlib.sha256(json.dumps(token,ensure_ascii=False).encode()).hexdigest()[:24]
            seen[token] = tid
            db.execute('INSERT INTO term VALUES(?,?,?,?,?,?,?,0)',
                (tid,domain,text,sk,ocr_key(sk,domain),kind,'observed_catalogue_form_not_verified_identity'))
        db.execute('INSERT INTO mention(term_id,record_id,raw,start,end) VALUES(?,?,?,?,?)',
                   (tid,record,raw_text,a,b))

    for i, row in enumerate(base.execute('SELECT * FROM specimen_record ORDER BY sheet,source_row'),1):
        fields = json.loads(row['fields_json'])
        main = row['sheet']=='主表'
        date_info = parse_date(str(fields.get('date') or '')) if main else parse_date('')
        db.execute('INSERT INTO record VALUES(?,?,?,?,?,?,?,?,?,?)',
            (row['entity_id'],row['specimen_key'],row['sheet'],row['source_row'],row['content_group'],
             row['fields_json'],date_info['start'],date_info['end'],date_info['precision'],date_info['status']))
        taxon = parse_taxon(str(fields.get('taxon') or ''))
        if taxon['raw']:
            term('taxon',taxon['raw'],'qualified_name' if taxon['qualifier'] else 'scientific_name',row['entity_id'])
        if main:
            stats['date_'+date_info['status']]+=1
            raw = str(fields.get('place') or '')
            for seq, seg in enumerate(split_locality(raw)):
                db.execute('INSERT INTO segment VALUES(?,?,?,?,?,?,?,?,?)',
                    (row['entity_id'],seq,seg['start'],seg['end'],seg['raw'],seg['kind'],seg['name'],
                     seg['country_candidate'],seg['status']))
                stats['segment_'+seg['kind']]+=1
                if seg['name']:
                    term('place',seg['name'],seg['kind'],row['entity_id'],seg['name_start'],seg['name_end'])
            if fields.get('collector'):
                term('collector',str(fields['collector']),'collector_name_form',row['entity_id'])
        if i % 20000 == 0:
            print(json.dumps({'stage':'parse','records':i,'terms':len(seen)}),flush=True)
    db.commit()
    db.execute('UPDATE term SET record_count=(SELECT count(DISTINCT record_id) FROM mention m WHERE m.term_id=term.term_id)')
    db.execute("INSERT INTO term_fts(term_fts) VALUES('rebuild')")
    db.commit()
    # External name linkage is a name correspondence, never proof of place/person identity.
    cache={}
    for i,t in enumerate(db.execute('SELECT * FROM term').fetchall(),1):
        tid,domain,text,sk,_,kind,_,_=t
        domain_base = 'person' if domain=='collector' else domain
        keys = [key(text)]
        if domain=='taxon':
            tx=parse_taxon(text)
            keys = [key(tx['genus'])] if tx['qualifier'] and tx['genus'] else [key(text),key(tx['name'])]
        for candidate_key in dict.fromkeys(keys):
            ck=(domain_base,candidate_key)
            if ck not in cache:
                cache[ck]=base.execute('''SELECT n.entity_id,n.raw_name,e.canonical_name,n.name_kind,n.evidence_id
                    FROM name_variant n JOIN entity e USING(entity_id)
                    WHERE n.domain=? AND n.lexical_key=? AND n.subject_specimen IS NULL
                    ORDER BY n.priority,n.name_id LIMIT 12''', ck).fetchall()
            matches=cache[ck]
            for m in matches:
                db.execute('INSERT OR IGNORE INTO authority_link VALUES(?,?,?,?,?,?,?)',
                    (tid,*tuple(m),'name_correspondence_only_identity_unverified' if domain!='taxon' else 'external_taxonomic_name_candidate'))
            if matches: break
        if i%25000==0:
            print(json.dumps({'stage':'external_name_links','terms':i}),flush=True)
    counts={name:db.execute('SELECT count(*) FROM '+name).fetchone()[0]
            for name in ['record','term','mention','segment','authority_link']}
    summary = {'version':VERSION,'purpose':'OCR calibration reference names, not specimen identification',
        'base_db':str(BASE),'source_workbook_sha256':protected['resource/中亚ok.xlsx'],
        'counts':counts,'by_domain':dict(db.execute('SELECT domain,count(*) FROM term GROUP BY domain')),
        'linked_terms':dict(db.execute('SELECT t.domain,count(DISTINCT t.term_id) FROM term t JOIN authority_link a USING(term_id) GROUP BY t.domain')),
        'parsing_counts':dict(stats),'protected_final_rows_excluded':49,
        'limitations':['Rule parsing and name links are not independently reviewed botanical/geographical truth.',
                      'Historical and modern names remain distinct; no coordinates are assigned to specimens.',
                      'Date intervals retain precision; collector identity is unresolved.',
                      'No LLM calls, no images, no training or final-test inference.']}
    db.execute('INSERT INTO metadata VALUES(?,?)',('manifest',json.dumps(summary,ensure_ascii=False)))
    db.commit()
    summary['integrity_check']=db.execute('PRAGMA integrity_check').fetchone()[0]
    summary['foreign_key_errors']=db.execute('PRAGMA foreign_key_check').fetchall()
    db.close();base.close()
    summary['seconds']=round(time.perf_counter()-start,3)
    summary['database_sha256']=digest(output/'reference.sqlite3')
    save(output/'build_manifest.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,default=DEFAULT)
    build(p.parse_args().output)
