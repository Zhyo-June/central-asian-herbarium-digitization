"""Fixed source-derived OCR stress cases plus six existing human-reviewed cases.

These are vocabulary retrieval checks, NOT independent botanical/OCR accuracy.
The baseline is allowed the same source catalogue where observed forms are tested.
"""
from __future__ import annotations
import argparse
import html
import json
import random
import re
import statistics
from collections import Counter
from pathlib import Path

from .build import ROOT,BASE,DEFAULT,read_db,save,digest
from .parse import key,person_key
from .retrieve import ReferenceRetriever
from p10_rag.retrieve import Retriever

OUT=ROOT/'outputs/rag_reference_20261020_01'


def noise(text):
    letters=[i for i,c in enumerate(text) if c.isalpha() and i>1 and i<len(text)-2]
    if not letters:return text+'x'
    i=letters[len(letters)//2]
    return text[:i]+text[i+1:]


def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    path=OUT/'benchmark_queries.jsonl'
    if path.exists():raise FileExistsError(path)
    rng=random.Random(20261020);db=read_db(BASE);queries=[];missing=[]
    def add(**q):
        q['query_id']=f"Q{len(queries)+1:04d}";queries.append(q)
    tax=[dict(r) for r in db.execute("SELECT e.entity_id,e.canonical_name FROM entity e JOIN taxon t USING(entity_id) WHERE t.status='Accepted' AND length(e.canonical_name) BETWEEN 10 AND 40 ORDER BY e.entity_id")]
    for r in rng.sample(tax,12):
        name=r['canonical_name']
        mixed=name.translate(str.maketrans({'a':'а','o':'о','c':'с'}))
        for tag,text in [('clean',name),('deletion',noise(name)),('mixed_script',mixed)]:
            add(group='external_taxon_'+tag,field='taxon',text=text,expected_ids=[r['entity_id']],external_only=True)
    places=[dict(r) for r in db.execute("SELECT e.entity_id,e.canonical_name FROM entity e WHERE domain='place' AND entity_id LIKE 'geonames:%' AND length(canonical_name) BETWEEN 6 AND 32 ORDER BY entity_id")]
    for r in rng.sample(places,12):
        for tag,text in [('clean',r['canonical_name']),('deletion',noise(r['canonical_name']))]:
            add(group='external_place_'+tag,field='place',text=text,expected_ids=[r['entity_id']],external_only=True)
    fragments=['Ер-ойлан-дуз','Арчасай','Бадхыз','Каржантау','Памиро-Алай','Каратау','Ташкент',
               'Самарканд','Зарафшан','Ферганская','Караванский','Джалалабадская','Алайская','Чаткальский',
               'Кызыл-кумов','Чу-Илийские']
    for fragment in fragments:
        row=db.execute("SELECT * FROM specimen_record WHERE sheet='主表' AND json_extract(fields_json,'$.place') LIKE ? ORDER BY source_row LIMIT 1",('%'+fragment+'%',)).fetchone()
        if not row:missing.append(fragment);continue
        f=json.loads(row['fields_json'])
        for tag,text in [('fragment',fragment),('deletion',noise(fragment)),('wrapped','Место сбора: '+fragment)]:
            add(group='catalogue_place_'+tag,field='place',text=text,expected_names=[fragment],
                source_row=row['source_row'],source_specimen=row['specimen_key'],external_only=False)
        add(group='joint_context_leave_one_group_out',field='place',text=noise(fragment),expected_names=[fragment],
            context={'taxon':f.get('taxon'),'collector':f.get('collector'),'date':str(f.get('date') or '')},
            exclude_specimen_id=row['specimen_key'],source_row=row['source_row'],external_only=False)
    collectors=db.execute("SELECT raw_name,count(*) n FROM name_variant WHERE name_kind='catalogue_collector' AND raw_name LIKE '%.%' GROUP BY raw_name HAVING count(*)>50 ORDER BY n DESC,raw_name LIMIT 80").fetchall()
    for r in rng.sample(collectors,min(10,len(collectors))):
        text=r['raw_name'];initials=re.findall(r'(?<!\w)([A-Za-zА-Яа-яЁё])\s*\.',text)
        surname=re.sub(r'(?<!\w)[A-Za-zА-Яа-яЁё]\s*\.',' ',text).strip()
        reversed_name=''.join(x+'.' for x in initials)+' '+surname
        for tag,q in [('clean',text),('initial_order',reversed_name),('deletion',noise(text))]:
            add(group='collector_'+tag,field='collector',text=q,expected_names=[text],external_only=False)
    human=json.loads((ROOT/'11_rag/p10_human_acceptance_20261015_01/human_acceptance.json').read_text(encoding='utf-8'))
    original={q['query_id']:q for q in map(json.loads,(ROOT/'11_rag/p10_ai_acceptance_review_20261015_01/originals/queries.jsonl').read_text(encoding='utf-8').splitlines())}
    for q in human['records']:
        if q['disposition']=='label_name_link' and q['answerability']=='answerable' and q['routing_status']=='confirmed':
            o=original[q['query_id']]
            add(group='human_reviewed_development_OCR',field=o['field'],text=o['text'],expected_ids=q['expected_entity_ids'],
                external_only=True,exclude_specimen_id=q['specimen_id'],original_query_id=q['query_id'])
    for i in range(18):
        add(group='synthetic_no_answer',field=['taxon','place','collector'][i%3],text=f'Qzxv{731+i} Wqzj{912+i}',
            expected_names=[],expected_ids=[],negative=True,external_only=False)
    with path.open('x',encoding='utf-8') as f:
        for q in queries:f.write(json.dumps(q,ensure_ascii=False)+'\n')
    save(OUT/'benchmark_protocol.json',{'seed':20261020,'queries':len(queries),'sha256':digest(path),
        'groups':dict(Counter(q['group'] for q in queries)),'missing_literal_source_fragments':missing,
        'endpoint':'expected reference name or authority entity in top-k; not specimen barcode',
        'baseline_source_policy':'catalogue_assisted for observed forms; external_only for external/human cases; leave-one-group-out when requested',
        'scope':'Source-derived engineering stress cases and exposed human-reviewed development cases. No independent gold or OCR correction accuracy.',
        'latency_note':'Sequential local execution with caches; latency is diagnostic, not a controlled speed benchmark.'})
    db.close();print(f'Frozen {len(queries)} queries: {path}')


def matches(q,c,new):
    ids={c.get('candidate_id') if new else c.get('entity_id')}
    if new:ids.update(x['entity_id'] for x in c.get('authority_links',[]))
    if ids & set(q.get('expected_ids',[])):return True
    strings=[c.get('name',''),c.get('matched_name','')] if new else [c.get('canonical_name',''),c.get('matched_span','')]
    normalize=person_key if q['field']=='collector' else key
    for expected in q.get('expected_names',[]):
        a=normalize(expected)
        for s in strings:
            b=normalize(s)
            if q['field']=='place':
                if (' '+a+' ') in (' '+b+' '):return True
            elif a==b:return True
    return False


def run(output):
    output=Path(output);output.mkdir(parents=True,exist_ok=False)
    save(output/'code_hashes.json',{p.name:digest(p) for p in Path(__file__).parent.glob('*.py')})
    path=OUT/'benchmark_queries.jsonl'
    protocol=json.loads((OUT/'benchmark_protocol.json').read_text(encoding='utf-8'))
    assert digest(path)==protocol['sha256']
    queries=list(map(json.loads,path.read_text(encoding='utf-8').splitlines()))
    before=Retriever(BASE);after=ReferenceRetriever();results=[]
    try:
        with (output/'results.jsonl').open('x',encoding='utf-8') as f:
            for i,q in enumerate(queries,1):
                catalogue=not q.get('external_only',False);excluded=q.get('exclude_specimen_id')
                b=before.query(q['field'],q['text'],top_k=10,include_catalogue=catalogue,
                    mode='generalization' if excluded or not catalogue else 'catalogue_assisted',query_specimen_id=excluded)
                a=after.query(q['field'],q['text'],top_k=10,context=q.get('context'),
                    exclude_specimen_id=excluded,external_only=q.get('external_only',False))
                plain=after.query(q['field'],q['text'],top_k=10,exclude_specimen_id=excluded,
                    external_only=q.get('external_only',False)) if q.get('context') else None
                item={'query':q,'before':b,'after':a,'after_without_context':plain}
                item['ranks']={}
                for label,result,new in [('before',b,False),('after',a,True),('after_without_context',plain,True)]:
                    if result is not None:
                        hits=[j for j,c in enumerate(result['candidates'],1) if matches(q,c,new)]
                        item['ranks'][label]=min(hits) if hits else None
                f.write(json.dumps(item,ensure_ascii=False)+'\n');f.flush();results.append(item)
                if i%20==0:print(json.dumps({'evaluated':i,'total':len(queries)}),flush=True)
    finally:before.close();after.close()
    metrics={}
    for group in sorted({q['group'] for q in queries}):
        rows=[r for r in results if r['query']['group']==group]
        metric={'n':len(rows)}
        for label in ['before','after']:
            if rows[0]['query'].get('negative'):
                metric[label]={'correct_abstentions':sum(not r[label]['candidates'] for r in rows)}
            else:
                ranks=[r['ranks'][label] for r in rows]
                metric[label]={'hits_at_1':sum(x is not None and x<=1 for x in ranks),
                    'hits_at_5':sum(x is not None and x<=5 for x in ranks),'hits_at_10':sum(x is not None and x<=10 for x in ranks),
                    'mrr_at_10':sum(1/x if x else 0 for x in ranks)/len(rows)}
        metrics[group]=metric
    positive=[r for r in results if not r['query'].get('negative')]
    total={label:{'n':len(positive),'hits_at_1':sum(r['ranks'][label]==1 for r in positive),
           'hits_at_5':sum(r['ranks'][label] is not None and r['ranks'][label]<=5 for r in positive),
           'hits_at_10':sum(r['ranks'][label] is not None for r in positive)} for label in ['before','after']}
    joint=[r for r in results if r['after_without_context'] is not None]
    joint_report={'n':len(joint),'with_context_hits_at_5':sum(r['ranks']['after'] is not None and r['ranks']['after']<=5 for r in joint),
        'without_context_hits_at_5':sum(r['ranks']['after_without_context'] is not None and r['ranks']['after_without_context']<=5 for r in joint),
        'queries_with_joint_support':sum(any(c.get('joint_support_records',0)>0 for c in r['after']['candidates']) for r in joint)}
    regressions=[r['query']['query_id'] for r in positive if r['ranks']['before'] is not None and
                 (r['ranks']['after'] is None or r['ranks']['after']>r['ranks']['before'])]
    report={'protocol':protocol,'groups':metrics,'pooled_engineering_only':total,'context_ablation':joint_report,
            'rank_regressions_retained':regressions,'independent_accuracy':None,'LLM_correction_accuracy':None}
    save(output/'metrics.json',report)
    body=''.join(f'<tr><td>{html.escape(g)}</td><td>{v["n"]}</td><td>{v["before"].get("hits_at_5",v["before"].get("correct_abstentions"))}</td><td>{v["after"].get("hits_at_5",v["after"].get("correct_abstentions"))}</td></tr>' for g,v in metrics.items())
    examples=''.join('<tr><td>'+html.escape(r['query']['text'])+'</td><td>'+str(r['ranks'].get('before'))+'</td><td>'+str(r['ranks'].get('after'))+'</td></tr>' for r in results)
    (output/'comparison.html').write_text('<!doctype html><html lang="zh"><meta charset="utf-8"><title>OCR参考库检索对比</title><style>body{font:16px Arial;max-width:1100px;margin:40px auto;line-height:1.6;color:#172b3a}table{border-collapse:collapse;width:100%;margin:24px 0}th,td{text-align:left;padding:9px;border-bottom:1px solid #d8e0e6}th{background:#edf3f7}</style><h1>OCR参考库检索对比</h1><p>终点是参考名称候选命中，不是标本条码识别。工程查询来自来源库，人工复核项属于已暴露开发材料；本报告不代表独立准确率，也未运行LLM纠错。</p><table><tr><th>组别</th><th>查询数</th><th>优化前@5</th><th>优化后@5</th></tr>'+body+'</table><p>synthetic_no_answer 一行统计正确无候选数。失败及排名下降全部保留。联合上下文消融：'+html.escape(json.dumps(joint_report,ensure_ascii=False))+'</p><h2>逐条排名</h2><table><tr><th>查询</th><th>优化前</th><th>优化后</th></tr>'+examples+'</table></html>',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--output',type=Path,default=DEFAULT/'evaluation_01')
    a=p.parse_args();prepare() if a.prepare else run(a.output)
