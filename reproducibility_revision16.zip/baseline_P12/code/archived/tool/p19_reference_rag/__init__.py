"""Versioned OCR reference vocabulary. Historical experiment modules are untouched."""
VERSION = "ocr_reference_v1"
