from pathlib import Path
import json,csv,collections
R=Path(__file__).resolve().parents[1];O=R/'generated';O.mkdir(exist_ok=True)
rows=[json.loads(l) for l in (R/'geography/spatial_records_paired.jsonl').read_text('utf-8').splitlines()]
out=[]
for v in ['original','human_corrected']:
 rr=[r for r in rows if r['input_version']==v];c=collections.Counter(r['category'] for r in rr)
 for k,n in c.items():out.append({'version':v,'category':k,'n':n,'denominator':len(rr),'percent':round(100*n/len(rr),2)})
with (O/'revision12_spatial_categories.csv').open('w',encoding='utf-8',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
print(O/'revision12_spatial_categories.csv')
