from pathlib import Path
import sys,csv,json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.font_manager import FontProperties

ROOT=Path(__file__).resolve().parents[1]; PROJECT=ROOT.parents[1]
OUT=ROOT/'figures'; QA=ROOT/'qa'; OUT.mkdir(exist_ok=True); MM=1/25.4
BLUE='#2F6B89'; TEAL='#267D74'; GOLD='#D5A44C'; GREY='#B9C1C7'; INK='#1F2933'
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Microsoft YaHei','DejaVu Sans'],
 'font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':8,
 'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'savefig.dpi':400,
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.6,'text.color':INK,
 'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK})
metric=list(csv.DictReader((ROOT/'tables/metrics_side_by_side.csv').open(encoding='utf-8-sig')))
local=[r for r in metric if r['field']=='locality']
methods=[r['method'] for r in local]
contracts={
 'figure1':{'claim':'Complementary text and image reading routes share a label front end and retain source-linked outputs.','archetype':'workflow','evidence':['saved six-route configuration'],'statistics':'not applicable'},
 'figure2':{'claim':'Evaluated labels vary in writing, layout, obstruction and identification history.','archetype':'source image plate','sampling':'Six illustrative cases, not a frequency estimate.','image_changes':'Proportional resize only; no retouching or contrast adjustment; independent display scales.'},
 'figure3':{'claim':'Domain adaptation improves line recognition and visual reading recovers more locality information on the evaluated material.','archetype':'three complementary quantitative panels','n':['256 lines / 49 specimens','319 specimens','24 readable locality cases / 50 audited specimens'],'spread':'All bars show descriptive point estimates. Available specimen-bootstrap and Wilson intervals are reported in text and supplement, not assigned to unsupported bars.','test':'No new inferential tests.','source_data':['metrics_side_by_side.csv','manual_line_figure_values.csv']},
 'figure4':{'claim':'The structured regional resource connects original records to searchable names and improves source-derived retrieval.','archetype':'resource diagram plus descriptive composition and retrieval','n':['86,705 catalogue rows','160 source-derived answerable queries'],'spread':'Descriptive finite-set counts; no sampling interval.','source_data':['catalogue_family_counts.csv','retrieval_figure_values.csv']}}
(OUT/'figure_contracts.json').write_text(json.dumps(contracts,ensure_ascii=False,indent=2),encoding='utf-8')
with (ROOT/'tables/manual_line_figure_values.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['model','edits','reference_characters','cer_percent']);w.writerows([['Pretrained Paddle',2041,5874,2041/5874*100],['Adapted Paddle',685,5874,685/5874*100],['TrOCR',866,5874,866/5874*100]])
(ROOT/'tables/retrieval_figure_values.csv').write_text('version,top5_hits,answerable_queries\nBefore,110,160\nRestructured,155,160\n',encoding='utf-8')

def label(ax,letter,title):
    ax.annotate(letter,(0,1.10),xycoords='axes fraction',xytext=(-8,0),textcoords='offset points',fontweight='bold',fontsize=10,ha='right',va='baseline')
    ax.set_title(title,loc='left',pad=15,fontweight='normal')

def box(ax,x,y,w,h,txt,color=BLUE,fs=8):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.015',linewidth=.8,edgecolor=color,facecolor='white')
    ax.add_patch(p);ax.text(x+w/2,y+h/2,txt,ha='center',va='center',fontsize=fs,linespacing=1.4)

def arrow(ax,start,end,color=INK):
    ax.annotate('',xy=end,xytext=start,arrowprops={'arrowstyle':'-|>','lw':.8,'color':color,'shrinkA':2,'shrinkB':2})

def save(fig,name,lang,ids=None):
    fig.canvas.draw()
    fig.savefig(OUT/f'{name}_{lang}.pdf',facecolor='white')
    fig.savefig(OUT/f'{name}_{lang}.svg',facecolor='white')
    fig.savefig(OUT/f'{name}_{lang}.png',facecolor='white',dpi=400)
    if name=='figure2':
        fig.savefig(OUT/f'{name}_{lang}.tiff',facecolor='white',dpi=400,pil_kwargs={'compression':'tiff_lzw'})
    plt.close(fig)

for lang in ['en']:
    zh=lang=='zh'
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','Arial','DejaVu Sans'] if zh else ['Arial','Microsoft YaHei','DejaVu Sans']
    fig,ax=plt.subplots(figsize=(170*MM,132*MM));fig.subplots_adjust(left=.025,right=.975,bottom=.035,top=.97)
    ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    box(ax,.26,.855,.48,.115,'标本图像 → 定向检测 → 标签校正' if zh else 'Specimen image → oriented detection\n→ rectified primary label')
    box(ax,.04,.58,.38,.16,'本地OCR\n领域适配Paddle · TrOCR候选' if zh else 'Local OCR\nAdapted Paddle · TrOCR alternatives')
    box(ax,.58,.58,.38,.16,'直接视觉读取\n相同主要标签图像' if zh else 'Direct visual reading\nSame primary-label image',TEAL)
    arrow(ax,(.37,.855),(.23,.75));arrow(ax,(.63,.855),(.77,.75))
    box(ax,.04,.32,.38,.15,'OCR-Rule  ·  LLM-Assemble\nLLM-Correct  ·  LLM-RAG')
    box(ax,.58,.32,.38,.15,'VLM-Direct\nVLM-RAG',TEAL)
    arrow(ax,(.23,.58),(.23,.48));arrow(ax,(.77,.58),(.77,.48))
    box(ax,.30,.075,.40,.135,'保留原文及来源\n关联规范化解释与人工核验' if zh else 'Verbatim text + source links\nNormalized interpretation + review',INK)
    arrow(ax,(.23,.32),(.40,.22));arrow(ax,(.77,.32),(.60,.22))
    ax.text(.50,.536,'外部参考\n可选证据' if zh else 'External references\nD and F only',ha='center',va='center',fontsize=7,color=TEAL)
    arrow(ax,(.47,.51),(.40,.48),TEAL);arrow(ax,(.53,.51),(.60,.48),TEAL)
    save(fig,'figure1',lang)

    fig,axes=plt.subplots(3,1,figsize=(170*MM,194*MM));fig.subplots_adjust(left=.23,right=.96,bottom=.13,top=.94,hspace=.66)
    vals=[2041/5874*100,685/5874*100,866/5874*100]
    names=['Pretrained Paddle','Adapted Paddle','TrOCR'] if not zh else ['预训练Paddle','适配Paddle','TrOCR']
    ax=axes[0];ax.barh(names,vals,color=[GREY,BLUE,GOLD],height=.55);ax.invert_yaxis();ax.set_xlim(0,40)
    ax.set_xlabel('字符错误率（%）' if zh else 'Character error rate (%)')
    for y,v in enumerate(vals):ax.text(v+.6,y,f'{v:.2f}',va='center',fontsize=8)
    label(ax,'a','人工行裁剪识别' if zh else 'Recognition on manual line crops')
    ax=axes[1];v=[float(r['coverage_percent']) for r in local]
    colors=[GREY]*4+[BLUE,TEAL];ax.barh(methods,v,color=colors,height=.68);ax.invert_yaxis();ax.set_xlim(0,105)
    ax.set_xlabel('产地参考字符覆盖率（%）' if zh else 'Locality reference characters recovered (%)')
    for y,value in enumerate(v):ax.text(value+1,y,f'{value:.2f}',va='center',fontsize=7.5)
    label(ax,'b','全部319份标本的产地恢复' if zh else 'Reference-assisted coverage on 319 specimens')
    ax=axes[2];complete=np.array([int(r['human_correct']) for r in local]);partial=np.array([int(r['human_partial']) for r in local]);other=24-complete-partial
    ax.barh(methods,complete,color=BLUE,height=.68,label='完整' if zh else 'Complete')
    ax.barh(methods,partial,left=complete,color=GOLD,height=.68,label='部分' if zh else 'Partial')
    ax.barh(methods,other,left=complete+partial,color=GREY,height=.68,label='其余' if zh else 'Other')
    ax.invert_yaxis();ax.set_xlim(0,24);ax.set_xticks([0,6,12,18,24]);ax.set_xlabel('清晰可读产地数量（n = 24）' if zh else 'Clearly readable localities (n = 24)')
    for y,(a,b,c) in enumerate(zip(complete,partial,other)):
        for left,num,color in [(0,a,'white'),(a,b,INK),(a+b,c,INK)]:
            if num:ax.text(left+num/2,y,str(num),va='center',ha='center',fontsize=7.5,color=color)
    ax.legend(loc='upper left',bbox_to_anchor=(0,-.28),ncol=3,frameon=False,fontsize=8,handlelength=1.2)
    label(ax,'c','人工评阅中的完整与部分恢复' if zh else 'Complete and partial recovery in image review')
    save(fig,'figure3',lang,list('abc'))

    fig=plt.figure(figsize=(170*MM,158*MM));gs=fig.add_gridspec(2,2,left=.17,right=.96,bottom=.12,top=.94,wspace=.65,hspace=.75,height_ratios=[1,1])
    a=fig.add_subplot(gs[0,:]);b=fig.add_subplot(gs[1,0]);c=fig.add_subplot(gs[1,1]);a.set(xlim=(0,1),ylim=(0,1));a.axis('off')
    box(a,.025,.58,.265,.25,'编目 86,705\n鉴定历史 8,032' if zh else 'Catalogue 86,705\nDeterminations 8,032',fs=8)
    box(a,.37,.58,.26,.25,'449,758片段\n74,991词条' if zh else '449,758 segments\n74,991 terms',fs=8)
    box(a,.725,.58,.255,.25,'10,812权威链接' if zh else '10,812 authority\ncandidate links',TEAL,fs=8)
    arrow(a,(.30,.70),(.36,.70));arrow(a,(.64,.70),(.71,.70))
    box(a,.20,.05,.63,.25,'原始单元格与字符区间 · 名称变体 · 来源页面' if zh else 'Original cells + offsets · name variants · source pages',INK,fs=8)
    arrow(a,(.50,.57),(.50,.32));label(a,'a','从记录到可溯源检索' if zh else 'From records to traceable retrieval')
    fam=['Poaceae','Lamiaceae','Caryophyllaceae','Polygonaceae','其他 / 缺失' if zh else 'Other / missing'];nums=[38390,24441,13755,9936,183]
    b.barh(fam,np.array(nums)/1000,color=[BLUE,TEAL,GOLD,GREY,'#E4E7EA'],height=.6);b.invert_yaxis();b.set_xlim(0,48)
    for y,n in enumerate(nums):b.text(n/1000+1.3,y,f'{n:,}',fontsize=7,va='center')
    b.set_xlabel('编目记录（千条）' if zh else 'Catalogue records (thousands)');b.tick_params(axis='y',labelsize=7)
    label(b,'b','馆藏科级构成' if zh else 'Catalogue composition')
    cats=['重组前','重组后'] if zh else ['Before','Restructured'];hits=np.array([110,155]);miss=160-hits
    c.barh(cats,hits,color=[GREY,TEAL],height=.40);c.barh(cats,miss,left=hits,color='#EEF0F2',height=.40);c.invert_yaxis();c.set_xlim(0,160);c.set_xticks([0,80,160])
    for y,h in enumerate(hits):c.text(8,y,f'{h}/160',va='center',ha='left',color=INK if y==0 else 'white',fontsize=9)
    c.set_xlabel('前五位检索命中数' if zh else 'Queries retrieved in top five')
    label(c,'c','来源派生查询' if zh else 'Source-derived queries')
    save(fig,'figure4',lang,list('abc'))
print('Figures 1, 3 and 4 labels updated; figure 2 retained.')
