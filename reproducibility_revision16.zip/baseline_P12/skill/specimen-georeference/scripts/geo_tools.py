"""Read local specimen evidence, retrieve typed place candidates, and project geometry."""
import argparse, collections, hashlib, json, re, sqlite3, sys, unicodedata
from pathlib import Path
sys.dont_write_bytecode=True
PROFILE=Path(__file__).resolve().parents[1]/'references/project.json'

def load_environment(profile):
    cfg=json.loads(Path(profile).read_text(encoding='utf-8'))
    root=Path(cfg['root']);run=root/cfg['reference_run']
    sys.path.insert(0,str(root/cfg['python_packages']))
    return cfg,root,run

def read_db(path):
    db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row;return db

def norm(value):
    from unidecode import unidecode
    value=unicodedata.normalize('NFKC',value).casefold().translate(str.maketrans({'ѣ':'е','і':'и','ѳ':'ф','ё':'е','ъ':'','қ':'к','ғ':'г','ҳ':'х','ў':'у','ӯ':'у','ӣ':'и','ң':'н','ө':'о','ү':'у'}))
    value=re.sub(r"[’ʻʼ`']",'',value)
    return ' '.join(re.sub('[^a-z0-9]+',' ',unidecode(value)).split())

def stem(value):
    value=norm(value)
    value=re.sub(r'\b(?:lake|ozero|ozera|ozere|ozeru|river|reka|reki|rekoi|mountain|mountains|khrebet|khrebta|gora|gory|valley|dolina|doliny|oblast|oblasti|region|district|raion|rayon|province|viloyati|tumani)\b',' ',value)
    value=' '.join(value.split())
    return re.sub(r'(?:skogo|skomu|skaia|skaya|skii|skiy|skoi|skoe|sk)$','',value)

KINDS={
 'lake':('LK','LKS','LKN','LKNI','LKSI','LKI','RSV','RSVI'),
 'river':('STM','STMS','STMI','STMM','STMX','SBED','CNFL','CNL','WTRC'),
 'mountain':('MTS','MT','PK','PKS','MTD','HLL','HLLS','RDGE','PASS','RK','MESA'),
 'valley':('VAL','VALS','BASN','GATE','GULCH'),
 'admin1':('ADM1',),'admin2':('ADM2','ADM3'),
 'glacier':('GLCR',),'pass':('PASS',),'desert':('DSRT','SAND'),'protected_area':('RESN','PRK','RESF','RESW'),'country':('PCLI','PCL','PCLD'),
}

def context(args,root,run,cfg):
    context_run=root/cfg.get('context_run',cfg['reference_run'])
    with (context_run/'results/localization_all_methods.jsonl').open(encoding='utf-8') as f:
        rows=(json.loads(line) for line in f)
        row=next(r for r in rows if (r['sample_id'],r['arm'])==(args.sample_id,args.arm))
    text=row['locality_text'];review=root/cfg['paper_revision']/'manual_review'
    tasks=json.loads((review/'review_dataset.json').read_text(encoding='utf-8'))['tasks']
    entries=json.loads((review/'第11版核查进度_20261022151939.json').read_text(encoding='utf-8'))['entries']
    corrections=[]
    for t in tasks:
        e=t.get('evidence',{})
        if t['module']!='geography' or t['sample_id']!=args.sample_id or args.arm not in e.get('arms',e.get('arm','')).split('|') or e.get('text')!=text:continue
        v=entries.get(t['id'],{});corrections.append({'task_id':t['id'],'source_file':str(review/'第11版核查进度_20261022151939.json'),
          'corrected_locality':v.get('corrected_locality',{}).get('value'),
          'retained_spatial_evidence':v.get('retained_spatial_evidence',{}).get('value'),
          'confirmation_basis':'user_confirmed_all_325_prior_review_items; geography_assignment_is_separate'})
    prior_geographic=[]
    db=read_db(run/'derived/gazetteer.sqlite3')
    for case_id,source_hash,payload in db.execute('SELECT case_id,source_sha256,payload_json FROM specimen_review WHERE case_id LIKE ?',(args.sample_id+'__%',)):
        prior_geographic.append({'case_id':case_id,'source_sha256':source_hash,'matches_requested_original_text':source_hash==hashlib.sha256(text.encode('utf-8')).hexdigest(),**json.loads(payload)})
    db.close()
    return {'sample_id':args.sample_id,'arm':args.arm,'source_text':text,'source_sha256':hashlib.sha256(text.encode('utf-8')).hexdigest(),
      'date_start':row['date_start'],'date_end':row['date_end'],'date_source':row['date_source'],
      'prior_human_text_corrections':corrections,'prior_geographic_evidence_by_text_hash':prior_geographic,'label_coordinate_from_previous_parser':row['coordinate'],
      'previous_parser_clues':[{'raw':f['raw'],'name':f['name'],'kind':f['kind']} for f in row['fragments']],
      'read_full_text_first':True,'source_file':str(context_run/'results/localization_all_methods.jsonl')}

def retrieve(args,root,run,cfg):
    from retrieval_v2 import retrieve as retrieve_v2
    return retrieve_v2(args,root,run,cfg)

def project(args,root,run,cfg):
    from shapely.geometry import shape, mapping
    from shapely import make_valid, union_all
    data=json.loads(Path(args.geometry).read_text(encoding='utf-8'))
    if data['type']=='FeatureCollection':g=union_all([make_valid(shape(f['geometry'])) for f in data['features']])
    else:g=make_valid(shape(data['geometry'] if data['type']=='Feature' else data))
    manifest=json.loads((run/'sources/boundaries/manifest.json').read_text(encoding='utf-8'))
    records=[]
    for layer in manifest['layers']:
        features=json.loads((run/'sources/boundaries'/layer['file']).read_text(encoding='utf-8'))['features']
        for f in features:
            area=make_valid(shape(f['geometry']))
            if not area.intersects(g):continue
            records.append({'country':layer['iso'],'level':layer['level'],'name':f['properties']['shapeName'],
               'shape_id':f['properties']['shapeID'],'boundary_year':layer['year'],'boundary_id':layer['boundary_id'],
               'covers_whole_geometry':bool(area.covers(g)),'source':layer['metadata_url']})
    finest=None
    for level in ['ADM2','ADM1','ADM0']:
        cover=[r for r in records if r['level']==level and r['covers_whole_geometry']]
        if len(cover)==1:finest=cover[0];break
    return {'geometry_role':args.role,'evidence':args.evidence,'geometry_file':str(Path(args.geometry).resolve()),
       'geometry_type':g.geom_type,'geometry_bounds':list(g.bounds),'overlay_crs':'EPSG:4326',
       'finest_unit_covering_submitted_geometry':finest,'intersecting_units':records,
       'applies_to':{'label_coordinate':'transcribed_coordinate','collection_extent':'supported_collection_extent','feature_extent':'whole_named_feature','reference_point':'named_feature_reference_point'}[args.role]}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--profile',default=str(PROFILE))
    sp=p.add_subparsers(dest='command',required=True)
    c=sp.add_parser('context');c.add_argument('--sample-id',required=True);c.add_argument('--arm',default='E',choices=list('ABCDEF'))
    r=sp.add_parser('retrieve');r.add_argument('--name',action='append',required=True);r.add_argument('--kind',required=True,choices=list(KINDS)+['settlement','historical_admin','landmark','generic_or_unresolved_phrase','unknown'])
    r.add_argument('--context-text',default='');r.add_argument('--country',action='append');r.add_argument('--sample-id');r.add_argument('--limit',type=int,default=20);r.add_argument('--min-score',type=float,default=.75)
    g=sp.add_parser('project');g.add_argument('--geometry',required=True);g.add_argument('--role',required=True,choices=['label_coordinate','collection_extent','feature_extent','reference_point']);g.add_argument('--evidence',action='append',required=True)
    for command in [c,r,g]:command.add_argument('--out')
    args=p.parse_args();cfg,root,run=load_environment(args.profile)
    result={'context':context,'retrieve':retrieve,'project':project}[args.command](args,root,run,cfg)
    value=json.dumps(result,ensure_ascii=False,indent=2)
    if args.out:Path(args.out).parent.mkdir(parents=True,exist_ok=True);Path(args.out).write_text(value,encoding='utf-8');print(args.out)
    else:print(value)

if __name__=='__main__':main()
