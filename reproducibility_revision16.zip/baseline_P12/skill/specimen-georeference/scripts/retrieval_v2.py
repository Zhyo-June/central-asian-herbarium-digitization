"""Typed full-alias retrieval with versioned, context-scoped curation evidence."""
import json, re, sqlite3, unicodedata
from functools import lru_cache
from rapidfuzz import process, fuzz
from unidecode import unidecode

KINDS = {
    'lake': ('LK','LKS','LKN','LKNI','LKSI','LKI','RSV','RSVI'),
    'river': ('STM','STMS','STMI','STMM','STMX','SBED','CNFL','CNL','WTRC'),
    'mountain': ('MTS','MT','PK','PKS','MTD','HLL','HLLS','RDGE','PASS','RK','MESA'),
    'valley': ('VAL','VALS','BASN','GATE','GULCH'),
    'glacier': ('GLCR',), 'pass': ('PASS',), 'desert': ('DSRT','SAND'),
    'protected_area': ('RESN','PRK','RESF','RESW'),
    'country': ('PCLI','PCL','PCLD'), 'admin1': ('ADM1',),
    'admin2': ('ADM2','ADM3'),
}

def norm(value):
    value=unicodedata.normalize('NFKC',value).casefold().translate(str.maketrans({'ѣ':'е','і':'и','ѳ':'ф','ё':'е','ъ':'','қ':'к','ғ':'г','ҳ':'х','ў':'у','ӯ':'у','ӣ':'и','ң':'н','ө':'о','ү':'у'}))
    value=re.sub(r"[’ʻʼ`']",'',value)
    return ' '.join(re.sub('[^a-z0-9]+',' ',unidecode(value)).split())

def core(value):
    value=norm(value)
    value=re.sub(r'\b(?:range|ridge|mountain|mountains|lake|river|valley|glacier|khrebet|khrebta|gora|gory|gore|ozero|ozera|ozere|ozeru|reka|reki|rekoi|dolina|doliny|oblast|oblasti|region|district|raion|rayon|province|viloyati|tumani|tizmasi|zhotasy|lednik|lednika)\b',' ',value)
    return re.sub(r'(?:skogo|skomu|skaia|skaya|skii|skiy|skoi|skoe|sk)$','', ' '.join(value.split())).strip()

def connection(path):
    db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    return db

def type_clause(kind):
    if kind in KINDS:
        codes=KINDS[kind];return 'e.feature_code IN ('+','.join('?' for _ in codes)+')',list(codes)
    if kind=='settlement':return "e.feature_class='P'",[]
    if kind=='historical_admin':return "e.feature_class='A'",[]
    if kind=='landmark':return "e.feature_class IN ('L','T')",[]
    return "e.feature_class IN ('A','P','T','H','L')",[]

@lru_cache(maxsize=24)
def alias_pool(dbpath,kind):
    db=connection(dbpath);where,params=type_clause(kind);pool={}
    for r in db.execute('SELECT DISTINCT a.nkey FROM alias a JOIN entity e ON e.id=a.entity_id WHERE '+where,params):
        for key in {r[0],core(r[0])}:
            if len(key)>=3:pool.setdefault(key,set()).add(r[0])
    db.close();return pool

@lru_cache(maxsize=1024)
def name_matches(dbpath,kind,names,min_score):
    pool=alias_pool(dbpath,kind);matches={}
    for key in {norm(n) for n in names}|{core(n) for n in names}:
        if len(key)<3:continue
        for value,score,_ in process.extract(key,list(pool),scorer=fuzz.ratio,score_cutoff=min_score*100,limit=120):
            for original in pool[value]:matches[original]=max(score,matches.get(original,0))
    return matches

def curation_guidance(db,names,kind,raw_context):
    keys={norm(n) for n in names}|{core(n) for n in names}
    guidance=[]
    for row in db.execute('SELECT payload_json FROM curation_rule'):
        rule=json.loads(row[0])
        if not (keys & set(rule['query_keys'])):continue
        expected=rule['expected_kind']
        flexible=expected in {'compound_toponym','unresolved_fragment','terrain_or_named_place','settlement_or_land_description'}
        semantic=expected in {'habitat_or_terrain','label_note','gully_description'}
        compatible=kind==expected or kind in {'unknown','generic_or_unresolved_phrase'} or flexible or semantic
        rule['type_compatible']=compatible
        rule['matched_targets']=[dict(t) for t in rule.get('targets',[]) if not t.get('catalogue_only') and compatible and raw_context and re.search(t['context_regex'],raw_context,re.I)]
        rule['catalogue_evidence_targets']=[t for t in rule.get('targets',[]) if t.get('catalogue_only')]
        for target in rule['matched_targets']:
            row=db.execute('SELECT id,name,country,feature_code,latitude,longitude,geometry_role FROM entity WHERE id=?',(target['entity_id'],)).fetchone()
            target['reference_entity']=dict(row)
            target['feature_evidence']=[json.loads(r[0]) for r in db.execute('SELECT payload_json FROM feature_evidence WHERE entity_id=?',(target['entity_id'],))]
        rule['context_match']=bool(rule['matched_targets'])
        # Only a generic reading of a known terrain word is suppressed. An explicit named village/river remains searchable.
        named_marker=bool(re.search(r'(?:кишл\w*|пос[её]лок|дерев\w*|полуст\w*|станц\w*|р\.|река)\s*[,.:]?\s*(?:Адыр|Такыр|Джайляу)',raw_context,re.I))
        rule['semantic_non_place']=bool(rule['id'] in {'LP013','LP036','LP049'} and kind in {'unknown','generic_or_unresolved_phrase','habitat_or_terrain','terrain'} and raw_context and not named_marker)
        guidance.append(rule)
    return guidance

def retrieve(args,root,run,cfg):
    dbpath=run/'derived/gazetteer.sqlite3';db=connection(dbpath)
    where,params=type_clause(args.kind)
    keys={norm(n) for n in args.name}|{core(n) for n in args.name}
    matches=name_matches(dbpath,args.kind,tuple(args.name),args.min_score)
    if args.country:
        where+=' AND ('+' OR '.join("(','||e.country||',') LIKE ?" for _ in args.country)+')'
        params+=['%,'+c+',%' for c in args.country]
    units={u['id']:u for u in json.loads((run/'derived/administrative_units.json').read_text(encoding='utf-8'))}
    found=[]
    if matches:
        found=db.execute('SELECT a.raw,a.nkey,a.name_kind,a.valid_from,a.valid_to,a.evidence_id,e.* FROM alias a JOIN entity e ON e.id=a.entity_id WHERE '+where+' AND a.nkey IN ('+','.join('?' for _ in matches)+')',params+list(matches)).fetchall()
    tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    guidance=[]
    if 'curation_rule' in tables:
        guidance=curation_guidance(db,args.name,args.kind,getattr(args,'context_text','') or '')
    semantic_non_place=any(g['semantic_non_place'] for g in guidance)
    if semantic_non_place:found=[]
    best={}
    for r in found:
        eid=r['id'];item={'entity_id':eid,'name':r['name'],'matched_name':r['raw'],'query_similarity':round(matches[r['nkey']]/100,4),
            **{k:r[k] for k in ['country','feature_class','feature_code','name_kind','valid_from','valid_to','evidence_id','source','geometry_role']},
            'reference_point':{'latitude':r['latitude'],'longitude':r['longitude']},
            'reference_point_admin':[units[u] for u in [r['unit1'],r['unit2']] if u in units],
            'curation_evidence':[g for g in guidance if eid in g.get('entity_ids',[]) or eid==g.get('old_entity_id')]}
        if eid not in best or item['query_similarity']>best[eid]['query_similarity']:best[eid]=item
    candidates=sorted(best.values(),key=lambda x:(-x['query_similarity'],x['entity_id']))
    for item in candidates:
        item['feature_evidence']=[]
        if 'feature_evidence' in tables:
            item['feature_evidence']=[json.loads(r[0]) for r in db.execute('SELECT payload_json FROM feature_evidence WHERE entity_id=?',(item['entity_id'],))]
    historical=[]
    for row in db.execute('SELECT * FROM history'):
        if max(fuzz.ratio(core(n),core(row['old_name'])) for n in args.name)<85:continue
        h=dict(row);h['details']=json.loads(h.pop('attributes_json'));historical.append(h)
    observed=[]
    if getattr(args,'sample_id',None):
        for key in keys:
            observed.extend(dict(r) for r in db.execute('SELECT name,kind,COUNT(DISTINCT specimen_id) AS other_specimens,MIN(year) AS first_observed_year,MAX(year) AS last_observed_year FROM admin_mention WHERE nkey=? AND specimen_id<>? AND content_group NOT IN (SELECT content_group FROM admin_mention WHERE specimen_id=?) GROUP BY name,kind',(key,args.sample_id,args.sample_id)))
    db.close()
    return {'queries':args.name,'kind':args.kind,'country_filter':args.country,'candidate_count':len(candidates),'candidates':candidates[:args.limit],
        'historical_relations':historical,'catalogue_name_observations':observed,'curation_guidance':guidance,
        'reference_database':str(dbpath),'retrieval_method':'typed_full_alias_edit_similarity_v2_with_context_curation',
        'selection_status':'terrain_description_preserved' if semantic_non_place else 'candidates_for_llm_comparison','geometry_note':'Points refer to named features. Interpret the full locality to determine collection extent; curation rules apply only to matching contexts.'}
