# 定位结果

每个标本、每条路线、每种输入版本一条JSON记录。仅保存可核对的简明理由和来源，不要求模型输出内部推理过程。

| 字段 | 内容 |
|---|---|
| `sample_id`, `arm`, `input_version` | 标本、路线；版本为`original`或`human_corrected` |
| `source_text`, `source_sha256` | 该版本的实际输入与指纹 |
| `interpretation` | 地名原文片段、地物类别、规范检索写法、方向距离/路线/岸别/海拔、日期 |
| `selected_features` | 实体ID、名称、类别、所用名称证据ID、来源；参考点坐标标明角色 |
| `collection_location` | 最细可支持的地点描述、几何角色、GeoJSON文件、范围依据、原坐标基准和不确定度（未知写null） |
| `admin_projection` | 最细可支持层级、完整归属链、相交区县、边界年份、投影证据文件 |
| `decision` | `evidence_supported`、`needs_review`或`unresolved` |
| `evidence_summary` | 名称、上下文、历史和空间证据的简明结论及来源ID |
| `alternatives` | 有实质竞争的候选及排除/保留理由 |
| `review_items` | 具体需补证或核对的项目 |
| `provenance` | 模型身份、执行方式、输入和库版本、使用的修订记录 |
| `verification` | `llm_reviewed`、`spatial_checked`、`human_confirmed`分别记录；此次无人工操作时最后一项为false |
| `changes_20261023` / 后续日期字段 | 本轮增加或修正的字段、证据与理由；旧人工意见保留在`human_geographic_review` |

地物类别和行政等级各自记录。湖泊可以跨县，湖岸片段可以小于县域；两者都保留。地点实体已对应但缺少范围资料时，将实体对应保存，`collection_location`保留已知语义范围并列出缺少的几何资料。

批量统计以唯一标本为单位，每个输入版本分别报告：实体对应数量、点位/范围表达数量、各行政层级覆盖数量、人工确认数量。原输出与人工修订后的结果分别统计。库中候选数量、LLM选中数量和人工确认数量使用不同列名。

空间统计同时报告：`geospatial_reference_available`（标签坐标或已支持的地物点/范围，含区域背景）、`collection_linked_spatial_reference`（直接关联采集描述的空间参照）、`spatial_reference_or_admin`（空间参照与行政范围的去重并集）。原载坐标另列。地物参考点能用于相应尺度的分布展示；具体采集点或地段按实际证据进一步缩小。

原60条质量样本使用`results/links60_before_after.json`与CSV逐条保存原人工评级、旧绑定、新目标、上下文适用条件、资料来源及剩余问题。语义纠正、部分上下文解决和实体替换分别计数；再次人工评分后才更新人工正确率。

05版增加`review_class_05`（identity / precision / resolved / already_resolved）、`human_required_05`、`finding_05`、`remaining_05`，旧04字段保存在`previous_04`。`merged_issues.json`按问题组保存对应链接ID、去重原文、来源及`action_owner`（user_reading / public_source_research / optional_precision / closed）。待办行数、独立问题组和需用户读字的标签数分别统计。
