# 当前项目接入

项目：`project`。

配置在同目录的`project.json`。当前参考库为`11_rag/geographic_link_review_20261023_06`，最新319份定位结果仍为`11_rag/geographic_resolution_20261023_04`。05库继承04库，加入60条链接补证、公开地图参照和问题分级；具体数量见`derived/reference_manifest.json`。包含60条链接处置、638条按文本指纹保存的既有核查/最新结果，以及地物范围和行政资料。旧库均保留，六路线原输出由`geographic_resolution_20261022_01`只读取得。边界年份分布于2007—2020年，输出时保留版本。

使用现有Python：

```powershell
$env:PYTHONIOENCODING='utf-8'
$geoPython='python'
$geoTool='skill/specimen-georeference/scripts/geo_tools.py'
& $geoPython $geoTool context --sample-id TASH092107 --arm E
& $geoPython $geoTool retrieve --name 'Куруксай' --name 'Quruqsoy' --kind settlement --country UZ --sample-id TASH092107
& $geoPython $geoTool retrieve --name 'Сарезское озеро' --name 'Sarez' --kind lake --sample-id TASH085515
& $geoPython $geoTool retrieve --name 'Акбулак' --kind river --context-text 'Бассейн р. Чирчик, р. Саргардон, недалеко от слияния саргардона и Акбулака' --sample-id TASH072080
& $geoPython $geoTool project --geometry 'external_local/collection_extent.geojson' --role collection_extent --evidence '地图URL、版本及范围构建说明'
```

所有命令输出JSON，可加`--out 新文件路径`保存。输入GeoJSON采用经度、纬度顺序；坐标投影使用EPSG:4326，原标签未说明基准时在结果中保留该信息。

`retrieve`返回候选，不自动确认实体。`--country`用于原文或已取得证据支持的国家筛选；未知时省略。`--sample-id`排除当前标本及相同内容组的主表名称记录。返回`reference_point_admin`仅表示数据库参考点处的行政区。

检索由`scripts/retrieval_v2.py`执行：在地物类型对应的完整别名池中比较拼写，返回上下文修正规则、历史关系和地物证据；不再先截断FTS前300项。`--context-text`用于匹配规则适用条件。`generic_or_unresolved_phrase`可用于尚未明确类型的词；已判为普通地形描述的词保留语义，不作为该句的聚落候选。

`project`接受Point、LineString、Polygon、MultiPolygon、Feature或FeatureCollection。对采集范围返回完整覆盖与相交行政区；对地物范围和参考点只报告该地物或参考点的空间关系。具有已知范围时优先传入范围几何。

原人工核查：`16_paper/revision_20261022_11/manual_review/第11版核查进度_20261022151939.json`。用户已确认其中325项经过逐项人工核查。后续地理意见保存在04目录`inputs/human_review_2026-10-22.json`。`context`提取与当前标本、路线和原文相符的地点修订，并返回按文本SHA256分组的地理意见及选中实体。新的资料判定与旧人工确认分别记录。

路线：A=OCR-Rule，B=LLM-Assemble，C=LLM-Correct，D=LLM-RAG，E=VLM-Direct，F=VLM-RAG。示范默认E；批量比较时每条路线各以319份为分母。模型输入不要包含其他路线的判断结论；需要整合多路线时另建ensemble结果。

05目录中的`本轮补证与核查减负报告.html`为补证入口，`60条链接_本轮分级对照.html`逐条列出04→05差异。原45行合并为44组：2组已解决，15组已有参照、余下为可选精度，27组身份待补证。27组中3组原需核4张标签，06版已完成TASH103268读字，剩余3张，24组继续查公开资料。`review/60条链接_精简人工核查.html`优先显示这3组，可导出JSON。资料队列与精度队列折叠保留。

04目录的`地理分布结果.html`仍为319份结果入口；04旧核查页保留原288条标本/文本问题。05补证针对60条主表链接，没有重新推断这288项。14份标本文字发生过修订，305份双版本文字相同；两版本均继承已有地理核查，统计分母各为319。主表链接证据不补写到319原输出中。

后续每次运行另建目录，记录原输入指纹、检索结果、模型身份及决定。当前会话执行就是LLM步骤；脚本本身不调用模型API。旧技能文件见当前目录`skill_snapshots/before`，本版见`skill_snapshots/after`。

06版人工读字结果见`results/manual_review_applied.json`，当前读字入口为`review/剩余3张标签_人工核查.html`。LP059在查询`Егры-Чек`时返回标本限定的读字规则，保持原河名整体，不新增地图坐标。
