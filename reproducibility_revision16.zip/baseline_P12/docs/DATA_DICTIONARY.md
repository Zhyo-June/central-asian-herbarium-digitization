# Data dictionary

- `sample_id`: specimen barcode; the unit of sampling and clustering.
- `arm`: A OCR-Rule; B LLM-Assemble; C LLM-Correct; D LLM-RAG; E VLM-Direct; F VLM-RAG.
- `label_text`: literal output evaluated against the catalogue. `normalized_candidate` is stored separately.
- `M/S/D/I/Nref`: matched/substituted/deleted/inserted characters and reference length. Coverage is sum(M)/sum(Nref), not an average of percentages.
- `output_stream`: concatenate scientific-name, locality and collector output without extra separators. `same_field`: align only the matching field.
- `grade`: `correct` (complete), `partial`, `incorrect`, `unassessable`, `correct_empty`, `technical_failure`.
- `initial_visibility`: image-only readability recorded before comparison. The main eligible grade is `readable`.
- `candidate_code`: randomized within reviewer/specimen/field; compare independent reviews by specimen, field and candidate text, not this alias.
- `split`: historical development/reserve/test labels retained for provenance; all were exposed during workflow development.
- `query_id`: frozen retrieval benchmark ID; `ranks` contains first relevant result rank. Missing relevant results remain misses.
- Gateway model strings are archived request/response identifiers. `request_metadata` omits connection URLs, local user paths and image payloads while retaining request hashes, parameters, model strings, timing and usage.

## Record versions and final review

- `baseline_P12/` and `update_P15/baseline/` preserve the research results at their recorded stages. The current P16 results are in `update_P15/derived/`. The 60-specimen quantitative quality estimates concern the pre-correction records.
- `human_review_confirmation` records final human checking of geographic interpretations and administrative assignments, including decisions to retain unresolved outcomes. The author confirmation was recorded on 25 October 2026; it is not a separately documented review-completion date. This field does not indicate that all 319 records underwent the 60-specimen quantitative quality audit.
- The specimen CSV gives this information in `geographic_final_review_status`, `geographic_final_reviewer_type`, `geographic_review_confirmation_date`, `geographic_review_confirmation_source` and `geographic_review_scope`.
- `human_review.status`, `human_geographic_review.status` and `current_human_review.status` retain the original human judgment: `pending` means reviewed but still unable to confirm the relevant assertion with the available evidence (additional evidence is needed); `confirmed` means the stated correspondence or extent was confirmed; `amended` means a correction was recorded. These are research judgments and are retained with the notes, reviewer/source details and outstanding evidence questions.
- `human_review_confirmation.status=completed_by_humans` records completion of human checking. It does not replace the judgment above, establish that every assertion is correct, or resolve a `pending` outcome. A reviewed record can retain supported broad spatial information while a more specific interpretation remains unconfirmed.
- For the 60 place-name links, `decision_by` and `final_disposition_review` identify final human checking. `requires_human_review=true` identifies an outstanding source-image or reading-evidence task; the current disposition, including retention of an unresolved task, has been reviewed.
- Model identifiers, prompts, model outputs, scientific evidence, original human judgments and before-and-after research results are retained. Administrative operation history is archived separately by the authors.
