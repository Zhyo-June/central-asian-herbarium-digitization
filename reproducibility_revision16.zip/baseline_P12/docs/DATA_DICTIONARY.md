# Data dictionary

- `sample_id`: specimen barcode; the unit of sampling and clustering.
- `arm`: A OCR-Rule; B LLM-Assemble; C LLM-Correct; D LLM-RAG; E VLM-Direct; F VLM-RAG.
- `label_text`: literal output evaluated against the catalogue. `normalized_candidate` is stored separately.
- `M/S/D/I/Nref`: matched/substituted/deleted/inserted characters and reference length. Coverage is sum(M)/sum(Nref), not an average of percentages.
- `output_stream`: concatenate scientific-name, locality and collector output without extra separators. `same_field`: align only the matching field.
- `grade`: `correct` (complete), `partial`, `incorrect`, `unassessable`, `correct_empty`, `technical_failure`.
- `initial_visibility`: image-only readability recorded before comparison. The main eligible grade is `readable`.
- `candidate_code`: randomized within reviewer/specimen/field; compare independent reviews by specimen, field and candidate text, not this alias.
- `split`: historical development/reserve/test labels retained for provenance; all were exposed during workflow development.
- `query_id`: frozen retrieval benchmark ID; `ranks` contains first relevant result rank. Missing relevant results remain misses.
- Gateway model strings are archived request/response identifiers. `request_metadata` omits connection URLs, local user paths and image payloads while retaining request hashes, parameters, model strings, timing and usage.

## P16 final human review and historical execution metadata

The author confirmed on 25 October 2026 that the geographic interpretations were checked by humans and that all 60 final place-name-link dispositions were individually checked and confirmed, including retained unresolved outcomes. This is the confirmation-record date; an actual review-completion date was not separately supplied.

- In current `update_P15/derived/` JSONL records, `human_review_confirmation` is the final status for geographic interpretation and administrative assignments. It is not a claim that all 319 records received the 60-specimen quantitative quality audit.
- The current specimen CSV mirrors that status in `geographic_final_review_status`, `geographic_final_reviewer_type`, `geographic_review_confirmation_date`, `geographic_review_confirmation_source` and `geographic_review_scope`.
- The nine current administrative subrecords formerly labelled with `adjudicator=current_session_llm` and `human_confirmed=false` retain those original values inside `initial_interpretation_provenance`. Their current `adjudicator` identifies human final checking and their current `human_confirmed` is true. Coordinates, names, roles and category assignments are unchanged.
- Frozen paired geography, pre-revision baseline records and review-preparation inputs preserve original flags. `review_metadata_stage=historical_snapshot` explicitly scopes those flags to their recorded stage; the later final-review status is identified separately. Original false values are not independent evidence of a currently unreviewed final record.
- For the 60 link dispositions, `initial_AI_assisted_proposal_provenance` identifies the AI-assisted proposal and its original confirmation status. `decision_by` and `final_disposition_review` identify final human checking. If `requires_human_review` is true, it means an outstanding source-image or reading-evidence task; the decision to retain that task has itself been reviewed.
- `new_independent_validation_claimed=false` means this provenance clarification does not create a new independent reviewer, validation cohort, accuracy estimate or additional observations. The 60-specimen quality audit remains single-reviewer and unblinded; the 15-specimen independent second review is a separate existing design.
- Table S1 validation mean/SD values are in `tables/paddle_fixed_update_summary.csv`. Its development CER values use the `fixed_final180` rows of `tables/paddle_fixed_update_dev49_summary.csv`; `best_validation_of7` rows are retained in the original source report but are not the development values quoted in Table S1. The same 49 development specimens and 256 lines are shared by the three training seeds.
