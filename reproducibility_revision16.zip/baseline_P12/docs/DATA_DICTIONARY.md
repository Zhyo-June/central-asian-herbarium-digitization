# Data dictionary

- `sample_id`: specimen barcode; the unit of sampling and clustering.
- `arm`: A OCR-Rule; B LLM-Assemble; C LLM-Correct; D LLM-RAG; E VLM-Direct; F VLM-RAG.
- `label_text`: literal output evaluated against the catalogue. `normalized_candidate` is stored separately.
- `M/S/D/I/Nref`: matched/substituted/deleted/inserted characters and reference length. Coverage is sum(M)/sum(Nref), not an average of percentages.
- `output_stream`: concatenate scientific-name, locality and collector output without extra separators. `same_field`: align only the matching field.
- `grade`: `correct` (complete), `partial`, `incorrect`, `unassessable`, `correct_empty`, `technical_failure`.
- `initial_visibility`: image-only readability recorded before comparison. The main eligible grade is `readable`.
- `candidate_code`: randomized within reviewer/specimen/field; compare independent reviews by specimen, field and candidate text, not this alias.
- `split`: historical development/reserve/test labels retained for provenance; all were exposed during workflow development.
- `query_id`: frozen retrieval benchmark ID; `ranks` contains first relevant result rank. Missing relevant results remain misses.
- Gateway model strings are archived request/response identifiers. `request_metadata` omits connection URLs, local user paths and image payloads while retaining request hashes, parameters, model strings, timing and usage.
